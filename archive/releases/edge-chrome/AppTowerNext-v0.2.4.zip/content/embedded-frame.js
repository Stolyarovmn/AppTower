(() => {
  if (window === window.top) return;

  const STYLE_ID = "app-tower-next-embedded-cleanup";
  const MSG = "ATN_EMBED_INIT_V024";

  function enableCleanup() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      html, body, * {
        scrollbar-width: none !important;
      }
      html::-webkit-scrollbar,
      body::-webkit-scrollbar,
      *::-webkit-scrollbar {
        width: 0 !important;
        height: 0 !important;
        display: none !important;
      }
      html, body {
        overscroll-behavior: contain !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
    document.documentElement.setAttribute("data-atn-embedded", "1");
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window.parent) return;
    if (event.data?.type !== MSG) return;
    enableCleanup();
  });
})();

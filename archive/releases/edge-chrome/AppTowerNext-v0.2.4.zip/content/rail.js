(() => {
  if (window !== window.top) return;

  const INSTANCE = "__appTowerNextRailV022";
  for (const key of ["__appTowerNextRailV011","__appTowerNextRailV021",INSTANCE]) {
    try { globalThis[key]?.dispose?.(); } catch {}
  }

  const HOST_ID="app-tower-next-host";
  const RESERVED_CLASS="app-tower-next-reserved";
  const HIDDEN_CLASS="app-tower-next-hidden";
  const FIXED_CLASS="app-tower-next-fixed";
  const FIXED_ANCHORED="app-tower-next-fixed-anchored";
  const FIXED_SHIFTED="app-tower-next-fixed-shifted";
  const ROOT_PADDING_VAR="--atn-original-root-padding-right";
  const FIXED_RIGHT_VAR="--atn-original-fixed-right";
  const RAIL_WIDTH=46;

  let disposed=false, visible=false, adjustmentFrame=null, railPort=null, reconnectTimer=null;
  const adjustedFixed=new Set();

  // Remove stale DOM/CSS state left by a previous unpacked build in this tab.
  document.getElementById(HOST_ID)?.remove();
  document.documentElement.classList.remove(RESERVED_CLASS);
  document.documentElement.style.removeProperty(ROOT_PADDING_VAR);
  for (const el of document.querySelectorAll(`.${FIXED_CLASS}`)) {
    el.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);
    el.style.removeProperty(FIXED_RIGHT_VAR);
  }

  const host=document.createElement("aside");
  host.id=HOST_ID; host.className=HIDDEN_CLASS; host.setAttribute("aria-label","App Tower Next");
  const shadow=host.attachShadow({mode:"closed"});
  shadow.innerHTML=`<style>
    :host,*{box-sizing:border-box}.rail{width:46px;height:100%;display:flex;flex-direction:column;align-items:center;gap:5px;padding:7px 4px;overflow-x:hidden;overflow-y:auto;scrollbar-width:none;color:#eee;background:#202020;border-left:1px solid rgba(255,255,255,.10);box-shadow:-3px 0 10px rgba(0,0,0,.20);pointer-events:auto;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}.rail::-webkit-scrollbar{display:none}button{all:unset;box-sizing:border-box}.site,.tool{width:36px;height:36px;flex:0 0 36px;display:grid;place-items:center;border-radius:8px;cursor:pointer;color:#ededed}.site:hover,.tool:hover,.site:focus-visible,.tool:focus-visible{background:rgba(255,255,255,.11)}.site:focus-visible,.tool:focus-visible{outline:2px solid #45c9bc;outline-offset:1px}.site img{width:25px;height:25px;object-fit:contain;border-radius:6px}.fallback{width:25px;height:25px;display:grid;place-items:center;border-radius:50%;background:#0f766e;color:white;font:700 12px/1 system-ui,sans-serif}.spacer{flex:1 1 auto;min-height:10px}.sep{width:28px;height:1px;flex:0 0 1px;margin:4px 0;background:rgba(255,255,255,.17)}.tool svg{width:23px;height:23px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
  </style><nav class="rail" aria-label="App Tower Next sites"></nav>`;
  document.documentElement.appendChild(host);
  const rail=shadow.querySelector(".rail");

  function faviconURL(url){const u=new URL("/_favicon/",chrome.runtime.getURL("/"));u.searchParams.set("pageUrl",url);u.searchParams.set("size","32");return u.href;}
  function fallback(title){const e=document.createElement("span");e.className="fallback";e.textContent=(title||"?").trim().slice(0,1).toUpperCase();return e;}
  function siteButton(site){
    const b=document.createElement("button");b.type="button";b.className="site";b.title=`${site.title}\nClick → active pane\nShift+Click → bottom pane`;
    const img=document.createElement("img");img.alt="";img.src=faviconURL(site.url);img.addEventListener("error",()=>img.replaceWith(fallback(site.title)),{once:true});b.append(img);
    b.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();chrome.runtime.sendMessage({type:"OPEN_SITE",url:site.url,title:site.title,mode:site.mode,compatDomains:site.compatDomains,siteId:site.id,targetPane:e.shiftKey?"bottom":undefined}).catch(()=>{});});
    return b;
  }
  function toolButton(kind,title,intent){
    const b=document.createElement("button");b.type="button";b.className="tool";b.title=title;b.innerHTML=kind==="plus"?`<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>`:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.6 1.6 0 0 0 .32 1.76l.08.08-2.96 2.96-.08-.08A1.6 1.6 0 0 0 15 19.4a1.6 1.6 0 0 0-1 .58 1.6 1.6 0 0 0-.4 1.02V21H9.4v-.02A1.6 1.6 0 0 0 8 19.4a1.6 1.6 0 0 0-1.76.32l-.08.08-2.96-2.96.08-.08A1.6 1.6 0 0 0 3.6 15a1.6 1.6 0 0 0-.58-1A1.6 1.6 0 0 0 2 13.6V9.4h.02A1.6 1.6 0 0 0 3.6 8a1.6 1.6 0 0 0-.32-1.76l-.08-.08L6.16 3.2l.08.08A1.6 1.6 0 0 0 8 3.6a1.6 1.6 0 0 0 1-.58A1.6 1.6 0 0 0 9.4 2H13.6v.02A1.6 1.6 0 0 0 15 3.6a1.6 1.6 0 0 0 1.76-.32l.08-.08 2.96 2.96-.08.08A1.6 1.6 0 0 0 19.4 8a1.6 1.6 0 0 0 .58 1A1.6 1.6 0 0 0 21 9.4V13.6h-.02A1.6 1.6 0 0 0 19.4 15Z"/></svg>`;
    b.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();chrome.runtime.sendMessage({type:"OPEN_PANEL",intent}).catch(()=>{});});return b;
  }
  async function renderSites(){const {sites=[]}=await chrome.storage.local.get("sites");if(disposed)return;rail.replaceChildren();for(const s of sites)if(s?.url)rail.append(siteButton(s));const spacer=document.createElement("div");spacer.className="spacer";rail.append(spacer);const sep=document.createElement("div");sep.className="sep";rail.append(sep);rail.append(toolButton("plus","Add site","add"),toolButton("settings","Settings","settings"));}

  function clearFixedAdjustments(){for(const el of adjustedFixed){el.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);el.style.removeProperty(FIXED_RIGHT_VAR);}adjustedFixed.clear();}
  function fixedAncestor(element){for(let node=element;node&&node!==document.documentElement;node=node.parentElement){if(node===host)return null;if(getComputedStyle(node).position==="fixed")return node;}return null;}
  function collectFixedAtRightEdge(){const found=new Set(),vw=window.innerWidth,vh=window.innerHeight;const xs=[Math.max(0,vw-2),Math.max(0,vw-RAIL_WIDTH-2)],ys=[2,Math.max(2,vh-2)];for(let y=24;y<vh;y+=64)ys.push(y);for(const x of xs)for(const y of ys)for(const hit of document.elementsFromPoint(x,y)){const f=fixedAncestor(hit);if(!f)continue;const r=f.getBoundingClientRect();if(r.width>0&&r.height>0&&r.right>vw-RAIL_WIDTH&&r.left<vw)found.add(f);}return found;}
  function adjustRightFixedElements(){adjustmentFrame=null;if(!visible){clearFixedAdjustments();return;}const next=collectFixedAtRightEdge();for(const old of [...adjustedFixed])if(!next.has(old)){old.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);old.style.removeProperty(FIXED_RIGHT_VAR);adjustedFixed.delete(old);}for(const el of next){if(adjustedFixed.has(el))continue;const right=getComputedStyle(el).right;el.classList.add(FIXED_CLASS);if(right&&right!=="auto"){el.style.setProperty(FIXED_RIGHT_VAR,right);el.classList.add(FIXED_ANCHORED);}else el.classList.add(FIXED_SHIFTED);adjustedFixed.add(el);}}
  function scheduleFixedAdjustment(){if(adjustmentFrame!==null)return;adjustmentFrame=requestAnimationFrame(adjustRightFixedElements);}


  function setVisible(next){
    if(disposed)return;next=Boolean(next);if(next===visible)return;
    if(next){
      document.documentElement.style.setProperty(ROOT_PADDING_VAR,getComputedStyle(document.documentElement).paddingRight);
      visible=true;host.classList.remove(HIDDEN_CLASS);document.documentElement.classList.add(RESERVED_CLASS);scheduleFixedAdjustment();
    } else {
      visible=false;host.classList.add(HIDDEN_CLASS);document.documentElement.classList.remove(RESERVED_CLASS);if(adjustmentFrame!==null){cancelAnimationFrame(adjustmentFrame);adjustmentFrame=null;}clearFixedAdjustments();document.documentElement.style.removeProperty(ROOT_PADDING_VAR);
    }
  }

  chrome.storage.onChanged.addListener((changes,area)=>{if(area==="local"&&!disposed&&changes.sites)renderSites().catch(()=>{});});
  chrome.runtime.onMessage.addListener(message=>{if(!disposed&&message?.type==="ATN_SET_RAIL_VISIBLE")setVisible(message.visible);});
  window.addEventListener("resize",scheduleFixedAdjustment,{passive:true});window.addEventListener("scroll",scheduleFixedAdjustment,{passive:true});
  const observer=new MutationObserver(scheduleFixedAdjustment);observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:["class","style"]});

  function connectPort(){
    if(disposed||railPort)return;clearTimeout(reconnectTimer);
    try{
      const p=chrome.runtime.connect({name:"ATN_RAIL"});railPort=p;p.onMessage.addListener(m=>{if(m?.type==="ATN_RAIL_VISIBILITY")setVisible(m.visible);});p.onDisconnect.addListener(()=>{if(railPort===p)railPort=null;if(!disposed)reconnectTimer=setTimeout(connectPort,250);});
    }catch{reconnectTimer=setTimeout(connectPort,500);}
  }

  globalThis[INSTANCE]={dispose(){disposed=true;clearTimeout(reconnectTimer);try{railPort?.disconnect();}catch{}railPort=null;observer.disconnect();if(adjustmentFrame!==null)cancelAnimationFrame(adjustmentFrame);visible=false;clearFixedAdjustments();document.documentElement.classList.remove(RESERVED_CLASS);document.documentElement.style.removeProperty(ROOT_PADDING_VAR);host.remove();}};

  renderSites().catch(()=>{});connectPort();
  chrome.runtime.sendMessage({type:"GET_RAIL_VISIBILITY"}).then(r=>{if(!disposed)setVisible(r?.visible!==false);}).catch(()=>{if(!disposed)setVisible(true);});
})();

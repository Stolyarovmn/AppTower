# App Tower Next v0.3.7

Experimental Manifest V3 extension for Microsoft Edge and Google Chrome.

## v0.3.7

- Removed the development default shortcuts (Yandex Translate / Google / GitHub / YouTube).
- Added Home onboarding when no shortcuts exist.
- `+` now opens the Add Site dialog prefilled from the active browser tab.
- The broom button clears the prefilled title/URL so an arbitrary site can be entered.
- Home provides Add current page, Add arbitrary site, Import, and Browser Sync.
- Settings provides Browser Sync on/off and JSON Export / Import.
- Browser Sync uses `chrome.storage.sync` for shortcut definitions only. Current panes, split ratio and active layout remain local to the device.
- JSON backup includes shortcuts, panes and layout. Import supports Merge or Replace.
- Fixed collapsed rail disappearing after `>` collapse by keeping an explicit per-window collapse intent across Side Panel port/onClosed races.
- Collapse broadcasts the page rail immediately and then invokes native `chrome.sidePanel.close()` without waiting for the background worker.

## Data model

- `chrome.storage.local`: working state and local layout.
- `chrome.storage.sync`: optional synced shortcut payload.
- Uninstall removes extension-local data as expected by Chromium.
- JSON Export is the explicit portable backup path.

## Install

1. Extract the ZIP into a clean folder.
2. Open `edge://extensions` or `chrome://extensions`.
3. Enable Developer mode.
4. Load unpacked and select the folder containing `manifest.json`.
5. Reload already-open HTTP/HTTPS tabs after updating an unpacked build.

## Security note

Compatibility mode removes frame-blocking response headers only for domains attached to a pane. Use Secure or Real Page for sensitive login/password pages when appropriate.


## v0.3.7

- The Add Site broom moved to the top-right corner and resets the whole form:
  title, URL, mode and compatibility domains.
- Collapse no longer shows or resizes the underlying page before Chromium has
  actually closed the native Side Panel.
- `sidePanel.onClosed` is authoritative for the collapsed state, so the browser
  owned native Side Panel X also naturally collapses back to App Tower.
- A stale Side Panel runtime port cannot override the collapsed state because
  `collapsedWindows` is persisted before the external rail is broadcast.

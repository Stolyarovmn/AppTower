# App Tower Next v0.2.8

Test build for current Microsoft Edge / Google Chrome (Manifest V3).

## New in v0.2.8

- Added **Collapse to App Tower** button in the native side-panel header. It closes only the expanded Side Panel and immediately reveals the 46 px App Tower rail on the current web page.
- Added the same collapse action to Settings.
- Replaced custom add/settings artwork with Windows **Segoe Fluent Icons** when available (`Add` U+E710, `Settings` U+E713, `ChevronRight` U+E76C), with symbol fallback outside Windows.
- Keeps v0.2.7 pane activation bridge, split workspace, compatibility renderer, YouTube support and rail stability fixes.

## Chromium limitations

### Full panel auto-open on browser startup
The public Side Panel API permits `chrome.sidePanel.open()` only in response to a user action. The expanded native panel therefore cannot be opened honestly from `runtime.onStartup`. The collapsed App Tower rail loads automatically on normal HTTP/HTTPS pages.

### Native Side Panel width
Chromium owns and persists the manually resized width for each side-panel entry. The public extension API exposes no width/default-width/reset-width setter, so v0.2.8 does not include a fake reset-width control. A real reset would require an external native helper editing the browser profile while the browser is closed.

### Narrow widths
The project will not use a fake virtual viewport. Future narrow-width support should prefer a real mobile site/mobile renderer on a per-site basis where technically possible.

## Install / update
1. Unpack into a **new empty folder**.
2. Open `edge://extensions` or `chrome://extensions`.
3. Keep only one App Tower Next install enabled.
4. Load the unpacked v0.2.8 folder.
5. Reload already-open web tabs so the newest content script is active.

# App Tower Next v0.6.0

Experimental Manifest V3 extension for Microsoft Edge and Google Chrome.

## v0.6.0 — PWA-aware Auto

App Tower no longer depends on the deprecated Edge PWA sidebar mechanism.

The Core now detects the standard Web App Manifest declared by a normal page:

```html
<link rel="manifest" href="/manifest.webmanifest">
```

Discovery is performed by a dedicated `content/pwa-discovery.js` content script.
The background worker fetches the manifest, validates/sanitizes it and stores a
bounded local metadata cache.

Cached metadata includes:
- name / short_name
- start_url
- scope
- display
- icons
- shortcuts
- manifest URL

The cache is local discovery metadata and is not Browser Sync data.

## Auto priority

Auto uses this order:

1. Installed declarative App Tower module
2. PWA/App preference for a discovered Web App Manifest
3. Ordinary web iframe with scoped Compatibility when necessary

A specialized module therefore wins over generic PWA handling.

## PWA App mode

When a Web App Manifest is discovered, a small app button appears in that
pane's toolbar (unless an installed specialized module already owns the URL).

The PWA dialog shows the app name, start URL, display mode and manifest
shortcuts. Settings -> Web Apps lists discovered manifests and can clear the
rediscoverable cache.

The user can enable:

`Use app mode in Auto`

When enabled, App Tower does NOT load that site in the pane iframe. The pane
becomes a lightweight launcher.

`Open as app` creates a top-level browser popup/sidecar using
`chrome.windows.create()`.

This is intentionally NOT an Edge `edge_side_panel` integration and it is not
an attempt to control an installed OS/PWA shell. It is a normal top-level web
page in a managed popup window, so the page is no longer an iframe child of the
App Tower extension.

One sidecar window is reused per web-app origin while the background state is
available; the mapping is also persisted in `chrome.storage.session`.

Manifest shortcuts are exposed as launch buttons and open inside the same
sidecar app window.

## Add Site integration

If the Add Site URL belongs to a known but uninstalled provider module, App
Tower suggests the declarative module first.

If no provider module owns the URL and a Web App Manifest has already been
discovered, Add Site offers `Use App`.

## Modules

Provider-specific integrations remain outside Core logic:

- YouTube
- Yandex Music
- additional user JSON modules

A module is declarative data, not executable JavaScript/WASM.

Settings -> Modules supports:
- install bundled module
- remove module
- import validated module JSON

## Data / backup

`chrome.storage.local`
- sites
- panes
- layout
- installed declarative modules
- PWA manifest cache
- local PWA launch preferences

`chrome.storage.sync` (optional)
- shortcuts
- installed declarative module manifests

PWA launch preference is intentionally local because desktop/window layouts can
differ between devices.

JSON Export schema 3 includes:
- sites
- panes
- layout
- modules
- PWA sidecar preferences

PWA manifest cache is not exported because it is rediscoverable.

## Startup

The collapsed App Tower rail remains injected at `document_start`.

The extension also overrides New Tab with its own minimal start page, as in
v0.4.x/v0.5.x.

The native Side Panel still cannot be force-opened automatically at browser
startup because the browser requires a user gesture for `sidePanel.open()`.

## Install

1. Extract the ZIP to a clean folder.
2. Open `edge://extensions` or `chrome://extensions`.
3. Enable Developer mode.
4. Load unpacked and choose the folder containing `manifest.json`.
5. Reload already-open HTTP/HTTPS tabs after updating an unpacked build.

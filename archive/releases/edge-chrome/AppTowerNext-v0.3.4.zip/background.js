const RENDER_MODES = new Set(["auto", "secure", "compat", "real"]);
const SIDE_PANEL_PATH = "sidepanel/sidepanel.html";
const SESSION_RULE_BASE = 30000;
const PANEL_SESSION_KEY = "atnPanelOpenWindowsV025";
const STATE_SCHEMA_VERSION = 6;
const YOUTUBE_COMPAT_DOMAINS = ["youtube.com","youtube-nocookie.com","google.com","googlevideo.com","ytimg.com","gstatic.com","googleapis.com","googleusercontent.com","ggpht.com","doubleclick.net"];

const DEFAULT_SITES = [
  { id:"yandex-translate", title:"Яндекс Переводчик", url:"https://translate.yandex.ru/", mode:"auto", compatDomains:["yandex.ru","ya.ru"] },
  { id:"google", title:"Google", url:"https://www.google.com/", mode:"auto", compatDomains:[] },
  { id:"github", title:"GitHub", url:"https://github.com/", mode:"auto", compatDomains:[] },
  { id:"youtube", title:"YouTube", url:"https://www.youtube.com/", mode:"auto", compatDomains:YOUTUBE_COMPAT_DOMAINS }
];
const DEFAULT_SITE_BY_ID = new Map(DEFAULT_SITES.map(site => [site.id, site]));

const DEFAULT_STATE = {
  sites: DEFAULT_SITES,
  panes: {
    top: { url:"https://translate.yandex.ru/", title:"Яндекс Переводчик", mode:"compat", compatDomains:["yandex.ru","ya.ru"], sourceSiteId:"yandex-translate" },
    bottom: { url:"https://www.youtube.com/", title:"YouTube", mode:"compat", compatDomains:YOUTUBE_COMPAT_DOMAINS, sourceSiteId:"youtube" }
  },
  layout: { split:true, ratio:0.58, activePane:"top" }
};

const openWindows = new Set();
// A side-panel document can remain alive for a short time while Chromium is
// closing it. Its runtime Port must not immediately mark the window open again.
const closingWindows = new Set();
const closingTimers = new Map();
const panelSessionReady = chrome.storage.session.get(PANEL_SESSION_KEY).then(data => {
  for (const value of data[PANEL_SESSION_KEY] || []) {
    const id = Number(value);
    if (Number.isInteger(id)) openWindows.add(id);
  }
}).catch(() => {});
const railPorts = new Map();
const panelPorts = new Map();

chrome.runtime.onInstalled.addListener(() => {
  void initialize(true);
});
chrome.runtime.onStartup.addListener(() => {
  void initialize(false);
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick:true }).catch(() => {});

if (chrome.sidePanel.onOpened?.addListener) {
  chrome.sidePanel.onOpened.addListener(({path, windowId}) => {
    if (!Number.isInteger(windowId) || !matchesPanelPath(path)) return;
    clearClosingState(windowId);
    markPanelOpen(windowId);
  });
}
if (chrome.sidePanel.onClosed?.addListener) {
  chrome.sidePanel.onClosed.addListener(({path, windowId}) => {
    if (!Number.isInteger(windowId) || !matchesPanelPath(path)) return;
    markPanelClosed(windowId);
  });
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "ATN_RAIL") {
    const windowId = port.sender?.tab?.windowId;
    if (!Number.isInteger(windowId)) return;
    addPort(railPorts, windowId, port);
    panelSessionReady.then(() => safePost(port, { type:"ATN_RAIL_VISIBILITY", visible:!openWindows.has(windowId) }));
    return;
  }

  const match = /^ATN_SIDE_PANEL:(\d+)$/.exec(port.name || "");
  if (match) {
    const windowId = Number(match[1]);
    if (!Number.isInteger(windowId)) return;
    addPort(panelPorts, windowId, port);
    // During an explicit collapse Chromium can keep/reconnect this document for
    // a moment. Do not let that stale port hide the page rail again.
    if (!closingWindows.has(windowId)) markPanelOpen(windowId);
    port.onDisconnect.addListener(() => {
      setTimeout(() => {
        if (!panelPorts.get(windowId)?.size) markPanelClosed(windowId);
      }, 80);
    });
  }
});

function addPort(map, windowId, port) {
  let set = map.get(windowId);
  if (!set) { set = new Set(); map.set(windowId, set); }
  set.add(port);
  port.onDisconnect.addListener(() => {
    set.delete(port);
    if (!set.size) map.delete(windowId);
  });
}
function safePost(port, message) { try { port.postMessage(message); } catch {} }
function broadcastRail(windowId, visible) {
  for (const port of railPorts.get(windowId) || []) safePost(port, { type:"ATN_RAIL_VISIBILITY", visible });
  chrome.tabs.query({ windowId }).then(tabs => Promise.allSettled(
    tabs.filter(t => Number.isInteger(t.id)).map(t => chrome.tabs.sendMessage(t.id, { type:"ATN_SET_RAIL_VISIBLE", visible }))
  )).catch(() => {});
}
function persistPanelWindows() {
  chrome.storage.session.set({ [PANEL_SESSION_KEY]: [...openWindows] }).catch(() => {});
}
function clearClosingState(windowId) {
  closingWindows.delete(windowId);
  const timer = closingTimers.get(windowId);
  if (timer) clearTimeout(timer);
  closingTimers.delete(windowId);
}

function beginClosingState(windowId) {
  clearClosingState(windowId);
  closingWindows.add(windowId);
  // Safety timeout: if Chromium fails to emit onClosed, keep the requested
  // collapsed state but allow a later genuine OPEN_PANEL/onOpened to reopen it.
  const timer = setTimeout(() => {
    closingWindows.delete(windowId);
    closingTimers.delete(windowId);
    // Reassert the collapsed rail after the side-panel document has had time
    // to unload/reconnect its runtime Port.
    if (!openWindows.has(windowId)) broadcastRail(windowId, true);
  }, 1500);
  closingTimers.set(windowId, timer);
}

function markPanelOpen(windowId) {
  if (closingWindows.has(windowId)) return;
  openWindows.add(windowId);
  persistPanelWindows();
  broadcastRail(windowId, false);
}
function markPanelClosed(windowId) {
  clearClosingState(windowId);
  openWindows.delete(windowId);
  persistPanelWindows();
  broadcastRail(windowId, true);
}
function matchesPanelPath(path) {
  return !path || String(path).endsWith(SIDE_PANEL_PATH);
}

chrome.windows.onRemoved.addListener((windowId) => {
  clearClosingState(windowId);
  openWindows.delete(windowId);
  persistPanelWindows();
  railPorts.delete(windowId);
  panelPorts.delete(windowId);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.panes) void syncCompatibilityRules(changes.panes.newValue);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;

  if (message.type === "OPEN_SITE") {
    const windowId = sender?.tab?.windowId;
    let openPromise = Promise.resolve();
    if (Number.isInteger(windowId)) {
      clearClosingState(windowId);
      // Hide the page rail synchronously before the native panel starts opening.
      openWindows.add(windowId);
      broadcastRail(windowId, false);
      try { openPromise = chrome.sidePanel.open({windowId}); }
      catch (error) { openPromise = Promise.reject(error); }
    }
    (async () => {
      try {
        const current = await ensureDefaults();
        const url = normalizeUrl(message.url);
        if (!url) throw new Error("Invalid URL");
        const explicitBottom = message.targetPane === "bottom";
        const existingPane = explicitBottom ? null : findPaneForUrl(current.panes, url);
        const targetPane = explicitBottom ? "bottom" : (existingPane || current.layout.activePane);
        if (!existingPane || explicitBottom) {
          const inferred = inferDefaultsForUrl(url);
          current.panes[targetPane] = {
            url,
            title:String(message.title || url),
            mode:resolveAutoMode(url, normalizeMode(message.mode || inferred.mode)),
            compatDomains:normalizeCompatDomains(Array.isArray(message.compatDomains) && message.compatDomains.length ? message.compatDomains : inferred.compatDomains),
            sourceSiteId:message.siteId ? String(message.siteId) : null
          };
        }
        if (explicitBottom) current.layout.split = true;
        current.layout.activePane = targetPane;
        await chrome.storage.local.set({panes:current.panes, layout:current.layout});
        await syncCompatibilityRules(current.panes);
        await openPromise;
        sendResponse({ok:true});
      } catch (error) {
        if (Number.isInteger(windowId)) markPanelClosed(windowId);
        sendResponse({ok:false, error:String(error?.message || error)});
      }
    })();
    return true;
  }

  if (message.type === "OPEN_PANEL") {
    const windowId = sender?.tab?.windowId;
    let openPromise = Promise.resolve();
    if (Number.isInteger(windowId)) {
      clearClosingState(windowId);
      openWindows.add(windowId);
      broadcastRail(windowId, false);
      try { openPromise = chrome.sidePanel.open({windowId}); }
      catch (error) { openPromise = Promise.reject(error); }
    }
    (async () => {
      try {
        await ensureDefaults();
        if (["add","settings"].includes(message.intent)) {
          await chrome.storage.local.set({pendingAction:{intent:message.intent, nonce:Date.now()}});
        }
        await openPromise;
        sendResponse({ok:true});
      } catch (error) {
        if (Number.isInteger(windowId)) markPanelClosed(windowId);
        sendResponse({ok:false, error:String(error?.message || error)});
      }
    })();
    return true;
  }

  if (message.type === "COLLAPSE_PANEL") {
    const windowId = Number(message.windowId);
    (async () => {
      try {
        if (!Number.isInteger(windowId)) throw new Error("Invalid windowId");
        beginClosingState(windowId);
        markPanelClosed(windowId);
        if (typeof chrome.sidePanel.close === "function") {
          await chrome.sidePanel.close({ windowId });
        } else {
          clearClosingState(windowId);
          throw new Error("sidePanel.close is not available in this Chromium version");
        }
        sendResponse({ ok:true });
      } catch (error) {
        sendResponse({ ok:false, error:String(error?.message || error) });
      }
    })();
    return true;
  }

  if (message.type === "GET_RAIL_VISIBILITY") {
    const windowId = sender?.tab?.windowId;
    panelSessionReady.then(() => {
      sendResponse({ visible:Number.isInteger(windowId) ? !openWindows.has(windowId) : true });
    });
    return true;
  }

  if (message.type === "SYNC_COMPAT_RULES") {
    (async () => {
      const panes = message.panes || (await chrome.storage.local.get("panes")).panes;
      const result = await syncCompatibilityRules(panes);
      sendResponse({ok:true, ...result});
    })().catch(error => sendResponse({ok:false, error:String(error?.message || error)}));
    return true;
  }

  if (message.type === "GET_STATE") {
    (async () => {
      const current = await ensureDefaults();
      const extra = await chrome.storage.local.get(["pendingAction"]);
      sendResponse({...current, ...extra});
    })().catch(error => sendResponse({ok:false, error:String(error?.message || error)}));
    return true;
  }
});

async function initialize(injectOpenTabs) {
  const current = await ensureDefaults();
  await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true});
  // v0.2.1 used dynamic rules. Clear any rules left by a same-ID development update.
  const oldDynamic = await chrome.declarativeNetRequest.getDynamicRules();
  if (oldDynamic.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:oldDynamic.map(r => r.id)});
  }
  await syncCompatibilityRules(current.panes);
  if (injectOpenTabs) await injectIntoOpenTabs();
}

async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({url:["http://*/*","https://*/*"]});
  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) continue;
    try {
      await chrome.scripting.insertCSS({target:{tabId:tab.id}, files:["content/rail.css"]});
      await chrome.scripting.executeScript({target:{tabId:tab.id}, files:["content/rail.js"]});
    } catch {}
  }
}

async function ensureDefaults() {
  const current = await chrome.storage.local.get(["sites","panes","layout","schemaVersion"]);
  const sites = Array.isArray(current.sites) ? current.sites.map(upgradeSite).filter(Boolean) : structuredClone(DEFAULT_STATE.sites);
  const panes = current.panes ? {top:upgradePane(current.panes.top,"top"), bottom:upgradePane(current.panes.bottom,"bottom")} : structuredClone(DEFAULT_STATE.panes);
  const layout = current.layout && typeof current.layout === "object" ? {
    split:current.layout.split !== false,
    ratio:clamp(Number(current.layout.ratio) || .58,.20,.80),
    activePane:current.layout.activePane === "bottom" ? "bottom" : "top"
  } : structuredClone(DEFAULT_STATE.layout);
  await chrome.storage.local.set({sites,panes,layout,schemaVersion:STATE_SCHEMA_VERSION});
  return {sites,panes,layout};
}
function upgradeSite(site) {
  if (!site?.url) return null;
  const url = normalizeUrl(site.url); if (!url) return null;
  const inferred = inferDefaultsForUrl(url);
  const id = String(site.id || crypto.randomUUID());
  const builtin = DEFAULT_SITE_BY_ID.get(id);
  // Built-in shortcuts used Secure in early prototypes. Migrate them to Auto so
  // clicking a shortcut opens a working site by default. User-created shortcuts
  // keep the mode the user selected.
  const requestedMode = builtin ? builtin.mode : (site.mode || inferred.mode);
  const requestedDomains = Array.isArray(site.compatDomains) && site.compatDomains.length
    ? site.compatDomains
    : (builtin?.compatDomains?.length ? builtin.compatDomains : inferred.compatDomains);
  return {id, title:String(site.title || builtin?.title || url), url, mode:resolveAutoMode(url, normalizeMode(requestedMode)), compatDomains:normalizeCompatDomains(requestedDomains)};
}
function upgradePane(pane,name) {
  const fallback = DEFAULT_STATE.panes[name];
  if (!pane?.url) return structuredClone(fallback);
  const url = normalizeUrl(pane.url) || fallback.url;
  const inferred = inferDefaultsForUrl(url);
  return {url, title:String(pane.title || url), mode:resolveAutoMode(url, normalizeMode(pane.mode || inferred.mode)), compatDomains:normalizeCompatDomains(Array.isArray(pane.compatDomains) && pane.compatDomains.length ? pane.compatDomains : inferred.compatDomains), sourceSiteId:pane.sourceSiteId ? String(pane.sourceSiteId) : null};
}

async function syncCompatibilityRules(panes) {
  const domains = new Set();
  for (const pane of Object.values(panes || {})) {
    if (!paneNeedsCompatibility(pane)) continue;
    for (const domain of compatibilityDomainsForPane(pane)) domains.add(domain);
  }
  const existing = await chrome.declarativeNetRequest.getSessionRules();
  const removeRuleIds = existing.map(r => r.id);
  const addRules = [...domains].slice(0,100).map((domain,index) => ({
    id:SESSION_RULE_BASE + index,
    priority:10,
    action:{type:"modifyHeaders", responseHeaders:[
      {header:"x-frame-options",operation:"remove"},
      {header:"content-security-policy",operation:"remove"},
      {header:"content-security-policy-report-only",operation:"remove"}
    ]},
    condition:{
      initiatorDomains:[chrome.runtime.id],
      urlFilter:`||${domain}^`,
      resourceTypes:["sub_frame"]
    }
  }));
  await chrome.declarativeNetRequest.updateSessionRules({removeRuleIds,addRules});
  return {domains:[...domains], ruleIds:addRules.map(r=>r.id)};
}

function paneNeedsCompatibility(pane) {
  const mode = normalizeMode(pane?.mode);
  if (mode === "compat") return true;
  if (mode !== "auto") return false;
  // Auto is resolved before persistence in v0.2.4; keep this fallback for migrated state:
  // - a concrete YouTube video uses youtube-nocookie embed and needs no header stripping;
  // - any other HTTP(S) page gets compatibility only for that pane's configured/current domains.
  // Users can choose Secure explicitly for sensitive sites where CSP must remain untouched.
  if (youtubeVideoId(pane?.url)) return false;
  try {
    const u = new URL(pane?.url || "");
    return u.protocol === "http:" || u.protocol === "https:";
  } catch { return false; }
}
function youtubeVideoId(value) {
  try {
    const url = new URL(value); const host = url.hostname.replace(/^www\./,"").toLowerCase(); let id = null;
    if (host === "youtu.be") id = url.pathname.split("/").filter(Boolean)[0] || null;
    if (host === "youtube.com" || host.endsWith(".youtube.com")) {
      if (url.pathname === "/watch") id = url.searchParams.get("v");
      else { const match = url.pathname.match(/^\/(?:shorts|embed|live)\/([A-Za-z0-9_-]{6,})/); if (match) id = match[1]; }
    }
    return id && /^[A-Za-z0-9_-]{6,}$/.test(id) ? id : null;
  } catch { return null; }
}
function compatibilityDomainsForPane(pane) {
  const domains = normalizeCompatDomains(pane.compatDomains || []);
  try { const host = new URL(pane.url).hostname.toLowerCase(); if (host) domains.push(host); } catch {}
  return [...new Set(domains)];
}
function inferDefaultsForUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (host === "translate.yandex.ru" || host.endsWith(".translate.yandex.ru")) return {mode:"compat",compatDomains:["yandex.ru","ya.ru"]};
    if (host === "youtube.com" || host === "www.youtube.com" || host === "youtu.be" || host.endsWith(".youtube.com")) {
      return youtubeVideoId(url)
        ? {mode:"auto",compatDomains:YOUTUBE_COMPAT_DOMAINS}
        : {mode:"compat",compatDomains:YOUTUBE_COMPAT_DOMAINS};
    }
  } catch {}
  return {mode:"secure",compatDomains:[]};
}
function normalizeCompatDomains(values) {
  const result=[];
  for (const raw of values || []) {
    const text=String(raw||"").trim().toLowerCase(); if(!text) continue;
    try { const url=new URL(text.includes("://")?text:`https://${text.replace(/^\.+/,"")}`); const host=url.hostname.toLowerCase(); if(host && !result.includes(host)) result.push(host); } catch {}
    if(result.length>=20) break;
  }
  return result;
}
function resolveAutoMode(url, mode) {
  const normalized = normalizeMode(mode);
  if (normalized !== "auto") return normalized;
  return youtubeVideoId(url) ? "auto" : "compat";
}
function normalizeMode(mode) { return RENDER_MODES.has(mode) ? mode : "secure"; }
function normalizeUrl(value) {
  let input=String(value||"").trim(); if(!input) return null;
  if(!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(input)) input="https://"+input;
  try { const u=new URL(input); return ["http:","https:"].includes(u.protocol) ? u.href : null; } catch { return null; }
}

function findPaneForUrl(panes, url) {
  for (const name of ["top","bottom"]) {
    const current = panes?.[name]?.url;
    if (!current) continue;
    if (current === url) return name;
    try { if (new URL(current).origin === new URL(url).origin) return name; } catch {}
  }
  return null;
}
function clamp(v,min,max){return Math.min(max,Math.max(min,v));}

# App Tower Next v0.2.5 — interaction/lifecycle fix

## Fixes in this build

- Side Panel presence survives extension service-worker restarts through `chrome.storage.session`.
- The Side Panel reconnects its runtime port automatically after a service-worker restart. This prevents the external page rail from reappearing while the native Side Panel is still open.
- External and internal Settings buttons now use the same SVG icon.
- Built-in shortcuts (Yandex, Google, GitHub, YouTube) migrate to Auto, so selecting a shortcut resolves to a working Compatibility mode instead of unexpectedly opening in Secure mode.
- Normal click on a shortcut that is already open in either pane now activates that existing pane instead of replacing the other pane. Shift+Click still explicitly replaces/opens the bottom pane.
- One/two-pane layout was rewritten from the prototype grid rules to a simpler flex layout. Switching 2 → 1 keeps the active pane visible; switching back restores both panes.
- Both iframe panes explicitly delegate the `fullscreen` feature in addition to `allowfullscreen`.
- Embedded-scrollbar cleanup from v0.2.4 is retained.

## Install / update

Use a NEW empty folder for this ZIP. Do not merge files into an older source folder.

Because early v0.1/v0.2.1 builds did not use the current stable manifest key, open `edge://extensions` and make sure there is only ONE enabled **App Tower Next** extension. An older copy with a different extension ID can inject its own rail and look exactly like a duplicate panel.

Expected current development extension ID: `hkehhabineigjcpjgopbdhmgaiahgehk`.

After reloading the extension, refresh already-open web pages once (`Ctrl+R`) so old content-script DOM is removed.

## Shortcut behavior

- Click shortcut: if that site is already in top/bottom, activate that pane; otherwise replace the active pane using Auto.
- Shift+Click shortcut: explicitly open/replace the bottom pane and enable split mode.
- Auto ordinary page → Compatibility.
- Auto concrete YouTube video URL → official `youtube-nocookie.com/embed/...` renderer.
- S = Secure iframe; C = Compatibility; R = real top-level page.

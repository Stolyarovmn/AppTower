const RENDER_MODES = new Set(["auto", "secure", "compat", "real"]);

const DEFAULT_SITES = [
  {
    id: "yandex-translate",
    title: "Яндекс Переводчик",
    url: "https://translate.yandex.ru/",
    mode: "compat",
    compatDomains: ["yandex.ru", "ya.ru"]
  },
  {
    id: "google",
    title: "Google",
    url: "https://www.google.com/",
    mode: "secure",
    compatDomains: []
  },
  {
    id: "github",
    title: "GitHub",
    url: "https://github.com/",
    mode: "secure",
    compatDomains: []
  },
  {
    id: "youtube",
    title: "YouTube",
    url: "https://www.youtube.com/",
    mode: "auto",
    compatDomains: []
  }
];

const DEFAULT_STATE = {
  sites: DEFAULT_SITES,
  panes: {
    top: {
      url: "https://translate.yandex.ru/",
      title: "Яндекс Переводчик",
      mode: "compat",
      compatDomains: ["yandex.ru", "ya.ru"],
      sourceSiteId: "yandex-translate"
    },
    bottom: {
      url: "https://www.youtube.com/",
      title: "YouTube",
      mode: "auto",
      compatDomains: [],
      sourceSiteId: "youtube"
    }
  },
  layout: { split: true, ratio: 0.58, activePane: "top" }
};

let panelConnections = 0;

chrome.runtime.onInstalled.addListener(() => initialize().catch(console.error));
chrome.runtime.onStartup.addListener(() => initialize().catch(console.error));
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "ATN_SIDE_PANEL") return;
  panelConnections += 1;
  chrome.storage.local.set({ panelOpen: true }).catch(() => {});
  port.onDisconnect.addListener(() => {
    panelConnections = Math.max(0, panelConnections - 1);
    if (panelConnections === 0) chrome.storage.local.set({ panelOpen: false }).catch(() => {});
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.panes) {
    syncCompatibilityRules(changes.panes.newValue).catch(console.error);
  }
});

async function initialize() {
  const current = await ensureDefaults();
  await chrome.storage.local.set({ panelOpen: false });
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  await syncCompatibilityRules(current.panes);
}

async function ensureDefaults() {
  const current = await chrome.storage.local.get(["sites", "panes", "layout"]);

  const sites = Array.isArray(current.sites)
    ? current.sites.map(upgradeSite).filter(Boolean)
    : structuredClone(DEFAULT_STATE.sites);

  const panes = current.panes
    ? {
        top: upgradePane(current.panes.top, "top"),
        bottom: upgradePane(current.panes.bottom, "bottom")
      }
    : structuredClone(DEFAULT_STATE.panes);

  const layout = current.layout && typeof current.layout === "object"
    ? {
        split: current.layout.split !== false,
        ratio: clamp(Number(current.layout.ratio) || 0.58, 0.20, 0.80),
        activePane: current.layout.activePane === "bottom" ? "bottom" : "top"
      }
    : structuredClone(DEFAULT_STATE.layout);

  await chrome.storage.local.set({ sites, panes, layout });
  return { sites, panes, layout };
}

function upgradeSite(site) {
  if (!site || !site.url) return null;
  const url = normalizeUrl(site.url);
  if (!url) return null;
  const inferred = inferDefaultsForUrl(url);
  return {
    id: String(site.id || crypto.randomUUID()),
    title: String(site.title || url),
    url,
    mode: normalizeMode(site.mode || inferred.mode),
    compatDomains: normalizeCompatDomains(
      Array.isArray(site.compatDomains) && site.compatDomains.length
        ? site.compatDomains
        : inferred.compatDomains
    )
  };
}

function upgradePane(pane, name) {
  const fallback = DEFAULT_STATE.panes[name];
  if (!pane || !pane.url) return structuredClone(fallback);
  const url = normalizeUrl(pane.url) || fallback.url;
  const inferred = inferDefaultsForUrl(url);
  return {
    url,
    title: String(pane.title || url),
    mode: normalizeMode(pane.mode || inferred.mode),
    compatDomains: normalizeCompatDomains(
      Array.isArray(pane.compatDomains) && pane.compatDomains.length
        ? pane.compatDomains
        : inferred.compatDomains
    ),
    sourceSiteId: pane.sourceSiteId ? String(pane.sourceSiteId) : null
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;

  if (message.type === "OPEN_SITE") {
    const windowId = sender?.tab?.windowId;
    let openPromise = Promise.resolve();

    // Keep this call in the synchronous user-gesture portion of the handler.
    if (Number.isInteger(windowId)) {
      try {
        openPromise = chrome.sidePanel.open({ windowId });
      } catch (error) {
        openPromise = Promise.reject(error);
      }
    }

    (async () => {
      const current = await ensureDefaults();
      const panes = current.panes;
      const layout = current.layout;
      const targetPane = message.targetPane === "bottom" ? "bottom" : layout.activePane;
      const url = normalizeUrl(message.url);
      if (!url) throw new Error("Invalid URL");

      const inferred = inferDefaultsForUrl(url);
      panes[targetPane] = {
        url,
        title: String(message.title || url),
        mode: normalizeMode(message.mode || inferred.mode),
        compatDomains: normalizeCompatDomains(
          Array.isArray(message.compatDomains) && message.compatDomains.length
            ? message.compatDomains
            : inferred.compatDomains
        ),
        sourceSiteId: message.siteId ? String(message.siteId) : null
      };

      if (targetPane === "bottom") layout.split = true;
      layout.activePane = targetPane;

      await syncCompatibilityRules(panes);
      await chrome.storage.local.set({ panes, layout });
      await openPromise;
      sendResponse({ ok: true });
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));

    return true;
  }

  if (message.type === "OPEN_PANEL") {
    const windowId = sender?.tab?.windowId;
    let openPromise = Promise.resolve();

    if (Number.isInteger(windowId)) {
      try {
        openPromise = chrome.sidePanel.open({ windowId });
      } catch (error) {
        openPromise = Promise.reject(error);
      }
    }

    (async () => {
      await ensureDefaults();
      if (["add", "settings"].includes(message.intent)) {
        await chrome.storage.local.set({ pendingAction: { intent: message.intent, nonce: Date.now() } });
      }
      await openPromise;
      sendResponse({ ok: true });
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));

    return true;
  }

  if (message.type === "SYNC_COMPAT_RULES") {
    (async () => {
      const panes = message.panes || (await chrome.storage.local.get("panes")).panes;
      const result = await syncCompatibilityRules(panes);
      sendResponse({ ok: true, ...result });
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message.type === "GET_STATE") {
    (async () => {
      const current = await ensureDefaults();
      const extra = await chrome.storage.local.get(["panelOpen", "pendingAction"]);
      sendResponse({ ...current, ...extra });
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }
});

async function syncCompatibilityRules(panes) {
  const domains = new Set();

  for (const pane of Object.values(panes || {})) {
    if (!pane || normalizeMode(pane.mode) !== "compat") continue;
    for (const domain of compatibilityDomainsForPane(pane)) domains.add(domain);
  }

  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((rule) => rule.id);

  const addRules = [...domains].slice(0, 100).map((domain, index) => ({
    id: 20000 + index,
    priority: 1,
    action: {
      type: "modifyHeaders",
      responseHeaders: [
        { header: "x-frame-options", operation: "remove" },
        { header: "content-security-policy", operation: "remove" },
        { header: "content-security-policy-report-only", operation: "remove" }
      ]
    },
    condition: {
      initiatorDomains: [chrome.runtime.id],
      requestDomains: [domain],
      resourceTypes: ["sub_frame"]
    }
  }));

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  return { domains: [...domains] };
}

function compatibilityDomainsForPane(pane) {
  const domains = normalizeCompatDomains(pane.compatDomains || []);
  try {
    const host = new URL(pane.url).hostname;
    if (host) domains.push(host);
  } catch {}
  return [...new Set(domains)];
}

function inferDefaultsForUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (host === "translate.yandex.ru" || host.endsWith(".translate.yandex.ru")) {
      return { mode: "compat", compatDomains: ["yandex.ru", "ya.ru"] };
    }
    if (host === "youtube.com" || host === "www.youtube.com" || host === "youtu.be" || host.endsWith(".youtube.com")) {
      return { mode: "auto", compatDomains: [] };
    }
  } catch {}
  return { mode: "secure", compatDomains: [] };
}

function normalizeCompatDomains(values) {
  const result = [];
  for (const raw of values || []) {
    const text = String(raw || "").trim().toLowerCase();
    if (!text) continue;
    try {
      const url = new URL(text.includes("://") ? text : `https://${text.replace(/^\.+/, "")}`);
      const host = url.hostname.toLowerCase();
      if (host && !result.includes(host)) result.push(host);
    } catch {}
    if (result.length >= 20) break;
  }
  return result;
}

function normalizeMode(mode) {
  return RENDER_MODES.has(mode) ? mode : "secure";
}

function normalizeUrl(value) {
  let input = String(value || "").trim();
  if (!input) return null;
  if (!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(input)) input = "https://" + input;
  try {
    const url = new URL(input);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.href;
  } catch {
    return null;
  }
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

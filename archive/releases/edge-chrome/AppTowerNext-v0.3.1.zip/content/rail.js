(() => {
  if (window !== window.top) return;

  const INSTANCE = "__appTowerNextRail";
  for (const key of ["__appTowerNextRailV011","__appTowerNextRailV021","__appTowerNextRailV022","__appTowerNextRailV023","__appTowerNextRailV024","__appTowerNextRailV025",INSTANCE]) {
    try { globalThis[key]?.dispose?.(); } catch {}
  }

  const HOST_ID="app-tower-next-host";
  const RESERVED_CLASS="app-tower-next-reserved";
  const HIDDEN_CLASS="app-tower-next-hidden";
  const SCROLLBAR_RELOCATED_CLASS="app-tower-next-scrollbar-relocated";
  const FIXED_CLASS="app-tower-next-fixed";
  const FIXED_ANCHORED="app-tower-next-fixed-anchored";
  const FIXED_SHIFTED="app-tower-next-fixed-shifted";
  const ROOT_PADDING_VAR="--atn-original-root-padding-right";
  const FIXED_RIGHT_VAR="--atn-original-fixed-right";
  const RAIL_WIDTH=46;

  let disposed=false, visible=false, adjustmentFrame=null, railPort=null, reconnectTimer=null, relocatedScroll=null;
  const adjustedFixed=new Set();

  // Remove stale DOM/CSS state left by a previous unpacked build in this tab.
  document.getElementById(HOST_ID)?.remove();
  document.documentElement.classList.remove(RESERVED_CLASS,SCROLLBAR_RELOCATED_CLASS);
  document.documentElement.style.removeProperty(ROOT_PADDING_VAR);
  for (const el of document.querySelectorAll(`.${FIXED_CLASS}`)) {
    el.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);
    el.style.removeProperty(FIXED_RIGHT_VAR);
  }

  const host=document.createElement("aside");
  host.id=HOST_ID; host.className=HIDDEN_CLASS; host.setAttribute("aria-label","App Tower Next");
  const shadow=host.attachShadow({mode:"closed"});
  shadow.innerHTML=`<style>
    :host,*{box-sizing:border-box}
    .rail{width:46px;height:100%;display:flex;flex-direction:column;align-items:center;padding:0 4px 7px;overflow:hidden;color:#eee;background:#202020;border-left:1px solid rgba(255,255,255,.10);box-shadow:-3px 0 10px rgba(0,0,0,.20);pointer-events:auto;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
    button{all:unset;box-sizing:border-box}
    .rail-head{width:100%;height:44px;flex:0 0 44px;display:grid;place-items:center;border-bottom:1px solid rgba(255,255,255,.10)}
    .rail-primary{width:100%;min-height:0;flex:1 1 auto;display:flex;flex-direction:column;align-items:center;gap:5px;overflow-x:hidden;overflow-y:auto;scrollbar-width:none}
    .rail-primary::-webkit-scrollbar{display:none}
    .sites{width:100%;display:flex;flex-direction:column;align-items:center;gap:5px;flex:0 0 auto}
    .rail-footer{width:100%;display:flex;flex-direction:column;align-items:center;flex:0 0 auto}
    .site,.tool{width:36px;height:36px;flex:0 0 36px;display:grid;place-items:center;border-radius:8px;cursor:pointer;color:#ededed}
    .site:hover,.tool:hover,.site:focus-visible,.tool:focus-visible{background:rgba(255,255,255,.11)}
    .site:focus-visible,.tool:focus-visible{outline:2px solid #45c9bc;outline-offset:1px}
    .site img{width:25px;height:25px;object-fit:contain;border-radius:6px}
    .fallback{width:25px;height:25px;display:grid;place-items:center;border-radius:50%;background:#0f766e;color:white;font:700 12px/1 system-ui,sans-serif}
    .sep{width:28px;height:1px;flex:0 0 1px;margin:4px 0;background:rgba(255,255,255,.17)}
    .native-icon{font-family:"Segoe Fluent Icons","Segoe MDL2 Assets";font-size:20px;line-height:1;font-weight:400}
    .expand-tool.native-icon{font-size:15px;position:relative;transform:translateX(-1px)}
    .expand-tool.native-icon::after{content:"";position:absolute;right:5px;top:9px;width:1px;height:13px;background:currentColor;opacity:.68;border-radius:1px}
    .fallback-icon{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;font-size:21px;line-height:1}
  </style>
  <nav class="rail" aria-label="App Tower Next sites">
    <div class="rail-head"><div class="expand-slot"></div></div>
    <div class="rail-primary">
      <div class="sites"></div>
      <div class="sep"></div>
      <div class="add-slot"></div>
    </div>
    <div class="rail-footer"></div>
  </nav>`;
  document.documentElement.appendChild(host);
  const rail=shadow.querySelector(".rail");
  const expandSlot=shadow.querySelector(".expand-slot");
  const sitesHost=shadow.querySelector(".sites");
  const addSlot=shadow.querySelector(".add-slot");
  const footer=shadow.querySelector(".rail-footer");

  function faviconURL(url){const u=new URL("/_favicon/",chrome.runtime.getURL("/"));u.searchParams.set("pageUrl",url);u.searchParams.set("size","32");return u.href;}
  function fallback(title){const e=document.createElement("span");e.className="fallback";e.textContent=(title||"?").trim().slice(0,1).toUpperCase();return e;}
  function siteButton(site){
    const b=document.createElement("button");b.type="button";b.className="site";b.title=`${site.title}\nClick → active pane\nShift+Click → bottom pane`;
    const img=document.createElement("img");img.alt="";img.src=faviconURL(site.url);img.addEventListener("error",()=>img.replaceWith(fallback(site.title)),{once:true});b.append(img);
    b.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();chrome.runtime.sendMessage({type:"OPEN_SITE",url:site.url,title:site.title,mode:site.mode,compatDomains:site.compatDomains,siteId:site.id,targetPane:e.shiftKey?"bottom":undefined}).catch(()=>{});});
    return b;
  }
  function toolButton(kind,title,intent){
    const b=document.createElement("button");b.type="button";b.className="tool";b.title=title;
    const useFluent=Boolean(document.fonts?.check?.('16px "Segoe Fluent Icons"')||document.fonts?.check?.('16px "Segoe MDL2 Assets"'));
    const glyph=kind==="plus"?"\uE710":kind==="expand"?"\uE76B":"\uE713";
    const fallbackText=kind==="plus"?"＋":kind==="expand"?"‹|":"⚙";
    b.textContent=useFluent?glyph:fallbackText;
    b.classList.add(useFluent?"native-icon":"fallback-icon");
    if(kind==="expand")b.classList.add("expand-tool");
    b.addEventListener("click",e=>{
      e.preventDefault();e.stopPropagation();
      chrome.runtime.sendMessage({type:"OPEN_PANEL",intent}).catch(()=>{});
    });
    return b;
  }
  async function renderSites(){
    const {sites=[]}=await chrome.storage.local.get("sites");
    if(disposed)return;
    expandSlot.replaceChildren(toolButton("expand","Развернуть последнее состояние",null));
    sitesHost.replaceChildren();
    for(const s of sites)if(s?.url)sitesHost.append(siteButton(s));
    addSlot.replaceChildren(toolButton("plus","Добавить сайт","add"));
    footer.replaceChildren(toolButton("settings","Настройки · App Tower Next v0.3.1","settings"));
  }

  function clearFixedAdjustments(){
    for(const el of adjustedFixed){
      el.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);
      el.style.removeProperty(FIXED_RIGHT_VAR);
    }
    adjustedFixed.clear();
  }

  function fixedAncestor(element){
    for(let node=element;node&&node!==document.documentElement;node=node.parentElement){
      if(node===host)return null;
      const position=getComputedStyle(node).position;
      if(position==="fixed"||position==="sticky")return node;
    }
    return null;
  }

  function collectFixedAtRightEdge(){
    const found=new Set();
    const vw=window.innerWidth,vh=window.innerHeight;
    const xs=[Math.max(0,vw-2),Math.max(0,vw-RAIL_WIDTH-2)];
    const ys=[1,Math.max(1,vh-2)];

    for(const el of adjustedFixed){
      const rect=el.getBoundingClientRect();
      const position=el.isConnected?getComputedStyle(el).position:"";
      if(el.isConnected&&(position==="fixed"||position==="sticky")&&rect.width>0&&rect.height>0){
        found.add(el);
      }
    }

    for(let y=24;y<vh;y+=40)ys.push(y);
    for(const x of xs)for(const y of ys)for(const hit of document.elementsFromPoint(x,y)){
      const f=fixedAncestor(hit);
      if(!f)continue;
      const rect=f.getBoundingClientRect();
      if(rect.width>0&&rect.height>0&&rect.right>vw-RAIL_WIDTH&&rect.left<vw)found.add(f);
    }
    return found;
  }

  function adjustRightFixedElements(){
    adjustmentFrame=null;
    if(!visible){clearFixedAdjustments();return;}

    const next=collectFixedAtRightEdge();
    for(const old of adjustedFixed){
      if(!next.has(old)){
        old.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);
        old.style.removeProperty(FIXED_RIGHT_VAR);
      }
    }

    for(const el of next){
      if(adjustedFixed.has(el))continue;
      const cs=getComputedStyle(el);
      const right=cs.right;
      el.classList.add(FIXED_CLASS);
      if(right==="auto"){
        const rect=el.getBoundingClientRect();
        if(rect.width<window.innerWidth-RAIL_WIDTH){
          el.classList.add(FIXED_SHIFTED);
        }else{
          el.style.setProperty(FIXED_RIGHT_VAR,"0px");
          el.classList.add(FIXED_ANCHORED);
        }
      }else{
        el.style.setProperty(FIXED_RIGHT_VAR,right);
        el.classList.add(FIXED_ANCHORED);
      }
    }
    adjustedFixed.clear();
    for(const el of next)adjustedFixed.add(el);
  }

  function scheduleFixedAdjustment(){
    if(adjustmentFrame!==null)return;
    adjustmentFrame=requestAnimationFrame(adjustRightFixedElements);
  }

  function enableScrollbarRelocation(){
    if(!document.body||document.scrollingElement!==document.documentElement||document.documentElement.classList.contains(SCROLLBAR_RELOCATED_CLASS))return;
    relocatedScroll={x:window.scrollX,y:window.scrollY};
    document.documentElement.classList.add(SCROLLBAR_RELOCATED_CLASS);
    requestAnimationFrame(()=>{
      if(!visible||!relocatedScroll||!document.documentElement.classList.contains(SCROLLBAR_RELOCATED_CLASS))return;
      document.body.scrollLeft=relocatedScroll.x;
      document.body.scrollTop=relocatedScroll.y;
    });
  }

  function disableScrollbarRelocation(){
    if(!document.documentElement.classList.contains(SCROLLBAR_RELOCATED_CLASS)){
      relocatedScroll=null;
      return;
    }
    const scroll={
      x:document.body?.scrollLeft??relocatedScroll?.x??0,
      y:document.body?.scrollTop??relocatedScroll?.y??0
    };
    document.documentElement.classList.remove(SCROLLBAR_RELOCATED_CLASS);
    relocatedScroll=null;
    requestAnimationFrame(()=>window.scrollTo(scroll.x,scroll.y));
  }


  function setVisible(next){
    if(disposed)return;
    next=Boolean(next);
    if(next===visible)return;

    if(next&&!visible){
      document.documentElement.style.setProperty(ROOT_PADDING_VAR,getComputedStyle(document.documentElement).paddingRight);
    }

    visible=next;
    host.classList.toggle(HIDDEN_CLASS,!visible);

    if(visible){
      document.documentElement.classList.add(RESERVED_CLASS);
      enableScrollbarRelocation();
      scheduleFixedAdjustment();
    }else{
      disableScrollbarRelocation();
      document.documentElement.classList.remove(RESERVED_CLASS);
      if(adjustmentFrame!==null){cancelAnimationFrame(adjustmentFrame);adjustmentFrame=null;}
      clearFixedAdjustments();
      document.documentElement.style.removeProperty(ROOT_PADDING_VAR);
    }
  }

  chrome.storage.onChanged.addListener((changes,area)=>{if(area==="local"&&!disposed&&changes.sites)renderSites().catch(()=>{});});
  chrome.runtime.onMessage.addListener(message=>{if(!disposed&&message?.type==="ATN_SET_RAIL_VISIBLE")setVisible(message.visible);});
  window.addEventListener("resize",scheduleFixedAdjustment,{passive:true});window.addEventListener("scroll",scheduleFixedAdjustment,{passive:true});
  document.addEventListener("DOMContentLoaded",()=>{if(visible){enableScrollbarRelocation();scheduleFixedAdjustment();}},{once:true});
  // Watch structural changes only. Watching class/style attributes here creates a
  // self-observation loop because our own rail-adjustment classes/styles are mutations.
  // Scroll/resize already covers sticky-header state changes; childList covers new UI.
  const observer=new MutationObserver(scheduleFixedAdjustment);
  observer.observe(document.documentElement,{childList:true,subtree:true});

  function connectPort(){
    if(disposed||railPort)return;clearTimeout(reconnectTimer);
    try{
      const p=chrome.runtime.connect({name:"ATN_RAIL"});railPort=p;p.onMessage.addListener(m=>{if(m?.type==="ATN_RAIL_VISIBILITY")setVisible(m.visible);});p.onDisconnect.addListener(()=>{if(railPort===p)railPort=null;if(!disposed)reconnectTimer=setTimeout(connectPort,250);});
    }catch{reconnectTimer=setTimeout(connectPort,500);}
  }

  globalThis[INSTANCE]={dispose(){disposed=true;clearTimeout(reconnectTimer);try{railPort?.disconnect();}catch{}railPort=null;observer.disconnect();if(adjustmentFrame!==null)cancelAnimationFrame(adjustmentFrame);visible=false;disableScrollbarRelocation();clearFixedAdjustments();document.documentElement.classList.remove(RESERVED_CLASS,SCROLLBAR_RELOCATED_CLASS);document.documentElement.style.removeProperty(ROOT_PADDING_VAR);host.remove();}};

  // The normal startup state is collapsed. Reserve the rail from document_start
  // so page layout does not initially extend underneath it.
  setVisible(true);
  renderSites().catch(()=>{});connectPort();
  chrome.runtime.sendMessage({type:"GET_RAIL_VISIBILITY"}).then(r=>{if(!disposed)setVisible(r?.visible!==false);}).catch(()=>{});
})();

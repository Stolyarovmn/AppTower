import {
  THEME_MODE_KEY,
  ACCENT_MODE_KEY,
  ACCENT_COLOR_KEY,
  readThemeSettings,
  applyThemeToDocument,
  watchSystemTheme
} from "../shared/theme.js";

const rail = document.getElementById("nt-rail");
const sitesHost = document.getElementById("nt-sites");
let themeSettings = await readThemeSettings();
applyThemeToDocument(themeSettings);

watchSystemTheme(() => {
  if (themeSettings.themeMode === "system" || themeSettings.accentMode === "system") {
    applyThemeToDocument(themeSettings);
  }
});

function faviconURL(url) {
  const u = new URL("/_favicon/", chrome.runtime.getURL("/"));
  u.searchParams.set("pageUrl", url);
  u.searchParams.set("size", "32");
  return u.href;
}

function fallback(title) {
  const e = document.createElement("span");
  e.className = "fallback";
  e.textContent = (title || "?").trim().slice(0, 1).toUpperCase();
  return e;
}

async function windowId() {
  return (await chrome.windows.getCurrent()).id;
}

async function renderSites() {
  const { sites=[] } = await chrome.storage.local.get("sites");
  sitesHost.replaceChildren();

  for (const site of sites) {
    if (!site?.url) continue;

    const b = document.createElement("button");
    b.className = "site";
    b.title = site.title || site.url;

    const img = document.createElement("img");
    img.src = faviconURL(site.url);
    img.alt = "";
    img.addEventListener("error", () => img.replaceWith(fallback(site.title)), { once:true });
    b.append(img);

    b.addEventListener("click", async event => {
      const id = await windowId();
      chrome.runtime.sendMessage({
        type:"OPEN_SITE",
        windowId:id,
        url:site.url,
        title:site.title,
        mode:site.mode,
        compatDomains:site.compatDomains,
        siteId:site.id,
        targetPane:event.shiftKey ? "bottom" : undefined
      }).catch(() => {});
    });

    sitesHost.append(b);
  }
}

async function openPanel(intent) {
  const id = await windowId();
  chrome.runtime.sendMessage({ type:"OPEN_PANEL", windowId:id, intent }).catch(() => {});
}

document.getElementById("nt-expand").addEventListener("click", () => openPanel());
document.getElementById("nt-add").addEventListener("click", () => openPanel("add"));
document.getElementById("nt-settings").addEventListener("click", () => openPanel("settings"));
document.getElementById("nt-close").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type:"DISABLE_GLOBAL" }).catch(() => {});
});

chrome.storage.local.get(["atnEnabled"]).then(({ atnEnabled }) => {
  rail.classList.toggle("hidden", atnEnabled === false);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  if (changes.sites) renderSites();
  if (changes.atnEnabled) {
    rail.classList.toggle("hidden", changes.atnEnabled.newValue === false);
  }

  if (changes[THEME_MODE_KEY] || changes[ACCENT_MODE_KEY] || changes[ACCENT_COLOR_KEY]) {
    readThemeSettings().then(settings => {
      themeSettings = settings;
      applyThemeToDocument(settings);
    }).catch(() => {});
  }
});

renderSites();

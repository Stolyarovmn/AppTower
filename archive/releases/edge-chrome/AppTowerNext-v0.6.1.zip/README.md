# App Tower Next v0.6.1

Experimental Manifest V3 extension for Microsoft Edge and Google Chrome.

## v0.6.1 — unified appearance

App Tower now has one local appearance configuration shared by:
- expanded native Side Panel UI
- collapsed injected App Tower rail
- App Tower New Tab page

### Theme mode

Settings -> Appearance -> Theme:

- System
- Light
- Dark

`System` follows `prefers-color-scheme` and updates live when the operating
system/browser switches between light and dark appearance.

Manual Light/Dark selection overrides the OS preference for App Tower UI only.
Websites loaded in panes keep their own styling.

### Accent color

Settings -> Appearance -> Accent:

- System
- Custom color

In System mode App Tower asks the browser for the CSS system `AccentColor`.
If it is unavailable, App Tower falls back to its built-in teal accent.

Custom mode uses a native color picker. The chosen accent is applied to focus
rings, active rail state, primary actions, native checkboxes and theme preview.
Text contrast is derived from the resolved accent.

`Reset` restores:
- Theme: System
- Accent: System
- fallback custom color: `#45c9bc`

### Storage and backup

Theme settings are stored in `chrome.storage.local`.

They are intentionally not put in Browser Sync because System/Light/Dark and
desktop appearance can reasonably differ between devices.

JSON Export schema 4 includes:

```json
{
  "theme": {
    "mode": "system",
    "accentMode": "system",
    "accentColor": "#45c9bc"
  }
}
```

Older App Tower exports remain importable. If an older backup has no `theme`
section, the current local appearance is preserved.

## v0.6.0 — PWA-aware Auto

App Tower detects the standard Web App Manifest declared by normal web pages
without depending on Edge's deprecated PWA sidebar mechanism.

Auto priority:

1. Installed declarative App Tower module
2. PWA/App preference for a discovered Web App Manifest
3. Ordinary web iframe with scoped Compatibility when necessary

PWA App mode launches a top-level managed popup/sidecar through
`chrome.windows.create()` instead of loading the site in an iframe.

## Modules

Provider-specific integrations remain declarative modules rather than Core
JavaScript. The bundled catalog currently contains YouTube and Yandex Music.

Settings -> Modules supports installation/removal and validated JSON module
imports.

## Startup

The collapsed App Tower rail is injected at `document_start` on ordinary web
pages. App Tower also supplies its own New Tab page.

The browser-owned native Side Panel cannot be force-opened at browser startup;
`chrome.sidePanel.open()` still requires a user gesture.

## Install / update unpacked build

1. Extract the ZIP into a clean folder.
2. Open `edge://extensions` or `chrome://extensions`.
3. Enable Developer mode.
4. Load unpacked, or replace the files of the existing unpacked extension.
5. Press Reload for the extension.
6. Reload already-open HTTP/HTTPS tabs so the current rail/content scripts are
   injected into them.

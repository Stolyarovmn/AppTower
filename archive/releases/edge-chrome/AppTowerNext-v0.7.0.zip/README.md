# App Tower Next v0.7.0

Experimental Manifest V3 extension for Microsoft Edge and Google Chrome.

## v0.7.0 — shortcut organization

The App Tower rail is no longer a flat fixed-height shortcut list.

### Overflow and scrolling

The shortcut area is its own vertical scroll viewport.

Supported input:
- mouse wheel
- touchpad scrolling
- touchscreen / pen pan gesture
- explicit up/down buttons

The up/down buttons are hidden while every shortcut fits in the visible area.
When the list overflows, both buttons appear; the button at the reached edge is
disabled. The native scrollbar remains hidden to keep the 46 px rail clean.

The same behavior is implemented in:
- expanded Side Panel rail
- collapsed injected rail
- App Tower New Tab rail

### Groups

A new Group tool appears below Add.

A group has:
- a user-editable name
- a rail icon generated from the first one or two letters of that name
- child site/template shortcuts

Clicking a group opens its contents. Dropping a top-level shortcut onto an
existing group adds it to that group. Nested groups are intentionally not
supported in this version.

Groups can be renamed and dissolved back into top-level shortcuts.

### Pointer drag

Top-level shortcut organization uses Pointer Events instead of desktop-only
HTML drag/drop.

- Mouse: move after pointer-down to start dragging.
- Touch / pen: hold for about 360 ms, then drag.
- Normal touch movement before the hold threshold remains native vertical
  scrolling.

Drop zones:
- upper quarter of an icon: move before
- lower quarter: move after
- center: combine / add to group

On touch/pen, holding a Group or Template without moving opens its editor.

### Two-pane templates

Dropping one normal site shortcut onto another asks whether to create:
- a Group
- a two-pane Template

A Template contains exactly two site shortcuts:
- Top site
- Bottom site

By default the dragged shortcut becomes Top. The editor can swap Top/Bottom.
Clicking the template opens both panes at once and selects the top pane.

The template icon shows the two site favicons overlaid. The Top site's favicon
has the higher visual z-order, matching the pane it opens into.

Per-template overlap is adjustable from 20% to 80% (default 50%). The template
editor also supports rename, Top/Bottom swap and dissolving the template back
into two ordinary shortcuts.

Desktop: right-click a template to edit it.
Touch/pen: hold the template without moving to open the editor.

### Persistence

The historical `sites` storage key is retained for compatibility, but its
entries are now a shortcut tree:

```text
site

group
  site
  template

template
  top: site
  bottom: site
  overlap: 50
```

State schema is 12. Existing flat shortcuts are migrated to `kind: site`.

JSON Export schema 5 preserves groups and templates. Browser Sync schema 3 also
carries the shortcut tree.

## Existing v0.6.x features

- unified System / Light / Dark theme
- system or custom accent color
- modular Auto renderer
- installable declarative provider modules
- PWA-aware Auto / top-level sidecar launcher
- split panes
- persistent collapsed App Tower rail at `document_start`
- App Tower New Tab

## Install / update unpacked build

1. Extract the ZIP into a clean folder, or replace the files in the current
   unpacked extension directory.
2. Open `edge://extensions` or `chrome://extensions`.
3. Press Reload on App Tower Next.
4. Reload already-open HTTP/HTTPS tabs so the updated collapsed rail is injected.

# App Tower Next v0.2.7

Changes in this build:

- A click, focus, or keyboard interaction inside an embedded cross-origin site now activates that pane.
- Keeps all v0.2.6 rail geometry / split / compatibility behavior.
- Documents Chromium credential-autofill limitation for cross-origin iframes.
- No attempt is made to bypass the browser password manager security boundary.

## Side-panel width

The public `chrome.sidePanel` extension API does not expose a width/default-width setter. Chromium owns the side-panel width and remembers a user-resized width for a panel entry. Set the preferred width once by dragging the native panel divider.

## Password autofill

The websites inside Secure/Compatibility panes are cross-origin iframes under an `extension://` top-level document. Chromium intentionally does not fill credentials across frames. Use Real Page for logins that must use the browser's built-in password manager.

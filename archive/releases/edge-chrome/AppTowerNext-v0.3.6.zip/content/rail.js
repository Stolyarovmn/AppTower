(() => {
  if (window !== window.top) return;

  const INSTANCE = "__appTowerNextRail";
  for (const key of ["__appTowerNextRailV011","__appTowerNextRailV021","__appTowerNextRailV022","__appTowerNextRailV023","__appTowerNextRailV024","__appTowerNextRailV025",INSTANCE]) {
    try { globalThis[key]?.dispose?.(); } catch {}
  }

  const HOST_ID="app-tower-next-host";
  const RESERVED_CLASS="app-tower-next-reserved";
  const HIDDEN_CLASS="app-tower-next-hidden";
  const FIXED_CLASS="app-tower-next-fixed";
  const FIXED_ANCHORED="app-tower-next-fixed-anchored";
  const FIXED_SHIFTED="app-tower-next-fixed-shifted";
  const NATIVE_SCROLLBAR_VAR="--atn-native-scrollbar-width";
  const FIXED_RIGHT_VAR="--atn-original-fixed-right";
  const RAIL_WIDTH=46;

  let disposed=false, visible=false, adjustmentFrame=null, geometryFrame=null,
      railPort=null, reconnectTimer=null;
  const adjustedFixed=new Set();

  // Remove stale DOM/CSS state left by a previous unpacked build in this tab.
  document.getElementById(HOST_ID)?.remove();
  document.documentElement.classList.remove(RESERVED_CLASS,"app-tower-next-scrollbar-relocated");
  document.documentElement.style.removeProperty(NATIVE_SCROLLBAR_VAR);
  for (const el of document.querySelectorAll(`.${FIXED_CLASS}`)) {
    el.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);
    el.style.removeProperty(FIXED_RIGHT_VAR);
  }

  const host=document.createElement("aside");
  host.id=HOST_ID; host.className=HIDDEN_CLASS; host.setAttribute("aria-label","App Tower Next");
  const shadow=host.attachShadow({mode:"closed"});
  shadow.innerHTML=`<style>
    :host,*{box-sizing:border-box}
    .rail{
      width:46px;height:100%;display:flex;flex-direction:column;align-items:center;
      padding:0 4px 7px;overflow:hidden;color:#eee;background:#202020;
      border-left:1px solid rgba(255,255,255,.10);
      box-shadow:-3px 0 10px rgba(0,0,0,.20);
      pointer-events:auto;font-family:system-ui,-apple-system,"Segoe UI",sans-serif
    }
    button{all:unset;box-sizing:border-box}

    /*
     * Mirrors the native Side Panel title row. This keeps the collapsed rail
     * from jumping upward when the native panel is closed.
     */
    .rail-chrome{
      width:100%;height:56px;flex:0 0 56px;display:grid;place-items:center;
      border-bottom:1px solid rgba(255,255,255,.10)
    }

    /*
     * Same 44 px control row as the expanded side panel. The short separator
     * is drawn INSIDE the row at bottom:0, so it aligns with the main header
     * without adding extra vertical margin.
     */
    .rail-head{
      width:100%;height:44px;flex:0 0 44px;display:grid;place-items:center;
      position:relative
    }
    .rail-head::after{
      content:"";position:absolute;left:50%;bottom:0;transform:translateX(-50%);
      width:28px;height:1px;background:rgba(255,255,255,.17)
    }

    .rail-primary{
      width:100%;min-height:0;flex:1 1 auto;display:flex;flex-direction:column;
      align-items:center;gap:5px;overflow-x:hidden;overflow-y:auto;scrollbar-width:none
    }
    .rail-primary::-webkit-scrollbar{display:none}
    .sites{width:100%;display:flex;flex-direction:column;align-items:center;gap:5px;flex:0 0 auto}
    .rail-footer{width:100%;display:flex;flex-direction:column;align-items:center;flex:0 0 auto}
    .site,.tool{
      width:36px;height:36px;flex:0 0 36px;display:grid;place-items:center;
      border-radius:8px;cursor:pointer;color:#ededed
    }
    .site:hover,.tool:hover,.site:focus-visible,.tool:focus-visible{background:rgba(255,255,255,.11)}
    .site:focus-visible,.tool:focus-visible{outline:2px solid #45c9bc;outline-offset:1px}
    .site img{width:25px;height:25px;object-fit:contain;border-radius:6px}
    .fallback{
      width:25px;height:25px;display:grid;place-items:center;border-radius:50%;
      background:#0f766e;color:white;font:700 12px/1 system-ui,sans-serif
    }

    /* Bottom separator: last shortcut -> Add. */
    .sep{width:28px;height:1px;flex:0 0 1px;margin:4px 0;background:rgba(255,255,255,.17)}

    .native-icon{
      font-family:"Segoe Fluent Icons","Segoe MDL2 Assets";
      font-size:20px;line-height:1;font-weight:400
    }
    .toggle-svg{width:16px;height:16px;display:block;overflow:visible;margin:auto}
    .toggle-svg path{fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}
    .close-tool{
      position:relative;color:#ededed
    }
    .close-tool::before,.close-tool::after{
      content:"";position:absolute;left:50%;top:50%;
      width:14px;height:1.5px;border-radius:1px;background:currentColor;
      transform-origin:center
    }
    .close-tool::before{transform:translate(-50%,-50%) rotate(45deg)}
    .close-tool::after{transform:translate(-50%,-50%) rotate(-45deg)}
    .fallback-icon{
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;font-size:21px;line-height:1
    }
  </style>
  <nav class="rail" aria-label="App Tower Next sites">
    <div class="rail-chrome"><div class="close-slot"></div></div>
    <div class="rail-head"><div class="expand-slot"></div></div>
    <div class="rail-primary">
      <div class="sites"></div>
      <div class="sep"></div>
      <div class="add-slot"></div>
    </div>
    <div class="rail-footer"></div>
  </nav>`;
  document.documentElement.appendChild(host);
  const rail=shadow.querySelector(".rail");
  const closeSlot=shadow.querySelector(".close-slot");
  const expandSlot=shadow.querySelector(".expand-slot");
  const sitesHost=shadow.querySelector(".sites");
  const addSlot=shadow.querySelector(".add-slot");
  const footer=shadow.querySelector(".rail-footer");

  function faviconURL(url){const u=new URL("/_favicon/",chrome.runtime.getURL("/"));u.searchParams.set("pageUrl",url);u.searchParams.set("size","32");return u.href;}
  function fallback(title){const e=document.createElement("span");e.className="fallback";e.textContent=(title||"?").trim().slice(0,1).toUpperCase();return e;}
  function siteButton(site){
    const b=document.createElement("button");b.type="button";b.className="site";b.title=`${site.title}\nClick → active pane\nShift+Click → bottom pane`;
    const img=document.createElement("img");img.alt="";img.src=faviconURL(site.url);img.addEventListener("error",()=>img.replaceWith(fallback(site.title)),{once:true});b.append(img);
    b.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();chrome.runtime.sendMessage({type:"OPEN_SITE",url:site.url,title:site.title,mode:site.mode,compatDomains:site.compatDomains,siteId:site.id,targetPane:e.shiftKey?"bottom":undefined}).catch(()=>{});});
    return b;
  }
  function toolButton(kind,title,intent){
    const b=document.createElement("button");
    b.type="button";
    b.className="tool";
    b.title=title;

    const useFluent=Boolean(
      document.fonts?.check?.('16px "Segoe Fluent Icons"') ||
      document.fonts?.check?.('16px "Segoe MDL2 Assets"')
    );

    if(kind==="expand"){
      b.innerHTML='<svg class="toggle-svg" viewBox="0 0 16 16" aria-hidden="true"><path d="M10.25 3.5 5.75 8l4.5 4.5"/></svg>';
    }else if(kind==="close"){
      b.textContent="";
      b.classList.add("close-tool");
    }else{
      const glyph=kind==="plus"?"\uE710":"\uE713";
      const fallbackText=kind==="plus"?"＋":"⚙";
      b.textContent=useFluent?glyph:fallbackText;
      b.classList.add(useFluent?"native-icon":"fallback-icon");
    }

    b.addEventListener("click",e=>{
      e.preventDefault();
      e.stopPropagation();

      if(kind==="close"){
        chrome.runtime.sendMessage({ type:"DISABLE_GLOBAL" }).catch(()=>{});
        return;
      }

      chrome.runtime.sendMessage({type:"OPEN_PANEL",intent}).catch(()=>{});
    });
    return b;
  }
  async function renderSites(){
    const {sites=[]}=await chrome.storage.local.get("sites");
    if(disposed)return;
    closeSlot.replaceChildren(toolButton("close","Отключить App Tower",null));
    expandSlot.replaceChildren(toolButton("expand","Развернуть последнее состояние",null));
    sitesHost.replaceChildren();
    for(const s of sites)if(s?.url)sitesHost.append(siteButton(s));
    addSlot.replaceChildren(toolButton("plus","Добавить текущую страницу","add"));
    footer.replaceChildren(toolButton("settings","Настройки · App Tower Next v0.3.6","settings"));
  }

  function clearFixedAdjustments(){
    for(const el of adjustedFixed){
      el.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);
      el.style.removeProperty(FIXED_RIGHT_VAR);
    }
    adjustedFixed.clear();
  }

  function fixedAncestor(element){
    for(let node=element;node&&node!==document.documentElement;node=node.parentElement){
      if(node===host)return null;
      const position=getComputedStyle(node).position;
      if(position==="fixed"||position==="sticky")return node;
    }
    return null;
  }

  function collectFixedAtRightEdge(){
    const found=new Set();
    const vw=document.documentElement.clientWidth || window.innerWidth;
    const vh=window.innerHeight;
    const xs=[Math.max(0,vw-2),Math.max(0,vw-RAIL_WIDTH-2)];
    const ys=[1,Math.max(1,vh-2)];

    for(const el of adjustedFixed){
      const rect=el.getBoundingClientRect();
      const position=el.isConnected?getComputedStyle(el).position:"";
      if(el.isConnected&&(position==="fixed"||position==="sticky")&&rect.width>0&&rect.height>0){
        found.add(el);
      }
    }

    for(let y=24;y<vh;y+=40)ys.push(y);
    for(const x of xs)for(const y of ys)for(const hit of document.elementsFromPoint(x,y)){
      const f=fixedAncestor(hit);
      if(!f)continue;
      const rect=f.getBoundingClientRect();
      if(rect.width>0&&rect.height>0&&rect.right>vw-RAIL_WIDTH&&rect.left<vw)found.add(f);
    }
    return found;
  }

  function adjustRightFixedElements(){
    adjustmentFrame=null;
    if(!visible){clearFixedAdjustments();return;}

    const vw=document.documentElement.clientWidth || window.innerWidth;
    const next=collectFixedAtRightEdge();
    for(const old of adjustedFixed){
      if(!next.has(old)){
        old.classList.remove(FIXED_CLASS,FIXED_ANCHORED,FIXED_SHIFTED);
        old.style.removeProperty(FIXED_RIGHT_VAR);
      }
    }

    for(const el of next){
      if(adjustedFixed.has(el))continue;
      const cs=getComputedStyle(el);
      const right=cs.right;
      el.classList.add(FIXED_CLASS);
      if(right==="auto"){
        const rect=el.getBoundingClientRect();
        if(rect.width<vw-RAIL_WIDTH){
          el.classList.add(FIXED_SHIFTED);
        }else{
          el.style.setProperty(FIXED_RIGHT_VAR,"0px");
          el.classList.add(FIXED_ANCHORED);
        }
      }else{
        el.style.setProperty(FIXED_RIGHT_VAR,right);
        el.classList.add(FIXED_ANCHORED);
      }
    }
    adjustedFixed.clear();
    for(const el of next)adjustedFixed.add(el);
  }

  function scheduleFixedAdjustment(){
    if(adjustmentFrame!==null)return;
    adjustmentFrame=requestAnimationFrame(adjustRightFixedElements);
  }


  function nativeScrollbarWidth(){
    const client=document.documentElement.clientWidth;
    if(!client) return 0;
    return Math.max(0, window.innerWidth-client);
  }

  function updateRailGeometry(){
    geometryFrame=null;
    if(disposed||!visible)return;
    document.documentElement.style.setProperty(
      NATIVE_SCROLLBAR_VAR,
      `${nativeScrollbarWidth()}px`
    );
    scheduleFixedAdjustment();
  }

  function scheduleGeometry(){
    if(geometryFrame!==null)return;
    geometryFrame=requestAnimationFrame(updateRailGeometry);
  }

  function setVisible(next){
    if(disposed)return;
    next=Boolean(next);


    if(next===visible)return;


    visible=next;
    host.classList.toggle(HIDDEN_CLASS,!visible);

    if(visible){
      document.documentElement.classList.add(RESERVED_CLASS);
      updateRailGeometry();
      scheduleGeometry();
      setTimeout(scheduleGeometry, 80);
      setTimeout(scheduleGeometry, 300);
    }else{
      document.documentElement.classList.remove(RESERVED_CLASS);
          document.documentElement.style.removeProperty(NATIVE_SCROLLBAR_VAR);
      if(adjustmentFrame!==null){cancelAnimationFrame(adjustmentFrame);adjustmentFrame=null;}
      if(geometryFrame!==null){cancelAnimationFrame(geometryFrame);geometryFrame=null;}
      clearFixedAdjustments();
    }
  }

  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=="local"||disposed)return;
    if(changes.sites)renderSites().catch(()=>{});
    if(changes.atnEnabled){
      if(changes.atnEnabled.newValue===false)setVisible(false);
    }
  });
  chrome.runtime.onMessage.addListener(message=>{
    if(disposed||message?.type!=="ATN_SET_RAIL_VISIBLE")return;
    setVisible(message.visible);
  });
  window.addEventListener("resize",scheduleGeometry,{passive:true});
  window.addEventListener("scroll",scheduleFixedAdjustment,{passive:true});
  document.addEventListener("DOMContentLoaded",()=>{
    if(visible){
      scheduleGeometry();
      scheduleFixedAdjustment();
    }
  },{once:true});
  // Watch structural changes only. Watching class/style attributes here creates a
  // self-observation loop because our own rail-adjustment classes/styles are mutations.
  // Scroll/resize already covers sticky-header state changes; childList covers new UI.
  const observer=new MutationObserver(()=>{
    scheduleGeometry();
    scheduleFixedAdjustment();
  });
  observer.observe(document.documentElement,{childList:true,subtree:true});

  function connectPort(){
    if(disposed||railPort)return;clearTimeout(reconnectTimer);
    try{
      const p=chrome.runtime.connect({name:"ATN_RAIL"});railPort=p;
      p.onMessage.addListener(m=>{
        if(m?.type!=="ATN_RAIL_VISIBILITY")return;
        setVisible(m.visible);
      });p.onDisconnect.addListener(()=>{if(railPort===p)railPort=null;if(!disposed)reconnectTimer=setTimeout(connectPort,250);});
    }catch{reconnectTimer=setTimeout(connectPort,500);}
  }

  globalThis[INSTANCE]={dispose(){
    disposed=true;
    clearTimeout(reconnectTimer);
    try{railPort?.disconnect();}catch{}
    railPort=null;
    observer.disconnect();
    if(adjustmentFrame!==null)cancelAnimationFrame(adjustmentFrame);
    if(geometryFrame!==null)cancelAnimationFrame(geometryFrame);
    visible=false;
    clearFixedAdjustments();
    document.documentElement.classList.remove(RESERVED_CLASS,"app-tower-next-scrollbar-relocated");
      document.documentElement.style.removeProperty(NATIVE_SCROLLBAR_VAR);
    host.remove();
  }};

  // Read the persistent global enable switch first. When enabled, this still
  // runs at document_start; when globally disabled, no rail/reserved width
  // flashes briefly during browser startup.
  chrome.storage.local.get("atnEnabled").then(({atnEnabled}) => {
    if(disposed) return;
    if(atnEnabled === false) {
      setVisible(false);
      return;
    }

    document.documentElement.style.setProperty(
      NATIVE_SCROLLBAR_VAR,
      `${nativeScrollbarWidth()}px`
    );
    setVisible(true);
  }).catch(() => {
    if(!disposed) setVisible(true);
  });

  renderSites().catch(()=>{});
  connectPort();

  chrome.runtime.sendMessage({type:"GET_RAIL_VISIBILITY"}).then(r=>{
    if(!disposed) setVisible(r?.visible!==false);
  }).catch(()=>{});
})();

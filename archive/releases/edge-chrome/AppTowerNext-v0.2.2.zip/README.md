# App Tower Next v0.2.2 — clean test build

This build fixes two development-update problems seen in v0.2.1:

1. The page rail could remain visible while the native Side Panel was open.
2. Repeated visibility messages could reserve another 46px each time, progressively shrinking the page and making scrollbars/layout look broken.

## Important: install this build CLEAN

Do **not** unpack v0.2.2 over v0.2.1.

1. In `edge://extensions` / `chrome://extensions`, remove the old **App Tower Next** test extension.
2. Extract `AppTowerNext-v0.2.2.zip` into a new empty folder.
3. Load that folder with **Load unpacked**.
4. Refresh already-open web pages once (`Ctrl+R`).

Starting with v0.2.2 the manifest contains a stable public extension key. Future unpacked builds can be placed in a new folder without changing the extension ID, as long as this key is preserved.

Expected development extension ID: `hkehhabineigjcpjgopbdhmgaiahgehk`.

## v0.2.2 changes

- Rail visibility is tracked per browser window.
- Uses native `chrome.sidePanel.onOpened/onClosed` when available.
- Side Panel and page rail also keep explicit runtime ports as a fallback.
- The page rail self-cleans stale DOM/classes from earlier App Tower Next builds.
- On install/update the service worker injects the current rail into already-open HTTP/HTTPS tabs, so stale development DOM is replaced without relying only on navigation.
- Fixed width reservation: original page padding is captured only on a hidden→visible transition, so repeated messages cannot stack 46px reservations.
- Moves the document scrollbar before the 46px rail when the document root owns scrolling, then restores it when the rail is hidden.
- Compatibility rules now use session-scoped DNR rules and anchored domain filters such as `||youtube.com/`.
- Expanded the YouTube compatibility domain set.
- Old dynamic compatibility rules are cleared at startup.

## Current limitation

Embedded sites are still real cross-origin pages inside iframes. A site can have its own nested scroll containers; the extension cannot directly restyle those cross-origin scrollbars. If Yandex/YouTube still shows awkward internal horizontal scrolling after this clean build, the next step is a per-pane **Fit/Mobile** rendering mode rather than more global CSS hacks.

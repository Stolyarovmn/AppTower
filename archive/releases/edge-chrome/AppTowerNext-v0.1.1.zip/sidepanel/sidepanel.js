const panelPort = chrome.runtime.connect({ name: "ATN_SIDE_PANEL" });

const state = {
  sites: [],
  panes: {
    top: { url: "https://translate.yandex.ru/", title: "Яндекс Переводчик" },
    bottom: { url: "https://www.youtube.com/", title: "YouTube" }
  },
  layout: { split: true, ratio: 0.58, activePane: "top" },
  focus: null
};

const workspace = document.getElementById("workspace");
const splitter = document.getElementById("splitter");
const toggleSplit = document.getElementById("toggle-split");
const addSite = document.getElementById("add-site");
const panelSites = document.getElementById("panel-sites");
const railAdd = document.getElementById("rail-add");
const railSettings = document.getElementById("rail-settings");

const siteDialog = document.getElementById("site-dialog");
const siteForm = document.getElementById("site-form");
const titleInput = document.getElementById("site-title");
const siteUrlInput = document.getElementById("site-url");

const settingsDialog = document.getElementById("settings-dialog");
const settingsSingle = document.getElementById("settings-single");
const settingsResetSplit = document.getElementById("settings-reset-split");

const paneEls = {
  top: document.querySelector('.pane[data-pane="top"]'),
  bottom: document.querySelector('.pane[data-pane="bottom"]')
};

await loadState();
renderAll();
await consumePendingAction();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  let rerender = false;
  if (changes.panes) {
    state.panes = changes.panes.newValue || state.panes;
    rerender = true;
  }
  if (changes.layout) {
    state.layout = changes.layout.newValue || state.layout;
    rerender = true;
  }
  if (changes.sites) {
    state.sites = changes.sites.newValue || [];
    renderPanelRail();
  }
  if (changes.pendingAction?.newValue) {
    handlePendingAction(changes.pendingAction.newValue).catch(() => {});
  }

  if (rerender) renderAll();
});

async function loadState() {
  const stored = await chrome.storage.local.get([
    "sites", "panes", "layout", "pendingAction"
  ]);
  if (Array.isArray(stored.sites)) state.sites = stored.sites;
  if (stored.panes) state.panes = stored.panes;
  if (stored.layout) state.layout = stored.layout;
}

function renderAll() {
  state.layout.ratio = clamp(Number(state.layout.ratio) || 0.58, 0.20, 0.80);
  workspace.style.setProperty("--split-y", `${state.layout.ratio * 100}%`);

  workspace.classList.toggle("split", !!state.layout.split && !state.focus);
  workspace.classList.toggle("focus-top", state.focus === "top");
  workspace.classList.toggle("focus-bottom", state.focus === "bottom");

  for (const name of ["top", "bottom"]) {
    const el = paneEls[name];
    const paneState = state.panes[name] || { url: "about:blank", title: "" };
    const input = el.querySelector('[data-role="url"]');
    const frame = el.querySelector('[data-role="frame"]');

    el.classList.toggle("active", state.layout.activePane === name);

    if (document.activeElement !== input) input.value = paneState.url || "";

    if (frame.dataset.current !== paneState.url) {
      frame.dataset.current = paneState.url;
      frame.src = paneState.url || "about:blank";
    }
  }

  renderPanelRail();
}

function faviconURL(url) {
  const favicon = new URL("/_favicon/", chrome.runtime.getURL("/"));
  favicon.searchParams.set("pageUrl", url);
  favicon.searchParams.set("size", "32");
  return favicon.href;
}

function fallback(title) {
  const el = document.createElement("span");
  el.className = "rail-fallback";
  el.textContent = (title || "?").trim().slice(0, 1).toUpperCase();
  return el;
}

function renderPanelRail() {
  panelSites.replaceChildren();

  const activeUrl = state.panes[state.layout.activePane]?.url || "";

  for (const site of state.sites) {
    if (!site?.url) continue;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "rail-site";
    button.title = `${site.title}\nClick → active pane\nShift+Click → bottom pane`;

    if (sameOriginOrUrl(activeUrl, site.url)) button.classList.add("active");

    const img = document.createElement("img");
    img.alt = "";
    img.src = faviconURL(site.url);
    img.addEventListener("error", () => img.replaceWith(fallback(site.title)), { once: true });
    button.append(img);

    button.addEventListener("click", async (event) => {
      await openSite(site, event.shiftKey ? "bottom" : state.layout.activePane);
    });

    panelSites.append(button);
  }
}

async function openSite(site, targetPane) {
  const paneName = targetPane === "bottom" ? "bottom" : "top";
  const url = normalizeUrl(site.url);
  if (!url) return;

  state.panes[paneName] = {
    url,
    title: site.title || url
  };
  state.layout.activePane = paneName;
  if (paneName === "bottom") state.layout.split = true;
  state.focus = null;

  await chrome.storage.local.set({
    panes: state.panes,
    layout: state.layout
  });

  renderAll();
}

for (const [name, el] of Object.entries(paneEls)) {
  el.addEventListener("pointerdown", () => activatePane(name), { passive: true });

  el.querySelector('[data-action="activate"]').addEventListener("click", () => activatePane(name));
  el.querySelector('[data-action="go"]').addEventListener("click", () => navigateFromInput(name));

  el.querySelector('[data-role="url"]').addEventListener("keydown", (event) => {
    if (event.key === "Enter") navigateFromInput(name);
  });

  el.querySelector('[data-action="reload"]').addEventListener("click", () => {
    const frame = el.querySelector('[data-role="frame"]');
    const current = state.panes[name]?.url || "about:blank";
    frame.src = "about:blank";
    requestAnimationFrame(() => {
      frame.src = current;
    });
  });

  el.querySelector('[data-action="external"]').addEventListener("click", async () => {
    const url = state.panes[name]?.url;
    if (isHttpUrl(url)) await chrome.tabs.create({ url });
  });

  el.querySelector('[data-action="focus"]').addEventListener("click", () => {
    state.focus = state.focus === name ? null : name;
    renderAll();
  });
}

async function activatePane(name) {
  if (state.layout.activePane === name) return;
  state.layout.activePane = name;
  await persistLayout();
  renderAll();
}

async function navigateFromInput(name) {
  const input = paneEls[name].querySelector('[data-role="url"]');
  const url = normalizeUrl(input.value);

  if (!url) {
    input.select();
    return;
  }

  state.panes[name] = { url, title: url };
  state.layout.activePane = name;
  state.focus = null;

  await chrome.storage.local.set({
    panes: state.panes,
    layout: state.layout
  });

  renderAll();
}

toggleSplit.addEventListener("click", async () => {
  state.focus = null;
  state.layout.split = !state.layout.split;
  await persistLayout();
  renderAll();
});

function openAddSiteDialog() {
  titleInput.value = "";
  siteUrlInput.value = "https://";
  if (!siteDialog.open) siteDialog.showModal();
  setTimeout(() => titleInput.focus(), 0);
}

function openSettingsDialog() {
  if (!settingsDialog.open) settingsDialog.showModal();
}

addSite.addEventListener("click", openAddSiteDialog);
railAdd.addEventListener("click", openAddSiteDialog);
railSettings.addEventListener("click", openSettingsDialog);

siteForm.addEventListener("submit", async (event) => {
  const submitter = event.submitter;
  if (!submitter || submitter.value === "cancel") return;

  event.preventDefault();

  const title = titleInput.value.trim();
  const url = normalizeUrl(siteUrlInput.value);

  if (!title || !url) return;

  state.sites = [
    ...state.sites,
    {
      id: crypto.randomUUID(),
      title,
      url
    }
  ];

  await chrome.storage.local.set({ sites: state.sites });
  siteDialog.close();
  renderPanelRail();
});

settingsSingle.addEventListener("click", async () => {
  state.focus = null;
  state.layout.split = false;
  await persistLayout();
  renderAll();
  settingsDialog.close();
});

settingsResetSplit.addEventListener("click", async () => {
  state.focus = null;
  state.layout.split = true;
  state.layout.ratio = 0.58;
  await persistLayout();
  renderAll();
  settingsDialog.close();
});

let dragging = false;

splitter.addEventListener("pointerdown", (event) => {
  if (!state.layout.split) return;

  dragging = true;
  splitter.setPointerCapture(event.pointerId);
  document.body.style.userSelect = "none";
});

splitter.addEventListener("pointermove", (event) => {
  if (!dragging) return;

  const rect = workspace.getBoundingClientRect();
  state.layout.ratio = clamp(
    (event.clientY - rect.top) / rect.height,
    0.20,
    0.80
  );

  workspace.style.setProperty("--split-y", `${state.layout.ratio * 100}%`);
});

splitter.addEventListener("pointerup", async (event) => {
  if (!dragging) return;

  dragging = false;
  document.body.style.userSelect = "";

  try {
    splitter.releasePointerCapture(event.pointerId);
  } catch {}

  await persistLayout();
});

splitter.addEventListener("dblclick", async () => {
  state.layout.ratio = 0.5;
  await persistLayout();
  renderAll();
});

splitter.addEventListener("keydown", async (event) => {
  if (event.key !== "ArrowUp" && event.key !== "ArrowDown") return;

  event.preventDefault();
  state.layout.ratio = clamp(
    state.layout.ratio + (event.key === "ArrowDown" ? 0.03 : -0.03),
    0.20,
    0.80
  );

  await persistLayout();
  renderAll();
});

async function persistLayout() {
  await chrome.storage.local.set({ layout: state.layout });
}

async function consumePendingAction() {
  const { pendingAction } = await chrome.storage.local.get("pendingAction");
  if (pendingAction) await handlePendingAction(pendingAction);
}

async function handlePendingAction(action) {
  if (!action?.intent) return;

  if (action.intent === "add") openAddSiteDialog();
  if (action.intent === "settings") openSettingsDialog();

  await chrome.storage.local.remove("pendingAction");
}

function normalizeUrl(value) {
  let input = String(value || "").trim();
  if (!input) return null;
  if (!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(input)) input = "https://" + input;

  try {
    const url = new URL(input);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.href;
  } catch {
    return null;
  }
}

function isHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

function sameOriginOrUrl(a, b) {
  if (!a || !b) return false;
  if (a === b) return true;

  try {
    return new URL(a).origin === new URL(b).origin;
  } catch {
    return false;
  }
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

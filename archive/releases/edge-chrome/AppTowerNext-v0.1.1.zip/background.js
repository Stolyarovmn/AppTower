const DEFAULT_SITES = [
  { id: "yandex-translate", title: "Яндекс Переводчик", url: "https://translate.yandex.ru/" },
  { id: "google", title: "Google", url: "https://www.google.com/" },
  { id: "github", title: "GitHub", url: "https://github.com/" },
  { id: "youtube", title: "YouTube", url: "https://www.youtube.com/" }
];

const DEFAULT_STATE = {
  sites: DEFAULT_SITES,
  panes: {
    top: { url: "https://translate.yandex.ru/", title: "Яндекс Переводчик" },
    bottom: { url: "https://www.youtube.com/", title: "YouTube" }
  },
  layout: {
    split: true,
    ratio: 0.58,
    activePane: "top"
  }
};

let panelConnections = 0;

async function ensureDefaults() {
  const current = await chrome.storage.local.get(["sites", "panes", "layout"]);
  const patch = {};
  if (!Array.isArray(current.sites)) patch.sites = DEFAULT_STATE.sites;
  if (!current.panes) patch.panes = DEFAULT_STATE.panes;
  if (!current.layout) patch.layout = DEFAULT_STATE.layout;
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
}

async function initialize() {
  await ensureDefaults();
  await chrome.storage.local.set({ panelOpen: false });
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}

chrome.runtime.onInstalled.addListener(() => {
  initialize().catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  initialize().catch(console.error);
});

chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch(() => {});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "ATN_SIDE_PANEL") return;

  panelConnections += 1;
  chrome.storage.local.set({ panelOpen: true }).catch(() => {});

  port.onDisconnect.addListener(() => {
    panelConnections = Math.max(0, panelConnections - 1);
    if (panelConnections === 0) {
      chrome.storage.local.set({ panelOpen: false }).catch(() => {});
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;

  if (message.type === "OPEN_SITE") {
    const windowId = sender?.tab?.windowId;

    let openPromise = Promise.resolve();
    if (Number.isInteger(windowId)) {
      try {
        openPromise = chrome.sidePanel.open({ windowId });
      } catch (error) {
        openPromise = Promise.reject(error);
      }
    }

    (async () => {
      await ensureDefaults();

      const stored = await chrome.storage.local.get(["panes", "layout"]);
      const panes = stored.panes || structuredClone(DEFAULT_STATE.panes);
      const layout = stored.layout || structuredClone(DEFAULT_STATE.layout);

      let targetPane = message.targetPane || layout.activePane || "top";
      if (targetPane !== "top" && targetPane !== "bottom") targetPane = "top";

      const url = normalizeUrl(message.url);
      if (!url) throw new Error("Invalid URL");

      panes[targetPane] = {
        url,
        title: String(message.title || url)
      };

      if (targetPane === "bottom") layout.split = true;
      layout.activePane = targetPane;

      await chrome.storage.local.set({ panes, layout });
      await openPromise;
      sendResponse({ ok: true });
    })().catch((error) => {
      sendResponse({ ok: false, error: String(error?.message || error) });
    });

    return true;
  }

  if (message.type === "OPEN_PANEL") {
    const windowId = sender?.tab?.windowId;

    let openPromise = Promise.resolve();
    if (Number.isInteger(windowId)) {
      try {
        openPromise = chrome.sidePanel.open({ windowId });
      } catch (error) {
        openPromise = Promise.reject(error);
      }
    }

    (async () => {
      await ensureDefaults();
      if (message.intent === "add" || message.intent === "settings") {
        await chrome.storage.local.set({
          pendingAction: {
            intent: message.intent,
            nonce: Date.now()
          }
        });
      }
      await openPromise;
      sendResponse({ ok: true });
    })().catch((error) => {
      sendResponse({ ok: false, error: String(error?.message || error) });
    });

    return true;
  }

  if (message.type === "GET_STATE") {
    (async () => {
      await ensureDefaults();
      const stored = await chrome.storage.local.get([
        "sites", "panes", "layout", "panelOpen", "pendingAction"
      ]);
      sendResponse(stored);
    })().catch((error) => {
      sendResponse({ ok: false, error: String(error?.message || error) });
    });
    return true;
  }
});

function normalizeUrl(value) {
  let input = String(value || "").trim();
  if (!input) return null;
  if (!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(input)) input = "https://" + input;

  try {
    const url = new URL(input);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.href;
  } catch {
    return null;
  }
}

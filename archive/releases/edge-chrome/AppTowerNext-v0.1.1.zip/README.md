# App Tower Next v0.1.1

Test build for Microsoft Edge and Google Chrome (Manifest V3).

## Fixed in 0.1.1

- The collapsed 46 px App Tower now reserves page width instead of simply
  covering the right edge of the site.
- Common `position: fixed` controls anchored to the right edge are shifted left
  while the collapsed rail is visible.
- Clicking a rail icon now calls `chrome.sidePanel.open()` before any async
  storage work so Chromium keeps the required user gesture.
- When the native Side Panel opens, the page-injected rail hides and an
  equivalent App Tower is rendered on the far-right inside the Side Panel.
- `+` and Settings now have working dialogs.

## Current functionality

- Native `chrome.sidePanel`.
- Collapsed 46 px App Tower on ordinary HTTP/HTTPS pages.
- Expanded layout: `[web panes | App Tower]`.
- Browser favicons through Chromium's built-in `_favicon` endpoint.
- Click a rail icon: open it in the active pane.
- Shift+Click: open it in the bottom pane and enable split mode.
- One-pane / two-pane layout.
- Horizontal draggable splitter; double-click = 50/50.
- Focus button (`□`) temporarily expands one pane.
- URL field, reload and open-as-normal-tab (`↗`) per pane.
- Add custom sites.
- Local persistence with `chrome.storage.local`.
- System light/dark theme.

## Security baseline

The web panes are still `iframe`s because public Chromium Side Panel APIs host
an extension page rather than arbitrary top-level web contents.

This build DOES NOT remove CSP or X-Frame-Options.

If a site refuses to embed, click `↗` to open it as a normal browser tab.

## Install / upgrade in Edge

1. Extract this ZIP into a permanent folder.
2. Open `edge://extensions`.
3. Enable **Developer mode**.
4. If v0.1.0 is already loaded:
   - remove it, OR replace the files in its folder with this build and press
     **Reload** on the extension card.
5. Click **Load unpacked** if needed.
6. Select the folder containing `manifest.json`.
7. Refresh already-open web pages once so the new content script is injected.

## Install / upgrade in Chrome

Use the same procedure at `chrome://extensions`.

## Known v0.1.1 limitations

- Width reservation is implemented from a content script. Very unusual sites
  with custom full-screen/fixed layouts can still require site-specific
  adjustments.
- Panel-open state is global in this prototype; multiple simultaneous browser
  windows are not yet independently tracked.
- Some websites cannot be embedded because of their security/authentication
  policy.
- Site edit/delete/reorder is planned for the next iteration.

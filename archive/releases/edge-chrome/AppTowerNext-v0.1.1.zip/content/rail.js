(() => {
  if (window !== window.top) return;

  const INSTANCE = "__appTowerNextRailV011";
  globalThis[INSTANCE]?.dispose?.();

  const HOST_ID = "app-tower-next-host";
  const RESERVED_CLASS = "app-tower-next-reserved";
  const HIDDEN_CLASS = "app-tower-next-hidden";
  const FIXED_CLASS = "app-tower-next-fixed";
  const FIXED_ANCHORED = "app-tower-next-fixed-anchored";
  const FIXED_SHIFTED = "app-tower-next-fixed-shifted";
  const ROOT_PADDING_VAR = "--atn-original-root-padding-right";
  const FIXED_RIGHT_VAR = "--atn-original-fixed-right";
  const RAIL_WIDTH = 46;

  let disposed = false;
  let adjustmentFrame = null;
  const adjustedFixed = new Set();

  document.getElementById(HOST_ID)?.remove();
  document.documentElement.classList.remove(RESERVED_CLASS);
  document.documentElement.style.removeProperty(ROOT_PADDING_VAR);

  const host = document.createElement("aside");
  host.id = HOST_ID;
  host.classList.add(HIDDEN_CLASS);
  host.setAttribute("aria-label", "App Tower Next");

  const shadow = host.attachShadow({ mode: "closed" });
  shadow.innerHTML = `
    <style>
      :host, * { box-sizing: border-box; }
      .rail {
        width: 46px;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 5px;
        padding: 7px 4px;
        overflow-x: hidden;
        overflow-y: auto;
        scrollbar-width: none;
        color: #eeeeee;
        background: #202020;
        border-left: 1px solid rgba(255,255,255,.10);
        box-shadow: -3px 0 10px rgba(0,0,0,.20);
        pointer-events: auto;
        font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
      }
      .rail::-webkit-scrollbar { display:none; }
      button {
        all: unset;
        box-sizing: border-box;
      }
      .site, .tool {
        width: 36px;
        height: 36px;
        flex: 0 0 36px;
        display: grid;
        place-items: center;
        border-radius: 8px;
        cursor: pointer;
        color: #ededed;
      }
      .site:hover, .tool:hover,
      .site:focus-visible, .tool:focus-visible {
        background: rgba(255,255,255,.11);
      }
      .site:focus-visible, .tool:focus-visible {
        outline: 2px solid #45c9bc;
        outline-offset: 1px;
      }
      .site img {
        width: 25px;
        height: 25px;
        object-fit: contain;
        border-radius: 6px;
      }
      .fallback {
        width: 25px;
        height: 25px;
        display: grid;
        place-items: center;
        border-radius: 50%;
        background: #0f766e;
        color: white;
        font: 700 12px/1 system-ui, sans-serif;
      }
      .spacer { flex: 1 1 auto; min-height: 10px; }
      .sep {
        width: 28px;
        height: 1px;
        flex: 0 0 1px;
        margin: 4px 0;
        background: rgba(255,255,255,.17);
      }
      .tool svg {
        width: 23px;
        height: 23px;
        fill: none;
        stroke: currentColor;
        stroke-width: 1.8;
        stroke-linecap: round;
        stroke-linejoin: round;
      }
    </style>
    <nav class="rail" aria-label="App Tower Next sites"></nav>
  `;

  document.documentElement.appendChild(host);
  const rail = shadow.querySelector(".rail");

  globalThis[INSTANCE] = {
    dispose() {}
  };

  function faviconURL(url) {
    const favicon = new URL("/_favicon/", chrome.runtime.getURL("/"));
    favicon.searchParams.set("pageUrl", url);
    favicon.searchParams.set("size", "32");
    return favicon.href;
  }

  function fallback(title) {
    const el = document.createElement("span");
    el.className = "fallback";
    el.textContent = (title || "?").trim().slice(0, 1).toUpperCase();
    return el;
  }

  function siteButton(site) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "site";
    button.title = `${site.title}\nClick → active pane\nShift+Click → bottom pane`;

    const img = document.createElement("img");
    img.alt = "";
    img.src = faviconURL(site.url);
    img.addEventListener("error", () => img.replaceWith(fallback(site.title)), { once: true });
    button.append(img);

    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();

      chrome.runtime.sendMessage({
        type: "OPEN_SITE",
        url: site.url,
        title: site.title,
        targetPane: event.shiftKey ? "bottom" : undefined
      }).catch(() => {});
    });

    return button;
  }

  function toolButton(kind, title, intent) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "tool";
    button.title = title;
    button.innerHTML = kind === "plus"
      ? `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>`
      : `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.6 1.6 0 0 0 .32 1.76l.08.08-2.96 2.96-.08-.08A1.6 1.6 0 0 0 15 19.4a1.6 1.6 0 0 0-1 .58 1.6 1.6 0 0 0-.4 1.02V21H9.4v-.02A1.6 1.6 0 0 0 8 19.4a1.6 1.6 0 0 0-1.76.32l-.08.08-2.96-2.96.08-.08A1.6 1.6 0 0 0 3.6 15a1.6 1.6 0 0 0-.58-1A1.6 1.6 0 0 0 2 13.6V9.4h.02A1.6 1.6 0 0 0 3.6 8a1.6 1.6 0 0 0-.32-1.76l-.08-.08L6.16 3.2l.08.08A1.6 1.6 0 0 0 8 3.6a1.6 1.6 0 0 0 1-.58A1.6 1.6 0 0 0 9.4 2H13.6v.02A1.6 1.6 0 0 0 15 3.6a1.6 1.6 0 0 0 1.76-.32l.08-.08 2.96 2.96-.08.08A1.6 1.6 0 0 0 19.4 8a1.6 1.6 0 0 0 .58 1A1.6 1.6 0 0 0 21 9.4V13.6h-.02A1.6 1.6 0 0 0 19.4 15Z"/></svg>`;

    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      chrome.runtime.sendMessage({ type: "OPEN_PANEL", intent }).catch(() => {});
    });

    return button;
  }

  async function renderSites() {
    const { sites = [] } = await chrome.storage.local.get("sites");
    if (disposed) return;

    rail.replaceChildren();
    for (const site of sites) {
      if (site?.url) rail.append(siteButton(site));
    }

    const spacer = document.createElement("div");
    spacer.className = "spacer";
    rail.append(spacer);

    const sep = document.createElement("div");
    sep.className = "sep";
    rail.append(sep);

    rail.append(
      toolButton("plus", "Add site", "add"),
      toolButton("settings", "Settings", "settings")
    );
  }

  function clearFixedAdjustments() {
    for (const element of adjustedFixed) {
      element.classList.remove(FIXED_CLASS, FIXED_ANCHORED, FIXED_SHIFTED);
      element.style.removeProperty(FIXED_RIGHT_VAR);
    }
    adjustedFixed.clear();
  }

  function fixedAncestor(element) {
    for (let node = element; node && node !== document.documentElement; node = node.parentElement) {
      if (node === host) return null;
      if (getComputedStyle(node).position === "fixed") return node;
    }
    return null;
  }

  function collectFixedAtRightEdge() {
    const found = new Set();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const xs = [
      Math.max(0, vw - 2),
      Math.max(0, vw - RAIL_WIDTH - 2)
    ];

    const ys = [2, Math.max(2, vh - 2)];
    for (let y = 24; y < vh; y += 64) ys.push(y);

    for (const x of xs) {
      for (const y of ys) {
        for (const hit of document.elementsFromPoint(x, y)) {
          const fixed = fixedAncestor(hit);
          if (!fixed) continue;

          const rect = fixed.getBoundingClientRect();
          if (
            rect.width > 0 &&
            rect.height > 0 &&
            rect.right > vw - RAIL_WIDTH &&
            rect.left < vw
          ) {
            found.add(fixed);
          }
        }
      }
    }

    return found;
  }

  function adjustRightFixedElements() {
    adjustmentFrame = null;
    if (host.classList.contains(HIDDEN_CLASS)) {
      clearFixedAdjustments();
      return;
    }

    const next = collectFixedAtRightEdge();

    for (const old of [...adjustedFixed]) {
      if (!next.has(old)) {
        old.classList.remove(FIXED_CLASS, FIXED_ANCHORED, FIXED_SHIFTED);
        old.style.removeProperty(FIXED_RIGHT_VAR);
        adjustedFixed.delete(old);
      }
    }

    for (const element of next) {
      if (adjustedFixed.has(element)) continue;

      const computed = getComputedStyle(element);
      element.classList.add(FIXED_CLASS);

      if (computed.right && computed.right !== "auto") {
        element.style.setProperty(FIXED_RIGHT_VAR, computed.right);
        element.classList.add(FIXED_ANCHORED);
      } else {
        element.classList.add(FIXED_SHIFTED);
      }

      adjustedFixed.add(element);
    }
  }

  function scheduleFixedAdjustment() {
    if (adjustmentFrame !== null) return;
    adjustmentFrame = requestAnimationFrame(adjustRightFixedElements);
  }

  function setVisible(visible) {
    if (disposed) return;
    const show = Boolean(visible);

    if (show) {
      document.documentElement.style.setProperty(
        ROOT_PADDING_VAR,
        getComputedStyle(document.documentElement).paddingRight
      );
      document.documentElement.classList.add(RESERVED_CLASS);
      host.classList.remove(HIDDEN_CLASS);
      scheduleFixedAdjustment();
    } else {
      host.classList.add(HIDDEN_CLASS);
      document.documentElement.classList.remove(RESERVED_CLASS);
      document.documentElement.style.removeProperty(ROOT_PADDING_VAR);
      clearFixedAdjustments();
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || disposed) return;
    if (changes.sites) renderSites().catch(() => {});
    if (changes.panelOpen) setVisible(!changes.panelOpen.newValue);
  });

  window.addEventListener("resize", scheduleFixedAdjustment, { passive: true });
  window.addEventListener("scroll", scheduleFixedAdjustment, { passive: true });

  const mutationObserver = new MutationObserver(() => scheduleFixedAdjustment());
  mutationObserver.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "style"]
  });

  globalThis[INSTANCE].dispose = () => {
    disposed = true;
    mutationObserver.disconnect();
    if (adjustmentFrame !== null) cancelAnimationFrame(adjustmentFrame);
    clearFixedAdjustments();
    document.documentElement.classList.remove(RESERVED_CLASS);
    document.documentElement.style.removeProperty(ROOT_PADDING_VAR);
    host.remove();
  };

  Promise.all([
    renderSites(),
    chrome.storage.local.get("panelOpen")
  ]).then(([, stored]) => {
    if (!disposed) setVisible(!stored.panelOpen);
  }).catch(() => {
    if (!disposed) setVisible(true);
  });
})();

# App Tower Next v0.1.0

Test build for Microsoft Edge and Google Chrome (Manifest V3).

## Implemented
- Native `chrome.sidePanel`.
- 46 px App Tower rail on ordinary HTTP/HTTPS pages.
- Chromium built-in favicons (`_favicon`), no external favicon service.
- Click = active pane; Shift+Click = bottom pane.
- One/two-pane layout with draggable horizontal splitter; double-click = 50/50.
- Focus a pane with `□`.
- URL field, reload, open normal tab (`↗`).
- Add custom sites (`+`).
- Local persistence with `chrome.storage.local`.
- System light/dark theme.

## Important limitation
The two web panes are iframes inside the native browser Side Panel. Some sites refuse embedding via X-Frame-Options, CSP frame-ancestors, authentication policy, third-party-cookie policy, or JavaScript. This build intentionally DOES NOT strip CSP or X-Frame-Options. Use `↗` when a site refuses to embed.

## Install Edge
1. Extract ZIP to a permanent folder.
2. Open `edge://extensions`.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select the folder containing `manifest.json`.
6. Open an ordinary website; the right rail should appear.
7. Click a rail icon or the extension toolbar icon.

## Install Chrome
Same, using `chrome://extensions`.

## Permissions
- `sidePanel`: native Chromium side panel.
- `storage`: local state only.
- `favicon`: browser-provided site favicons.
- Static HTTP/HTTPS content-script matches: used only to inject the App Tower rail on ordinary web pages.

No telemetry, analytics, remote code, sync or cloud backend is included.

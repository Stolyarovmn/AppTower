const DEFAULT_SITES = [
  { id: "yandex-translate", title: "Яндекс Переводчик", url: "https://translate.yandex.ru/" },
  { id: "google", title: "Google", url: "https://www.google.com/" },
  { id: "github", title: "GitHub", url: "https://github.com/" },
  { id: "youtube", title: "YouTube", url: "https://www.youtube.com/" }
];
const DEFAULT_STATE = {
  sites: DEFAULT_SITES,
  panes: {
    top: { url: "https://translate.yandex.ru/", title: "Яндекс Переводчик" },
    bottom: { url: "https://www.youtube.com/", title: "YouTube" }
  },
  layout: { split: true, ratio: 0.58, activePane: "top" }
};
async function ensureDefaults() {
  const current = await chrome.storage.local.get(["sites", "panes", "layout"]);
  const patch = {};
  if (!Array.isArray(current.sites)) patch.sites = DEFAULT_STATE.sites;
  if (!current.panes) patch.panes = DEFAULT_STATE.panes;
  if (!current.layout) patch.layout = DEFAULT_STATE.layout;
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
}
chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaults();
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});
chrome.runtime.onStartup.addListener(ensureDefaults);
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;
  if (message.type === "OPEN_SITE") {
    (async () => {
      await ensureDefaults();
      const state = await chrome.storage.local.get(["panes", "layout"]);
      const panes = state.panes || structuredClone(DEFAULT_STATE.panes);
      const layout = state.layout || structuredClone(DEFAULT_STATE.layout);
      let targetPane = message.targetPane || layout.activePane || "top";
      if (targetPane !== "top" && targetPane !== "bottom") targetPane = "top";
      panes[targetPane] = { url: normalizeUrl(message.url), title: message.title || message.url };
      if (targetPane === "bottom") layout.split = true;
      layout.activePane = targetPane;
      await chrome.storage.local.set({ panes, layout });
      const windowId = sender?.tab?.windowId;
      if (Number.isInteger(windowId)) await chrome.sidePanel.open({ windowId });
      sendResponse({ ok: true });
    })().catch(error => sendResponse({ ok:false, error:String(error) }));
    return true;
  }
  if (message.type === "OPEN_PANEL") {
    (async () => {
      await ensureDefaults();
      const windowId = sender?.tab?.windowId;
      if (Number.isInteger(windowId)) await chrome.sidePanel.open({ windowId });
      sendResponse({ ok:true });
    })().catch(error => sendResponse({ ok:false, error:String(error) }));
    return true;
  }
});
function normalizeUrl(value) {
  let input = String(value || "").trim();
  if (!input) return "about:blank";
  if (!/^[a-zA-Z][a-zA-Z\\d+.-]*:/.test(input)) input = "https://" + input;
  try {
    const u = new URL(input);
    return (u.protocol === "http:" || u.protocol === "https:") ? u.href : "about:blank";
  } catch { return "about:blank"; }
}

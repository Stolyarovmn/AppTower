const __atnWindow = await chrome.windows.getCurrent();
let __atnPanelPort = null;
let __atnPanelReconnectTimer = null;
function __atnConnectPanelPort() {
  clearTimeout(__atnPanelReconnectTimer);
  if (__atnPanelPort) return;
  try {
    const port = chrome.runtime.connect({ name: `ATN_SIDE_PANEL:${__atnWindow.id}` });
    __atnPanelPort = port;
    port.onDisconnect.addListener(() => {
      if (__atnPanelPort === port) __atnPanelPort = null;
      __atnPanelReconnectTimer = setTimeout(__atnConnectPanelPort, 120);
    });
  } catch {
    __atnPanelReconnectTimer = setTimeout(__atnConnectPanelPort, 300);
  }
}
__atnConnectPanelPort();

const MODE_ORDER = ["auto", "secure", "compat", "real"];
const MODE_META = {
  auto: { label: "A", title: "Auto: default mode; chooses a compact media renderer when available, otherwise scoped Compatibility" },
  secure: { label: "S", title: "Secure: normal iframe, security headers unchanged" },
  compat: { label: "C", title: "Compatibility: remove frame-blocking headers for configured domains" },
  real: { label: "R", title: "Real Page: top-level page in separate browser window/tab" }
};

const state = {
  sites: [],
  panes: {
    top: { url:"", title:"", mode:"auto", compatDomains:[], sourceSiteId:null },
    bottom: { url:"", title:"", mode:"auto", compatDomains:[], sourceSiteId:null }
  },
  layout: { split:false, ratio:0.58, activePane:"top" },
  focus: null,
  syncEnabled: false
};

const workspace = document.getElementById("workspace");
const homeView = document.getElementById("home-view");
const homeAddCurrent = document.getElementById("home-add-current");
const homeAddCustom = document.getElementById("home-add-custom");
const homeImport = document.getElementById("home-import");
const homeSync = document.getElementById("home-sync");
const splitter = document.getElementById("splitter");
const collapsePanelButton = document.getElementById("collapse-panel");
const toggleSplit = document.getElementById("toggle-split");
const panelSites = document.getElementById("panel-sites");
const railAdd = document.getElementById("rail-add");
const railSettings = document.getElementById("rail-settings");
const siteDialog = document.getElementById("site-dialog");
const siteForm = document.getElementById("site-form");
const titleInput = document.getElementById("site-title");
const siteUrlInput = document.getElementById("site-url");
const siteMode = document.getElementById("site-mode");
const compatDomainsRow = document.getElementById("compat-domains-row");
const siteCompatDomains = document.getElementById("site-compat-domains");
const settingsDialog = document.getElementById("settings-dialog");
const settingsSingle = document.getElementById("settings-single");
const settingsResetSplit = document.getElementById("settings-reset-split");
const settingsCollapse = document.getElementById("settings-collapse");
const cancelSite = document.getElementById("cancel-site");
const clearSite = document.getElementById("clear-site");
const settingsSync = document.getElementById("settings-sync");
const settingsExport = document.getElementById("settings-export");
const settingsImport = document.getElementById("settings-import");
const importFile = document.getElementById("import-file");
const importDialog = document.getElementById("import-dialog");
const importSummary = document.getElementById("import-summary");
const importMerge = document.getElementById("import-merge");
const importReplace = document.getElementById("import-replace");
let pendingImport = null;

const paneEls = {
  top: document.querySelector('.pane[data-pane="top"]'),
  bottom: document.querySelector('.pane[data-pane="bottom"]')
};

const hasFluentIcons = Boolean(document.fonts?.check?.('16px "Segoe Fluent Icons"') || document.fonts?.check?.('16px "Segoe MDL2 Assets"'));
document.documentElement.classList.toggle("no-fluent-icons", !hasFluentIcons);

const EMBED_INIT_MESSAGE = "ATN_EMBED_INIT_V025";
const EMBED_INTERACTION_MESSAGE = "ATN_EMBED_INTERACTION_V027";

// Pointer/focus events inside a cross-origin iframe do not bubble into the
// extension page. The all-frames content script bridges those interactions via
// postMessage so clicking/typing in a website selects the pane naturally.
window.addEventListener("message", (event) => {
  if (event.data?.type !== EMBED_INTERACTION_MESSAGE) return;
  for (const [name, pane] of Object.entries(paneEls)) {
    const frames = pane.querySelectorAll('iframe[data-role="frame"], iframe[data-role="media-frame"]');
    for (const frame of frames) {
      if (event.source === frame?.contentWindow) {
        activatePane(name).catch(() => {});
        return;
      }
    }
  }
});
for (const pane of Object.values(paneEls)) {
  for (const frame of pane.querySelectorAll('iframe[data-role="frame"], iframe[data-role="media-frame"]')) {
    frame.addEventListener("load", () => {
      try { frame.contentWindow?.postMessage({ type:EMBED_INIT_MESSAGE }, "*"); } catch {}
      setTimeout(() => {
        try { frame.contentWindow?.postMessage({ type:EMBED_INIT_MESSAGE }, "*"); } catch {}
      }, 250);
    });
  }
}

// A blocked iframe (X-Frame-Options/CSP error document) never runs our
// all-frames content script, so the postMessage bridge above cannot fire.
// Chromium still focuses the <iframe> element itself when the user clicks that
// error surface. Detect that focus transition and activate the pane normally.
function activatePaneFromFocusedFrame() {
  const active = document.activeElement;
  for (const [name, pane] of Object.entries(paneEls)) {
    for (const frame of pane.querySelectorAll('iframe[data-role="frame"], iframe[data-role="media-frame"]')) {
      if (active === frame) {
        activatePane(name).catch(() => {});
        return true;
      }
    }
  }
  return false;
}

window.addEventListener("blur", () => {
  // activeElement is updated just after the blur event in Chromium.
  queueMicrotask(activatePaneFromFocusedFrame);
  setTimeout(activatePaneFromFocusedFrame, 0);
}, true);

document.addEventListener("focusin", () => {
  activatePaneFromFocusedFrame();
}, true);

for (const [name, pane] of Object.entries(paneEls)) {
  for (const frame of pane.querySelectorAll('iframe[data-role="frame"], iframe[data-role="media-frame"]')) {
    frame.addEventListener("focus", () => activatePane(name).catch(() => {}));
  }
}

await loadState();
await syncCompatRules();
renderAll();
await consumePendingAction();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  let rerender = false;
  if (changes.panes) { state.panes = changes.panes.newValue || state.panes; rerender = true; }
  if (changes.layout) { state.layout = changes.layout.newValue || state.layout; rerender = true; }
  if (changes.sites) { state.sites = changes.sites.newValue || []; rerender = true; }
  if (changes.atnSyncEnabled) { state.syncEnabled = changes.atnSyncEnabled.newValue === true; updateSyncControls(); }
  if (changes.pendingAction?.newValue) handlePendingAction(changes.pendingAction.newValue).catch(() => {});
  if (rerender) renderAll();
});

async function loadState() {
  const response = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  if (response?.sites) state.sites = response.sites;
  if (response?.panes) state.panes = response.panes;
  if (response?.layout) state.layout = response.layout;
  state.syncEnabled = response?.syncEnabled === true;
  updateSyncControls();
}

function renderAll(forceReload = false) {
  const onboarding = state.sites.length === 0;
  homeView.classList.toggle("hidden", !onboarding);
  workspace.classList.toggle("hidden", onboarding);
  toggleSplit.disabled = onboarding;

  state.layout.ratio = clamp(Number(state.layout.ratio) || 0.58, 0.20, 0.80);
  workspace.style.setProperty("--split-y", `${state.layout.ratio * 100}%`);
  workspace.dataset.layout = state.focus
    ? `focus-${state.focus}`
    : (state.layout.split ? "split" : `single-${state.layout.activePane === "bottom" ? "bottom" : "top"}`);

  updateLayoutButton();
  if (!onboarding) {
    for (const name of ["top", "bottom"]) renderPane(name, forceReload);
  }
  renderPanelRail();
  updateSyncControls();
}

function renderPane(name, forceReload = false) {
  const el = paneEls[name];
  const pane = state.panes[name] || { url:"", title:"", mode:"auto", compatDomains:[] };
  const input = el.querySelector('[data-role="url"]');
  const frame = el.querySelector('iframe[data-role="frame"]');
  const mediaView = el.querySelector('[data-role="media-view"]');
  const mediaFrame = el.querySelector('iframe[data-role="media-frame"]');
  const wrap = el.querySelector('.frame-wrap');
  const modeButton = el.querySelector('[data-action="mode"]');

  el.classList.toggle("active", state.layout.activePane === name);
  if (document.activeElement !== input) input.value = pane.url || "";

  const mode = normalizeMode(pane.mode);
  const meta = MODE_META[mode];
  modeButton.textContent = meta.label;
  modeButton.title = `${meta.title}\nClick: next mode · Shift+Click: previous mode`;
  modeButton.className = `mode-button mode-${mode}`;

  const renderer = resolveRenderer(pane);
  wrap.classList.toggle("is-real", renderer.type === "real");
  wrap.classList.toggle("is-media", renderer.type === "media");

  if (renderer.type === "real") {
    frame.removeAttribute("src");
    frame.dataset.current = "";
    mediaFrame.removeAttribute("src");
    mediaFrame.dataset.current = "";
    return;
  }

  if (renderer.type === "media") {
    frame.removeAttribute("src");
    frame.dataset.current = "";
    mediaView.dataset.service = renderer.serviceKey;
    mediaView.dataset.kind = renderer.kind;
    mediaView.setAttribute("aria-hidden", "false");
    if (forceReload || mediaFrame.dataset.current !== renderer.src) {
      mediaFrame.dataset.current = renderer.src;
      mediaFrame.src = renderer.src;
    }
    return;
  }

  mediaView.setAttribute("aria-hidden", "true");
  mediaFrame.removeAttribute("src");
  mediaFrame.dataset.current = "";
  if (forceReload || frame.dataset.current !== renderer.src) {
    frame.dataset.current = renderer.src;
    frame.src = renderer.src;
  }
}

function resolveRenderer(pane) {
  const mode = normalizeMode(pane.mode);
  const url = pane.url || "about:blank";

  if (mode === "real") return { type:"real", note:"" };

  if (mode === "auto") {
    const music = yandexMusicMedia(url, pane.title);
    if (music) return music;

    const videoId = youtubeVideoId(url);
    if (videoId) {
      return {
        type:"media",
        serviceKey:"youtube",
        kind:"video",
        src:`https://www.youtube-nocookie.com/embed/${encodeURIComponent(videoId)}?playsinline=1&rel=0`
      };
    }

    return { type:"iframe", src:url };
  }

  return { type:"iframe", src:url };
}

function updateLayoutButton() {
  let layout = "split";
  if (!state.layout.split) layout = state.layout.activePane === "bottom" ? "single-bottom" : "single-top";
  toggleSplit.dataset.layout = layout;
  toggleSplit.setAttribute("aria-pressed", String(Boolean(state.layout.split)));
  toggleSplit.title = state.layout.split
    ? "Показаны две области · нажмите для одной"
    : "Показана одна область · нажмите для двух";
}

function faviconURL(url) {
  const favicon = new URL("/_favicon/", chrome.runtime.getURL("/"));
  favicon.searchParams.set("pageUrl", url);
  favicon.searchParams.set("size", "32");
  return favicon.href;
}

function fallback(title) {
  const el = document.createElement("span");
  el.className = "rail-fallback";
  el.textContent = (title || "?").trim().slice(0,1).toUpperCase();
  return el;
}

function renderPanelRail() {
  panelSites.replaceChildren();
  const activeUrl = state.panes[state.layout.activePane]?.url || "";

  for (const site of state.sites) {
    if (!site?.url) continue;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "rail-site";
    button.title = `${site.title}\n${MODE_META[normalizeMode(site.mode)].title}\nClick → active pane · Shift+Click → bottom pane`;
    if (sameOriginOrUrl(activeUrl, site.url)) button.classList.add("active");

    const img = document.createElement("img");
    img.alt = "";
    img.src = faviconURL(site.url);
    img.addEventListener("error", () => img.replaceWith(fallback(site.title)), { once:true });
    button.append(img);

    button.addEventListener("click", async (event) => {
      await openSite(site, event.shiftKey ? "bottom" : null);
    });

    panelSites.append(button);
  }
}

async function openSite(site, targetPane = null) {
  const url = normalizeUrl(site.url);
  if (!url) return;

  const explicitBottom = targetPane === "bottom";
  const existing = explicitBottom ? null : findPaneForUrl(url);
  const name = explicitBottom ? "bottom" : (existing || state.layout.activePane);

  if (!existing || explicitBottom) {
    const inferred = inferDefaultsForUrl(url);
    const requestedMode = normalizeMode(site.mode || inferred.mode);
    state.panes[name] = {
      url,
      title:site.title || url,
      mode:requestedMode,
      compatDomains:normalizeCompatDomains((site.compatDomains || []).length ? site.compatDomains : inferred.compatDomains),
      sourceSiteId:site.id || null
    };
  }

  state.layout.activePane = name;
  if (explicitBottom) state.layout.split = true;
  state.focus = null;

  await syncCompatRules();
  await chrome.storage.local.set({ panes:state.panes, layout:state.layout });
  renderAll(false);
}

for (const [name, el] of Object.entries(paneEls)) {
  el.addEventListener("pointerdown", () => activatePane(name), { passive:true });
  el.querySelector('[data-action="activate"]').addEventListener("click", () => activatePane(name));
  el.querySelector('[data-action="go"]').addEventListener("click", () => navigateFromInput(name));
  el.querySelector('[data-role="url"]').addEventListener("keydown", (event) => {
    if (event.key === "Enter") navigateFromInput(name);
  });
  el.querySelector('[data-action="reload"]').addEventListener("click", () => renderPane(name, true));
  el.querySelector('[data-action="external"]').addEventListener("click", () => openTab(name));
  el.querySelector('[data-action="focus"]').addEventListener("click", () => {
    state.focus = state.focus === name ? null : name;
    renderAll();
  });
  el.querySelector('[data-action="mode"]').addEventListener("click", async (event) => {
    await cycleMode(name, event.shiftKey ? -1 : 1);
  });
  el.querySelector('[data-action="real-window"]').addEventListener("click", () => openRealWindow(name));
  el.querySelector('[data-action="real-tab"]').addEventListener("click", () => openTab(name));
}

async function activatePane(name) {
  if (state.layout.activePane === name) return;
  state.layout.activePane = name;
  await persistLayout();
  renderAll();
}

async function navigateFromInput(name) {
  const input = paneEls[name].querySelector('[data-role="url"]');
  const url = normalizeUrl(input.value);
  if (!url) { input.select(); return; }

  const previous = state.panes[name] || {};
  const inferred = inferDefaultsForUrl(url);

  // Typing a new URL is a new navigation intent, so it always begins in Auto.
  // If the user wants S/C/R for this URL they can choose it afterwards.
  state.panes[name] = {
    ...previous,
    url,
    title:url,
    mode:"auto",
    compatDomains:normalizeCompatDomains(inferred.compatDomains),
    sourceSiteId:null
  };
  state.layout.activePane = name;
  state.focus = null;

  await syncCompatRules();
  await chrome.storage.local.set({ panes:state.panes, layout:state.layout });
  // URL changed only in this pane. A normal render reloads only frames whose src changed.
  renderAll(false);
}

async function cycleMode(name, direction) {
  const pane = state.panes[name];
  const current = MODE_ORDER.indexOf(normalizeMode(pane.mode));
  const next = (current + direction + MODE_ORDER.length) % MODE_ORDER.length;
  pane.mode = MODE_ORDER[next];

  if (pane.mode === "compat" && (!pane.compatDomains || !pane.compatDomains.length)) {
    pane.compatDomains = inferDefaultsForUrl(pane.url).compatDomains;
    if (!pane.compatDomains.length) {
      try { pane.compatDomains = [new URL(pane.url).hostname]; } catch { pane.compatDomains = []; }
    }
  }

  await syncCompatRules();
  await chrome.storage.local.set({ panes:state.panes });
  // Changing renderer/header rules must refresh only the pane the user changed.
  // Reloading both panes is disruptive (video/forms/scroll position in the other pane).
  renderAll(false);
  renderPane(name, true);
}

async function syncCompatRules() {
  const response = await chrome.runtime.sendMessage({ type:"SYNC_COMPAT_RULES", panes:state.panes });
  if (!response?.ok) console.warn("Failed to sync compatibility rules", response?.error);
}

async function openTab(name) {
  const url = state.panes[name]?.url;
  if (isHttpUrl(url)) await chrome.tabs.create({ url });
}

async function openRealWindow(name) {
  const url = state.panes[name]?.url;
  if (!isHttpUrl(url)) return;

  const screenLeft = Number.isFinite(window.screen.availLeft) ? window.screen.availLeft : 0;
  const screenTop = Number.isFinite(window.screen.availTop) ? window.screen.availTop : 0;
  const availableWidth = window.screen.availWidth || 1280;
  const availableHeight = window.screen.availHeight || 800;
  const width = clamp(Math.round(availableWidth * 0.31), 380, 560);
  const height = clamp(availableHeight, 560, availableHeight);
  const left = screenLeft + Math.max(0, availableWidth - width);

  await chrome.windows.create({
    url,
    type:"popup",
    focused:true,
    left,
    top:screenTop,
    width,
    height
  });
}

async function collapseToRail() {
  const windowId = __atnWindow?.id;

  try {
    if (typeof chrome.sidePanel?.close === "function") {
      // Chromium closes the native panel first. The collapsed rail appears
      // only from onClosed, so the underlying page is not reflowed early.
      await chrome.sidePanel.close({ windowId });
      return;
    }
  } catch {}

  try {
    await chrome.runtime.sendMessage({ type:"COLLAPSE_PANEL", windowId });
  } catch {
    try { window.close(); } catch {}
  }
}

collapsePanelButton.addEventListener("click", collapseToRail);
settingsCollapse?.addEventListener("click", async () => {
  settingsDialog.close();
  await collapseToRail();
});

toggleSplit.addEventListener("click", async () => {
  state.focus = null;
  state.layout.split = !state.layout.split;
  await persistLayout();
  renderAll();
});

async function openAddSiteDialog({ blank=false } = {}) {
  titleInput.value = "";
  siteUrlInput.value = "";
  siteMode.value = "auto";
  siteCompatDomains.value = "";

  if (!blank) {
    try {
      const response = await chrome.runtime.sendMessage({ type:"GET_CURRENT_TAB", windowId:__atnWindow.id });
      if (response?.tab) {
        titleInput.value = response.tab.title || "";
        siteUrlInput.value = response.tab.url || "";
        const inferred = inferDefaultsForUrl(response.tab.url);
        siteCompatDomains.value = inferred.compatDomains.join(", ");
      }
    } catch {}
  }

  updateCompatDomainsVisibility();
  if (!siteDialog.open) siteDialog.showModal();
  setTimeout(() => (titleInput.value ? siteUrlInput : titleInput).focus(), 0);
}

function openSettingsDialog() {
  if (!settingsDialog.open) settingsDialog.showModal();
}

railAdd.addEventListener("click", () => openAddSiteDialog());
railSettings.addEventListener("click", openSettingsDialog);
homeAddCurrent.addEventListener("click", () => openAddSiteDialog());
homeAddCustom.addEventListener("click", () => openAddSiteDialog({blank:true}));
homeImport.addEventListener("click", openImportPicker);
siteMode.addEventListener("change", updateCompatDomainsVisibility);
cancelSite.addEventListener("click", () => siteDialog.close());
clearSite.addEventListener("click", () => {
  titleInput.value = "";
  siteUrlInput.value = "";
  siteMode.value = "auto";
  siteCompatDomains.value = "";
  updateCompatDomainsVisibility();
  titleInput.focus();
});
siteUrlInput.addEventListener("blur", () => {
  if (siteMode.value !== "compat" || siteCompatDomains.value.trim()) return;
  const inferred = inferDefaultsForUrl(normalizeUrl(siteUrlInput.value));
  siteCompatDomains.value = inferred.compatDomains.join(", ");
});

function updateCompatDomainsVisibility() {
  compatDomainsRow.classList.toggle("hidden", siteMode.value !== "compat");
}

siteForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const title = titleInput.value.trim();
  const url = normalizeUrl(siteUrlInput.value);
  if (!title || !url) return;

  const mode = normalizeMode(siteMode.value);
  const compatDomains = mode === "compat"
    ? normalizeCompatDomains(siteCompatDomains.value.split(/[,\s]+/))
    : [];

  const site = { id:crypto.randomUUID(), title, url, mode, compatDomains };
  const wasEmpty = state.sites.length === 0;
  state.sites = [...state.sites, site];

  const patch = { sites:state.sites };
  if (wasEmpty) {
    const inferred = inferDefaultsForUrl(url);
    state.panes.top = {
      url, title,
      mode,
      compatDomains:normalizeCompatDomains(compatDomains.length ? compatDomains : inferred.compatDomains),
      sourceSiteId:site.id
    };
    state.panes.bottom = { url:"", title:"", mode:"auto", compatDomains:[], sourceSiteId:null };
    state.layout.split = false;
    state.layout.activePane = "top";
    patch.panes = state.panes;
    patch.layout = state.layout;
  }

  await chrome.storage.local.set(patch);
  await syncCompatRules();
  siteDialog.close();
  renderAll(false);
});

function updateSyncControls() {
  if (settingsSync) settingsSync.checked = state.syncEnabled;
  if (homeSync) homeSync.checked = state.syncEnabled;
}

async function setSyncEnabled(enabled) {
  const response = await chrome.runtime.sendMessage({ type:"SET_SYNC_ENABLED", enabled:Boolean(enabled) });
  if (!response?.ok) throw new Error(response?.error || "Sync error");
  state.syncEnabled = response.enabled === true;
  updateSyncControls();
}

settingsSync.addEventListener("change", async () => {
  try { await setSyncEnabled(settingsSync.checked); }
  catch { settingsSync.checked = state.syncEnabled; }
});
homeSync.addEventListener("change", async () => {
  try { await setSyncEnabled(homeSync.checked); }
  catch { homeSync.checked = state.syncEnabled; }
});

async function exportSettings() {
  const data = await chrome.storage.local.get(["sites","panes","layout"]);
  const payload = {
    format:"app-tower-next",
    schemaVersion:1,
    exportedAt:new Date().toISOString(),
    sites:Array.isArray(data.sites) ? data.sites : [],
    panes:data.panes || null,
    layout:data.layout || null
  };
  const blob = new Blob([JSON.stringify(payload,null,2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const day = new Date().toISOString().slice(0,10);
  a.href = url;
  a.download = `app-tower-next-${day}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function validateImport(value) {
  if (!value || value.format !== "app-tower-next" || !Array.isArray(value.sites)) return null;
  const sites = value.sites.map(site => {
    const url = normalizeUrl(site?.url);
    if (!url) return null;
    return {
      id:String(site.id || crypto.randomUUID()),
      title:String(site.title || url),
      url,
      mode:normalizeMode(site.mode || "auto"),
      compatDomains:normalizeCompatDomains(site.compatDomains || [])
    };
  }).filter(Boolean);
  return { sites, panes:value.panes || null, layout:value.layout || null };
}

function openImportPicker() {
  importFile.value = "";
  importFile.click();
}

settingsExport.addEventListener("click", exportSettings);
settingsImport.addEventListener("click", openImportPicker);

importFile.addEventListener("change", async () => {
  const file = importFile.files?.[0];
  if (!file) return;
  try {
    const parsed = validateImport(JSON.parse(await file.text()));
    if (!parsed) throw new Error("Некорректный файл App Tower Next");
    pendingImport = parsed;
    importSummary.textContent = `Найдено ярлыков: ${parsed.sites.length}. Можно объединить их с текущими или полностью заменить текущую конфигурацию.`;
    if (!importDialog.open) importDialog.showModal();
  } catch (error) {
    alert(String(error?.message || error));
  }
});

async function applyImport(mode) {
  if (!pendingImport) return;
  const incoming = pendingImport;
  pendingImport = null;

  if (mode === "merge") {
    const byUrl = new Map(state.sites.map(site => [normalizeUrl(site.url), site]));
    for (const site of incoming.sites) if (!byUrl.has(site.url)) byUrl.set(site.url, site);
    state.sites = [...byUrl.values()];
    const patch = { sites:state.sites };
    if ((!state.panes.top?.url && !state.panes.bottom?.url) && incoming.panes) {
      patch.panes = incoming.panes;
      state.panes = incoming.panes;
    }
    await chrome.storage.local.set(patch);
  } else {
    state.sites = incoming.sites;
    state.panes = incoming.panes || {
      top:incoming.sites[0] ? {
        url:incoming.sites[0].url,
        title:incoming.sites[0].title,
        mode:normalizeMode(incoming.sites[0].mode || "auto"),
        compatDomains:incoming.sites[0].compatDomains || [],
        sourceSiteId:incoming.sites[0].id
      } : {url:"",title:"",mode:"auto",compatDomains:[],sourceSiteId:null},
      bottom:{url:"",title:"",mode:"auto",compatDomains:[],sourceSiteId:null}
    };
    state.layout = incoming.layout || { split:false, ratio:.58, activePane:"top" };
    await chrome.storage.local.set({ sites:state.sites, panes:state.panes, layout:state.layout });
  }

  importDialog.close();
  await syncCompatRules();
  renderAll(false);
}

importMerge.addEventListener("click", () => applyImport("merge"));
importReplace.addEventListener("click", () => applyImport("replace"));

settingsSingle.addEventListener("click", async () => {
  state.focus = null;
  state.layout.split = false;
  await persistLayout();
  renderAll();
  settingsDialog.close();
});

settingsResetSplit.addEventListener("click", async () => {
  state.focus = null;
  state.layout.split = true;
  state.layout.ratio = 0.58;
  await persistLayout();
  renderAll();
  settingsDialog.close();
});

let dragging = false;
splitter.addEventListener("pointerdown", (event) => {
  if (!state.layout.split) return;
  dragging = true;
  splitter.setPointerCapture(event.pointerId);
  document.body.style.userSelect = "none";
});
splitter.addEventListener("pointermove", (event) => {
  if (!dragging) return;
  const rect = workspace.getBoundingClientRect();
  state.layout.ratio = clamp((event.clientY - rect.top) / rect.height, 0.20, 0.80);
  workspace.style.setProperty("--split-y", `${state.layout.ratio * 100}%`);
});
splitter.addEventListener("pointerup", async (event) => {
  if (!dragging) return;
  dragging = false;
  document.body.style.userSelect = "";
  try { splitter.releasePointerCapture(event.pointerId); } catch {}
  await persistLayout();
});
splitter.addEventListener("dblclick", async () => {
  state.layout.ratio = 0.5;
  await persistLayout();
  renderAll();
});
splitter.addEventListener("keydown", async (event) => {
  if (!["ArrowUp","ArrowDown"].includes(event.key)) return;
  event.preventDefault();
  state.layout.ratio = clamp(state.layout.ratio + (event.key === "ArrowDown" ? 0.03 : -0.03), 0.20, 0.80);
  await persistLayout();
  renderAll();
});

async function persistLayout() { await chrome.storage.local.set({ layout:state.layout }); }

async function consumePendingAction() {
  const { pendingAction } = await chrome.storage.local.get("pendingAction");
  if (pendingAction) await handlePendingAction(pendingAction);
}
async function handlePendingAction(action) {
  if (!action?.intent) return;
  if (action.intent === "add") openAddSiteDialog();
  if (action.intent === "settings") openSettingsDialog();
  await chrome.storage.local.remove("pendingAction");
}

function youtubeVideoId(value) {
  try {
    const url = new URL(value);
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    let id = null;
    if (host === "youtu.be") id = url.pathname.split("/").filter(Boolean)[0] || null;
    if (host === "youtube.com" || host.endsWith(".youtube.com")) {
      if (url.pathname === "/watch") id = url.searchParams.get("v");
      else {
        const match = url.pathname.match(/^\/(?:shorts|embed|live)\/([A-Za-z0-9_-]{6,})/);
        if (match) id = match[1];
      }
    }
    return id && /^[A-Za-z0-9_-]{6,}$/.test(id) ? id : null;
  } catch { return null; }
}

function yandexMusicMedia(value, paneTitle) {
  try {
    const url = new URL(value);
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (host !== "music.yandex.ru") return null;

    let embed = null;
    let label = "Яндекс Музыка";
    if (url.pathname.startsWith("/iframe/")) {
      embed = url.href;
    } else {
      const match = url.pathname.match(/^\/album\/(\d+)\/track\/(\d+)(?:\/|$)/);
      if (!match) return null;
      const [, albumId, trackId] = match;
      embed = `https://music.yandex.ru/iframe/#track/${trackId}/${albumId}`;
      label = `Трек ${trackId}`;
    }

    return {
      type:"media",
      service:"Яндекс Музыка",
      serviceKey:"yandex-music",
      mark:"Я",
      kind:"audio",
      title:friendlyMediaTitle(paneTitle, label),
      src:embed
    };
  } catch {
    return null;
  }
}

function friendlyMediaTitle(value, fallback) {
  const text = String(value || "").trim();
  if (!text || /^https?:\/\//i.test(text)) return fallback;
  return text;
}

function inferDefaultsForUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (host === "translate.yandex.ru" || host.endsWith(".translate.yandex.ru")) {
      return { mode:"auto", compatDomains:["yandex.ru","ya.ru"] };
    }
    if (host === "youtu.be" || host === "youtube.com" || host.endsWith(".youtube.com")) {
      const domains = ["youtube.com","youtube-nocookie.com","google.com","googlevideo.com","ytimg.com","gstatic.com","googleapis.com","googleusercontent.com","ggpht.com","doubleclick.net"];
      return { mode:"auto", compatDomains:domains };
    }
    if (host === "music.yandex.ru" || host.endsWith(".music.yandex.ru")) {
      return { mode:"auto", compatDomains:[] };
    }
  } catch {}
  return { mode:"auto", compatDomains:[] };
}

function compatibilityDomainsForPane(pane) {
  const domains = normalizeCompatDomains(pane.compatDomains || []);
  try { domains.push(new URL(pane.url).hostname.toLowerCase()); } catch {}
  return [...new Set(domains.filter(Boolean))];
}

function normalizeCompatDomains(values) {
  const result = [];
  for (const raw of values || []) {
    const text = String(raw || "").trim().toLowerCase();
    if (!text) continue;
    try {
      const url = new URL(text.includes("://") ? text : `https://${text.replace(/^\.+/, "")}`);
      if (url.hostname && !result.includes(url.hostname)) result.push(url.hostname);
    } catch {}
    if (result.length >= 20) break;
  }
  return result;
}
function resolveAutoMode(url, mode) {
  return normalizeMode(mode);
}
function normalizeMode(mode) { return MODE_ORDER.includes(mode) ? mode : "auto"; }
function normalizeUrl(value) {
  let input = String(value || "").trim();
  if (!input) return null;
  if (!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(input)) input = "https://" + input;
  try {
    const url = new URL(input);
    if (!['http:','https:'].includes(url.protocol)) return null;
    return url.href;
  } catch { return null; }
}
function isHttpUrl(value) { return Boolean(normalizeUrl(value)); }

function findPaneForUrl(url) {
  for (const name of ["top","bottom"]) {
    const current = state.panes[name]?.url;
    if (!current) continue;
    if (current === url) return name;
    try { if (new URL(current).origin === new URL(url).origin) return name; } catch {}
  }
  return null;
}
function sameOriginOrUrl(a,b) {
  if (!a || !b) return false;
  if (a === b) return true;
  try { return new URL(a).origin === new URL(b).origin; } catch { return false; }
}
function clamp(value,min,max) { return Math.min(max,Math.max(min,value)); }

# App Tower Next v0.4.1

Experimental Manifest V3 extension for Microsoft Edge and Google Chrome.

## v0.4.1

- Removed the development default shortcuts (Yandex Translate / Google / GitHub / YouTube).
- Added Home onboarding when no shortcuts exist.
- `+` now opens the Add Site dialog prefilled from the active browser tab.
- The broom button clears the prefilled title/URL so an arbitrary site can be entered.
- Home provides Add current page, Add arbitrary site, Import, and Browser Sync.
- Settings provides Browser Sync on/off and JSON Export / Import.
- Browser Sync uses `chrome.storage.sync` for shortcut definitions only. Current panes, split ratio and active layout remain local to the device.
- JSON backup includes shortcuts, panes and layout. Import supports Merge or Replace.
- Fixed collapsed rail disappearing after `>` collapse by keeping an explicit per-window collapse intent across Side Panel port/onClosed races.
- Collapse broadcasts the page rail immediately and then invokes native `chrome.sidePanel.close()` without waiting for the background worker.

## Data model

- `chrome.storage.local`: working state and local layout.
- `chrome.storage.sync`: optional synced shortcut payload.
- Uninstall removes extension-local data as expected by Chromium.
- JSON Export is the explicit portable backup path.

## Install

1. Extract the ZIP into a clean folder.
2. Open `edge://extensions` or `chrome://extensions`.
3. Enable Developer mode.
4. Load unpacked and select the folder containing `manifest.json`.
5. Reload already-open HTTP/HTTPS tabs after updating an unpacked build.

## Security note

Compatibility mode removes frame-blocking response headers only for domains attached to a pane. Use Secure or Real Page for sensitive login/password pages when appropriate.


## v0.4.1

- The Add Site broom moved to the top-right corner and resets the whole form:
  title, URL, mode and compatibility domains.
- Collapse no longer shows or resizes the underlying page before Chromium has
  actually closed the native Side Panel.
- `sidePanel.onClosed` is authoritative for the collapsed state, so the browser
  owned native Side Panel X also naturally collapses back to App Tower.
- A stale Side Panel runtime port cannot override the collapsed state because
  `collapsedWindows` is persisted before the external rail is broadcast.


## v0.4.1

- Auto (`A`) is now the canonical default mode everywhere.
- Typing a URL manually into either pane always starts that new URL in Auto.
- Empty panes use Auto.
- New shortcuts default to Auto; an explicitly selected S/C/R shortcut keeps
  that configured mode.
- Auto is no longer silently persisted as Compatibility. The UI/state stays
  `A`; runtime logic decides whether scoped Compatibility is required.
- Schema 8 migrates old manually-entered S/C pane state back to Auto. Shortcut
  modes are preserved.
- Added the first compact media adapter: a Yandex Music track URL in the form
  `/album/<albumId>/track/<trackId>` is rendered through Yandex's official
  `/iframe/#track/<trackId>/<albumId>` player while the pane remains in Auto.


## v0.4.1

- Auto media renderer now presents supported services as compact player cards instead of full pages.
  Yandex Music track links use the documented 180 px official embed; YouTube video URLs use youtube-nocookie embeds.
- The collapsed App Tower rail is painted/reserved immediately from the static `document_start` content script, then reconciled with the persistent global X state.
- `runtime.onStartup` also performs a recovery injection pass for already-restored web tabs.
- The package overrides the browser New Tab page with a minimal App Tower start page so the rail exists on Ctrl+T and when the browser starts on a New Tab page.
- Browser-internal pages such as `edge://settings`, `edge://extensions`, downloads UI, the PDF viewer and other privileged surfaces still cannot be modified by a normal extension.
- The native Side Panel itself still cannot be programmatically opened on browser startup because `sidePanel.open()` requires a user action. Startup therefore guarantees the collapsed App Tower rail, not an expanded native side panel.


## v0.4.1 media UI

- Removed the App Tower card around official media embeds.
- The pane toolbar is the only App Tower chrome; the official player appears
  directly below it.
- Yandex Music track: full pane width, official 180 px embed.
- YouTube: full pane width, official 16:9 embed.
- AUTO remains visible only as the pane mode button `A`, not as a second badge.

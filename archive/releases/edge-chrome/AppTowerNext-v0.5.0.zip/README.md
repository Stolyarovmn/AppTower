# App Tower Next v0.5.0

Experimental Manifest V3 extension for Microsoft Edge and Google Chrome.

## What changed in v0.5.0

App Tower now has a real declarative module layer.

The Core still owns:
- persistent App Tower rail
- native Side Panel integration
- split panes
- Auto / Secure / Compatibility / Real Page
- startup / New Tab behavior
- shortcuts, Browser Sync and JSON backup
- a fixed safe renderer engine

Provider-specific media behavior is no longer hard-coded into `sidepanel.js`.

Bundled optional modules:
- `YouTube`
- `Яндекс Музыка`

They are described by JSON manifests under `modules/` and are copied to
`chrome.storage.local.atnInstalledModules` only when installed.

A fresh v0.5.0 install starts with no optional media modules enabled.
An upgrade from an older App Tower build automatically installs YouTube and
Yandex Music once so existing behavior is not lost; either module can then be
removed from Settings.

## Module Manager

Settings -> Modules shows available and installed declarative adapters.

Supported actions:
- Install a bundled module
- Remove a module
- Install an additional module from a JSON file

The Add Site dialog also suggests a matching module when the current URL belongs
to a known provider but its module is not installed.

## Security model

A module is data, not executable code.

The module loader accepts only the App Tower declarative schema:
- module metadata
- host hints
- bounded URL regex matchers
- media renderer type
- URL templates built from regex captures
- fixed height / fill / aspect-ratio layout hints

JavaScript, WASM, remote script URLs and arbitrary commands are not part of the
schema and are ignored/rejected by the validator. The executable logic remains
inside the reviewed extension package.

## Data / Sync

JSON Export now includes installed module manifests as well as shortcuts, panes
and layout. Import can merge or replace them.

Browser Sync payload schema 2 also carries the installed declarative module
manifests. Old schema-1 sync payloads remain accepted and do not wipe local
modules.

## Current bundled module behavior

### YouTube
Recognizes:
- `youtube.com/watch?v=...`
- `youtube.com/shorts/...`
- `youtube.com/embed/...`
- `youtube.com/live/...`
- `youtu.be/...`

Renderer: official `youtube-nocookie.com` 16:9 embed.

### Яндекс Музыка
Recognizes:
- `/album/<albumId>/track/<trackId>` -> 180 px track player
- `/album/<albumId>` -> fill-height album player
- `/users/<owner>/playlists/<playlistId>` -> fill-height legacy/public playlist
- already-embedded `/iframe/` URLs

Unsupported/new/private Yandex Music URL forms simply fall back to the ordinary
Auto web renderer.

## Install

1. Extract the ZIP into a clean folder.
2. Open `edge://extensions` or `chrome://extensions`.
3. Enable Developer mode.
4. Load unpacked and select the folder containing `manifest.json`.
5. Reload already-open HTTP/HTTPS tabs after updating an unpacked build.

## Notes

The browser-owned native Side Panel still cannot be automatically expanded at
browser startup because `chrome.sidePanel.open()` requires a user gesture.
The collapsed App Tower rail is injected at `document_start` and remains the
startup-presence mechanism.

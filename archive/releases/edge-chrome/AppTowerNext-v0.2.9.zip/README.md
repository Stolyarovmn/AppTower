# App Tower Next v0.2.9

Test build for Microsoft Edge and Google Chrome (Manifest V3).

## v0.2.9 changes

- Reworked collapsed App Tower page reservation using the same proven strategy as the audited Classic Sidebar:
  root right padding + scrollbar relocation + fixed-right element adjustment.
- This is intended to stop the 46 px rail from covering page content on browser start and after collapse.
- Internal panel controls moved to match the requested layout:
  - split (1/2 panes) stays in the content header;
  - collapse moved to the top of the right App Tower rail;
  - only one `+` remains, directly after the site shortcuts;
  - site shortcuts grow downward as sites are added;
  - Settings stays at the bottom.
- External collapsed rail follows the same shortcuts → `+` → Settings arrangement.
- Fluent/MDL2 system glyphs remain preferred for Add, Settings, and Collapse.

## Native Side Panel width limitation

The public Chromium `chrome.sidePanel` API still does not expose a width setter/resetter.
Edge 151 can therefore reset an extension Side Panel width when it is closed and reopened,
and the extension cannot reliably force the previous width back.

If exact automatic width restoration becomes a hard requirement, the expanded renderer has
to move away from native `chrome.sidePanel` to a controllable sidecar browser window/native
helper. That trade-off is intentionally not made in this build.

## Install

Use a new empty folder for this build, then load it from `edge://extensions` /
`chrome://extensions` with Developer mode enabled. Keep only one App Tower Next installed.
Refresh already-open web tabs once so their content script is updated.

## Security

Compatibility mode removes frame-blocking CSP/X-Frame-Options only for the pane's configured
domains. Secure mode leaves them unchanged. Real Page uses a top-level browser page.

No telemetry, analytics, remote JavaScript, sync backend, or cloud service is included.

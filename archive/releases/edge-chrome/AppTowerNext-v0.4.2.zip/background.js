const RENDER_MODES = new Set(["auto", "secure", "compat", "real"]);
const SIDE_PANEL_PATH = "sidepanel/sidepanel.html";
const SESSION_RULE_BASE = 30000;
const PANEL_SESSION_KEY = "atnPanelOpenWindowsV025";
const COLLAPSED_SESSION_KEY = "atnCollapsedWindowsV037";
const GLOBAL_ENABLED_KEY = "atnEnabled";
const SYNC_ENABLED_KEY = "atnSyncEnabled";
const SYNC_PAYLOAD_KEY = "atnSyncPayload";
const SYNC_UPDATED_AT_KEY = "atnSyncUpdatedAt";
const STATE_SCHEMA_VERSION = 9;
const YOUTUBE_COMPAT_DOMAINS = ["youtube.com","youtube-nocookie.com","google.com","googlevideo.com","ytimg.com","gstatic.com","googleapis.com","googleusercontent.com","ggpht.com","doubleclick.net"];

const LEGACY_DEFAULT_SITES = [
  { id:"yandex-translate", title:"Яндекс Переводчик", url:"https://translate.yandex.ru/" },
  { id:"google", title:"Google", url:"https://www.google.com/" },
  { id:"github", title:"GitHub", url:"https://github.com/" },
  { id:"youtube", title:"YouTube", url:"https://www.youtube.com/" }
];
const LEGACY_DEFAULT_IDS = new Set(LEGACY_DEFAULT_SITES.map(site => site.id));

const EMPTY_PANE = { url:"", title:"", mode:"auto", compatDomains:[], sourceSiteId:null };
const DEFAULT_STATE = {
  sites: [],
  panes: { top:structuredClone(EMPTY_PANE), bottom:structuredClone(EMPTY_PANE) },
  layout: { split:false, ratio:0.58, activePane:"top" }
};

let globallyEnabled = true;
const globalEnabledReady = chrome.storage.local.get(GLOBAL_ENABLED_KEY).then(data => {
  globallyEnabled = data[GLOBAL_ENABLED_KEY] !== false;
}).catch(() => {
  globallyEnabled = true;
});

let syncEnabled = false;
let applyingRemoteSync = false;

const openWindows = new Set();
const collapsedWindows = new Set();
const collapsedSessionReady = chrome.storage.session.get(COLLAPSED_SESSION_KEY).then(data => {
  for (const value of data[COLLAPSED_SESSION_KEY] || []) {
    const id = Number(value);
    if (Number.isInteger(id)) collapsedWindows.add(id);
  }
}).catch(() => {});
// A side-panel document can remain alive for a short time while Chromium is
// closing it. Its runtime Port must not immediately mark the window open again.
const panelSessionReady = chrome.storage.session.get(PANEL_SESSION_KEY).then(data => {
  for (const value of data[PANEL_SESSION_KEY] || []) {
    const id = Number(value);
    if (Number.isInteger(id)) openWindows.add(id);
  }
}).catch(() => {});
const railPorts = new Map();
const panelPorts = new Map();

chrome.runtime.onInstalled.addListener(() => {
  void initialize(true);
});
chrome.runtime.onStartup.addListener(() => {
  // Static document_start content scripts are the primary path. This recovery
  // pass covers tabs restored before the MV3 worker finished waking up.
  void initialize(true);
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick:false }).catch(() => {});

chrome.action.onClicked.addListener((tab) => {
  const windowId = tab?.windowId;
  globallyEnabled = true;
  chrome.storage.local.set({ [GLOBAL_ENABLED_KEY]: true }).catch(() => {});

  if (!Number.isInteger(windowId)) return;

  // The browser-action click is a direct user gesture, so open immediately.
  collapsedWindows.delete(windowId);
  persistCollapsedWindows();
  openWindows.add(windowId);
  persistPanelWindows();
  broadcastRail(windowId, false);
  try {
    const result = chrome.sidePanel.open({ windowId });
    result?.catch?.(() => {
      openWindows.delete(windowId);
      persistPanelWindows();
      broadcastRail(windowId, true);
    });
  } catch {
    openWindows.delete(windowId);
    persistPanelWindows();
    broadcastRail(windowId, true);
  }
});

if (chrome.sidePanel.onOpened?.addListener) {
  chrome.sidePanel.onOpened.addListener(({path, windowId}) => {
    if (!Number.isInteger(windowId) || !matchesPanelPath(path)) return;
    if (!collapsedWindows.has(windowId)) markPanelOpen(windowId);
  });
}
if (chrome.sidePanel.onClosed?.addListener) {
  chrome.sidePanel.onClosed.addListener(({path, windowId}) => {
    if (!Number.isInteger(windowId) || !matchesPanelPath(path)) return;
    markPanelClosed(windowId, { collapsed:true });
  });
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "ATN_RAIL") {
    const windowId = port.sender?.tab?.windowId;
    if (!Number.isInteger(windowId)) return;
    addPort(railPorts, windowId, port);
    Promise.all([panelSessionReady, collapsedSessionReady, globalEnabledReady]).then(() => {
      safePost(port, {
        type:"ATN_RAIL_VISIBILITY",
        visible:globallyEnabled && !openWindows.has(windowId)
      });
    });
    return;
  }

  const match = /^ATN_SIDE_PANEL:(\d+)$/.exec(port.name || "");
  if (match) {
    const windowId = Number(match[1]);
    if (!Number.isInteger(windowId)) return;
    addPort(panelPorts, windowId, port);
    // A stale/reconnecting panel document must not override a confirmed
    // collapsed state. Genuine OPEN_PANEL clears collapsedWindows first.
    if (!collapsedWindows.has(windowId)) markPanelOpen(windowId);
    port.onDisconnect.addListener(() => {
      queueMicrotask(() => {
        if (!panelPorts.get(windowId)?.size) {
          markPanelClosed(windowId, { collapsed:true });
        }
      });
    });
  }
});

function addPort(map, windowId, port) {
  let set = map.get(windowId);
  if (!set) { set = new Set(); map.set(windowId, set); }
  set.add(port);
  port.onDisconnect.addListener(() => {
    set.delete(port);
    if (!set.size) map.delete(windowId);
  });
}
function safePost(port, message) { try { port.postMessage(message); } catch {} }
function broadcastRail(windowId, visible) {
  const effectiveVisible = globallyEnabled && Boolean(visible);
  for (const port of railPorts.get(windowId) || []) {
    safePost(port, { type:"ATN_RAIL_VISIBILITY", visible:effectiveVisible });
  }
  chrome.tabs.query({ windowId }).then(tabs => Promise.allSettled(
    tabs
      .filter(t => Number.isInteger(t.id))
      .map(t => chrome.tabs.sendMessage(t.id, {
        type:"ATN_SET_RAIL_VISIBLE",
        visible:effectiveVisible
      }))
  )).catch(() => {});
}
function persistPanelWindows() {
  chrome.storage.session.set({ [PANEL_SESSION_KEY]: [...openWindows] }).catch(() => {});
}
function persistCollapsedWindows() {
  chrome.storage.session.set({ [COLLAPSED_SESSION_KEY]: [...collapsedWindows] }).catch(() => {});
}
function markPanelOpen(windowId) {
  if (collapsedWindows.has(windowId)) return;
  openWindows.add(windowId);
  persistPanelWindows();
  broadcastRail(windowId, false);
}

function markPanelClosed(windowId, { collapsed=true } = {}) {
  openWindows.delete(windowId);
  if (collapsed) collapsedWindows.add(windowId);
  persistPanelWindows();
  persistCollapsedWindows();
  broadcastRail(windowId, true);
}
function matchesPanelPath(path) {
  return !path || String(path).endsWith(SIDE_PANEL_PATH);
}

chrome.windows.onRemoved.addListener((windowId) => {
  collapsedWindows.delete(windowId);
  persistCollapsedWindows();
  openWindows.delete(windowId);
  persistPanelWindows();
  railPorts.delete(windowId);
  panelPorts.delete(windowId);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    if (changes.panes) void syncCompatibilityRules(changes.panes.newValue);
    if (changes[SYNC_ENABLED_KEY]) syncEnabled = changes[SYNC_ENABLED_KEY].newValue === true;
    if (changes.sites && syncEnabled && !applyingRemoteSync) void pushSyncPayload();
  }

  if (area === "sync" && changes[SYNC_PAYLOAD_KEY] && syncEnabled) {
    void applyRemoteSyncPayload(changes[SYNC_PAYLOAD_KEY].newValue);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;

  if (message.type === "OPEN_SITE") {
    globallyEnabled = true;
    chrome.storage.local.set({ [GLOBAL_ENABLED_KEY]: true }).catch(() => {});
    const windowId = Number.isInteger(Number(message.windowId)) ? Number(message.windowId) : sender?.tab?.windowId;
    let openPromise = Promise.resolve();
    if (Number.isInteger(windowId)) {
      collapsedWindows.delete(windowId);
      persistCollapsedWindows();
      // Hide the page rail synchronously before the native panel starts opening.
      openWindows.add(windowId);
      broadcastRail(windowId, false);
      try { openPromise = chrome.sidePanel.open({windowId}); }
      catch (error) { openPromise = Promise.reject(error); }
    }
    (async () => {
      try {
        const current = await ensureDefaults();
        const url = normalizeUrl(message.url);
        if (!url) throw new Error("Invalid URL");
        const explicitBottom = message.targetPane === "bottom";
        const existingPane = explicitBottom ? null : findPaneForUrl(current.panes, url);
        const targetPane = explicitBottom ? "bottom" : (existingPane || current.layout.activePane);
        if (!existingPane || explicitBottom) {
          const inferred = inferDefaultsForUrl(url);
          current.panes[targetPane] = {
            url,
            title:String(message.title || url),
            mode:resolveAutoMode(url, normalizeMode(message.mode || inferred.mode)),
            compatDomains:normalizeCompatDomains(Array.isArray(message.compatDomains) && message.compatDomains.length ? message.compatDomains : inferred.compatDomains),
            sourceSiteId:message.siteId ? String(message.siteId) : null
          };
        }
        if (explicitBottom) current.layout.split = true;
        current.layout.activePane = targetPane;
        await chrome.storage.local.set({panes:current.panes, layout:current.layout});
        await syncCompatibilityRules(current.panes);
        await openPromise;
        sendResponse({ok:true});
      } catch (error) {
        if (Number.isInteger(windowId)) markPanelClosed(windowId);
        sendResponse({ok:false, error:String(error?.message || error)});
      }
    })();
    return true;
  }

  if (message.type === "OPEN_PANEL") {
    globallyEnabled = true;
    chrome.storage.local.set({ [GLOBAL_ENABLED_KEY]: true }).catch(() => {});
    const windowId = Number.isInteger(Number(message.windowId)) ? Number(message.windowId) : sender?.tab?.windowId;
    let openPromise = Promise.resolve();
    if (Number.isInteger(windowId)) {
      collapsedWindows.delete(windowId);
      persistCollapsedWindows();
      openWindows.add(windowId);
      broadcastRail(windowId, false);
      try { openPromise = chrome.sidePanel.open({windowId}); }
      catch (error) { openPromise = Promise.reject(error); }
    }
    (async () => {
      try {
        await ensureDefaults();
        if (["add","settings"].includes(message.intent)) {
          await chrome.storage.local.set({pendingAction:{intent:message.intent, nonce:Date.now()}});
        }
        await openPromise;
        sendResponse({ok:true});
      } catch (error) {
        if (Number.isInteger(windowId)) markPanelClosed(windowId);
        sendResponse({ok:false, error:String(error?.message || error)});
      }
    })();
    return true;
  }


  if (message.type === "COLLAPSE_PANEL") {
    const windowId = Number(message.windowId);
    (async () => {
      try {
        if (!Number.isInteger(windowId)) throw new Error("Invalid windowId");
        if (typeof chrome.sidePanel.close !== "function") {
          throw new Error("sidePanel.close is not available in this Chromium version");
        }
        await chrome.sidePanel.close({ windowId });
        sendResponse({ ok:true });
      } catch (error) {
        sendResponse({ ok:false, error:String(error?.message || error) });
      }
    })();
    return true;
  }

  if (message.type === "DISABLE_GLOBAL") {
    (async () => {
      globallyEnabled = false;
      await chrome.storage.local.set({ [GLOBAL_ENABLED_KEY]: false });

      // Hide every collapsed rail immediately.
      const tabs = await chrome.tabs.query({ url:["http://*/*","https://*/*"] });
      await Promise.allSettled(
        tabs
          .filter(tab => Number.isInteger(tab.id))
          .map(tab => chrome.tabs.sendMessage(tab.id, {
            type:"ATN_SET_RAIL_VISIBLE",
            visible:false
          }))
      );

      // "Close" is global: close native App Tower side panels in all windows too.
      const windowIds = [...openWindows];
      openWindows.clear();
      collapsedWindows.clear();
      persistCollapsedWindows();
      persistPanelWindows();

      if (typeof chrome.sidePanel.close === "function") {
        await Promise.allSettled(
          windowIds.map(windowId => chrome.sidePanel.close({ windowId }))
        );
      }

      sendResponse({ ok:true });
    })().catch(error => {
      sendResponse({ ok:false, error:String(error?.message || error) });
    });
    return true;
  }

  if (message.type === "GET_RAIL_VISIBILITY") {
    const windowId = sender?.tab?.windowId;
    Promise.all([panelSessionReady, globalEnabledReady]).then(() => {
      sendResponse({
        visible:globallyEnabled &&
          (Number.isInteger(windowId) ? !openWindows.has(windowId) : true),
        enabled:globallyEnabled
      });
    });
    return true;
  }

  if (message.type === "SET_SYNC_ENABLED") {
    (async () => {
      const enabled = message.enabled === true;
      syncEnabled = enabled;
      await chrome.storage.local.set({ [SYNC_ENABLED_KEY]: enabled });
      if (enabled) await enableBrowserSync();
      sendResponse({ ok:true, enabled });
    })().catch(error => sendResponse({ok:false, error:String(error?.message || error)}));
    return true;
  }

  if (message.type === "GET_CURRENT_TAB") {
    (async () => {
      const windowId = Number(message.windowId);
      const tabs = await chrome.tabs.query(Number.isInteger(windowId)
        ? { active:true, windowId }
        : { active:true, currentWindow:true });
      const tab = tabs[0];
      const url = normalizeUrl(tab?.url);
      sendResponse({ ok:true, tab:url ? { title:String(tab?.title || url), url } : null });
    })().catch(error => sendResponse({ok:false, error:String(error?.message || error)}));
    return true;
  }

  if (message.type === "SYNC_COMPAT_RULES") {
    (async () => {
      const panes = message.panes || (await chrome.storage.local.get("panes")).panes;
      const result = await syncCompatibilityRules(panes);
      sendResponse({ok:true, ...result});
    })().catch(error => sendResponse({ok:false, error:String(error?.message || error)}));
    return true;
  }

  if (message.type === "GET_STATE") {
    (async () => {
      const current = await ensureDefaults();
      const extra = await chrome.storage.local.get(["pendingAction",SYNC_ENABLED_KEY]);
      sendResponse({...current, syncEnabled:extra[SYNC_ENABLED_KEY] === true, pendingAction:extra.pendingAction});
    })().catch(error => sendResponse({ok:false, error:String(error?.message || error)}));
    return true;
  }
});

async function initialize(injectOpenTabs) {
  let current = await ensureDefaults();
  if (current.syncEnabled) {
    await pullSyncOnStartup();
    current = await ensureDefaults();
  }
  await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:false});
  // v0.2.1 used dynamic rules. Clear any rules left by a same-ID development update.
  const oldDynamic = await chrome.declarativeNetRequest.getDynamicRules();
  if (oldDynamic.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:oldDynamic.map(r => r.id)});
  }
  await syncCompatibilityRules(current.panes);
  if (injectOpenTabs) await injectIntoOpenTabs();
}

async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({url:["http://*/*","https://*/*"]});
  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) continue;
    try {
      await chrome.scripting.insertCSS({target:{tabId:tab.id}, files:["content/rail.css"]});
      await chrome.scripting.executeScript({target:{tabId:tab.id}, files:["content/rail.js"]});
    } catch {}
  }
}

async function ensureDefaults() {
  const current = await chrome.storage.local.get([
    "sites","panes","layout","schemaVersion",
    GLOBAL_ENABLED_KEY,SYNC_ENABLED_KEY,SYNC_UPDATED_AT_KEY
  ]);

  const previousSchema = Number(current.schemaVersion) || 0;
  let sites = Array.isArray(current.sites)
    ? current.sites.map(upgradeSite).filter(Boolean)
    : [];

  // v0.3.6 removes the four development shortcuts. Remove only the original
  // built-in IDs during migration; user-created shortcuts are untouched.
  if (previousSchema < 7) {
    sites = sites.filter(site => !LEGACY_DEFAULT_IDS.has(site.id));
  }

  let panes = current.panes
    ? { top:upgradePane(current.panes.top), bottom:upgradePane(current.panes.bottom) }
    : structuredClone(DEFAULT_STATE.panes);

  if (previousSchema < 7) {
    for (const name of ["top","bottom"]) {
      if (LEGACY_DEFAULT_IDS.has(panes[name]?.sourceSiteId)) panes[name] = structuredClone(EMPTY_PANE);
    }
  }

  // v0.3.8 makes Auto the canonical default. Earlier builds could silently
  // persist S/C for a URL typed directly into a pane even though the user never
  // selected that mode. Treat only unsourced/manual panes as implicit and move
  // them back to Auto. Saved site shortcuts keep their explicitly configured mode.
  if (previousSchema < 8) {
    for (const name of ["top","bottom"]) {
      const pane = panes[name];
      if (pane?.url && !pane.sourceSiteId && (pane.mode === "secure" || pane.mode === "compat")) {
        pane.mode = "auto";
      }
      if (!pane?.url) panes[name] = structuredClone(EMPTY_PANE);
    }
  }

  if (previousSchema < 9) {
    // v0.4.0 changes renderer selection only; persisted pane/site data stays compatible.
  }

  // If migration leaves no saved sites, Home onboarding is authoritative.
  if (!sites.length) {
    panes = structuredClone(DEFAULT_STATE.panes);
  } else if (!panes.top?.url && !panes.bottom?.url) {
    panes.top = paneFromSite(sites[0]);
  }

  const layout = current.layout && typeof current.layout === "object" ? {
    split:current.layout.split === true,
    ratio:clamp(Number(current.layout.ratio) || .58,.20,.80),
    activePane:current.layout.activePane === "bottom" ? "bottom" : "top"
  } : structuredClone(DEFAULT_STATE.layout);

  if (previousSchema < 7) {
    const topReady = Boolean(panes.top?.url);
    const bottomReady = Boolean(panes.bottom?.url);
    if (topReady !== bottomReady) {
      layout.split = false;
      layout.activePane = bottomReady ? "bottom" : "top";
    }
  }

  const enabled = typeof current[GLOBAL_ENABLED_KEY] === "boolean"
    ? current[GLOBAL_ENABLED_KEY]
    : true;
  const sync = current[SYNC_ENABLED_KEY] === true;

  const patch = {
    sites, panes, layout,
    schemaVersion:STATE_SCHEMA_VERSION,
    [GLOBAL_ENABLED_KEY]:enabled,
    [SYNC_ENABLED_KEY]:sync,
    [SYNC_UPDATED_AT_KEY]:Number(current[SYNC_UPDATED_AT_KEY]) || 0
  };
  await chrome.storage.local.set(patch);
  globallyEnabled = enabled;
  syncEnabled = sync;
  return {sites,panes,layout,syncEnabled:sync};
}

function upgradeSite(site) {
  if (!site?.url) return null;
  const url = normalizeUrl(site.url); if (!url) return null;
  const inferred = inferDefaultsForUrl(url);
  const id = String(site.id || crypto.randomUUID());
  const requestedMode = normalizeMode(site.mode || "auto");
  const requestedDomains = Array.isArray(site.compatDomains) && site.compatDomains.length
    ? site.compatDomains
    : inferred.compatDomains;
  return {
    id,
    title:String(site.title || url),
    url,
    mode:requestedMode,
    compatDomains:normalizeCompatDomains(requestedDomains)
  };
}

function upgradePane(pane) {
  if (!pane?.url) return structuredClone(EMPTY_PANE);
  const url = normalizeUrl(pane.url);
  if (!url) return structuredClone(EMPTY_PANE);
  const inferred = inferDefaultsForUrl(url);
  return {
    url,
    title:String(pane.title || url),
    mode:resolveAutoMode(url, normalizeMode(pane.mode || inferred.mode)),
    compatDomains:normalizeCompatDomains(
      Array.isArray(pane.compatDomains) && pane.compatDomains.length
        ? pane.compatDomains
        : inferred.compatDomains
    ),
    sourceSiteId:pane.sourceSiteId ? String(pane.sourceSiteId) : null
  };
}

function paneFromSite(site) {
  const inferred = inferDefaultsForUrl(site.url);
  return {
    url:site.url,
    title:site.title || site.url,
    mode:resolveAutoMode(site.url, normalizeMode(site.mode || inferred.mode)),
    compatDomains:normalizeCompatDomains(
      Array.isArray(site.compatDomains) && site.compatDomains.length
        ? site.compatDomains
        : inferred.compatDomains
    ),
    sourceSiteId:site.id || null
  };
}

async function enableBrowserSync() {
  const local = await chrome.storage.local.get(["sites",SYNC_UPDATED_AT_KEY]);
  const remote = (await chrome.storage.sync.get(SYNC_PAYLOAD_KEY))[SYNC_PAYLOAD_KEY];
  const localSites = Array.isArray(local.sites) ? local.sites.map(upgradeSite).filter(Boolean) : [];

  if (!localSites.length && validSyncPayload(remote) && remote.sites.length) {
    await applyRemoteSyncPayload(remote, true);
  } else {
    await pushSyncPayload();
  }
}

async function pullSyncOnStartup() {
  const remote = (await chrome.storage.sync.get(SYNC_PAYLOAD_KEY))[SYNC_PAYLOAD_KEY];
  if (!validSyncPayload(remote)) return;
  await applyRemoteSyncPayload(remote);
}

function validSyncPayload(payload) {
  return Boolean(
    payload && payload.format === "app-tower-next-sync" &&
    Number.isFinite(Number(payload.updatedAt)) && Array.isArray(payload.sites)
  );
}

async function pushSyncPayload() {
  if (!syncEnabled || applyingRemoteSync) return;
  const {sites=[]} = await chrome.storage.local.get("sites");
  const updatedAt = Date.now();
  const payload = {
    format:"app-tower-next-sync",
    schemaVersion:1,
    updatedAt,
    sites:sites.map(upgradeSite).filter(Boolean)
  };
  await chrome.storage.local.set({ [SYNC_UPDATED_AT_KEY]:updatedAt });
  await chrome.storage.sync.set({ [SYNC_PAYLOAD_KEY]:payload });
}

async function applyRemoteSyncPayload(payload, force=false) {
  if (!syncEnabled || !validSyncPayload(payload)) return false;
  const local = await chrome.storage.local.get(["sites",SYNC_UPDATED_AT_KEY]);
  const localUpdatedAt = Number(local[SYNC_UPDATED_AT_KEY]) || 0;
  if (!force && Number(payload.updatedAt) <= localUpdatedAt) return false;

  const sites = payload.sites.map(upgradeSite).filter(Boolean);
  applyingRemoteSync = true;
  try {
    const patch = {
      sites,
      [SYNC_UPDATED_AT_KEY]:Number(payload.updatedAt) || Date.now()
    };
    const panes = (await chrome.storage.local.get("panes")).panes;
    if (!sites.length) patch.panes = structuredClone(DEFAULT_STATE.panes);
    else if (!panes?.top?.url && !panes?.bottom?.url) patch.panes = {top:paneFromSite(sites[0]), bottom:structuredClone(EMPTY_PANE)};
    await chrome.storage.local.set(patch);
  } finally {
    applyingRemoteSync = false;
  }
  return true;
}

async function syncCompatibilityRules(panes) {
  const domains = new Set();
  for (const pane of Object.values(panes || {})) {
    if (!paneNeedsCompatibility(pane)) continue;
    for (const domain of compatibilityDomainsForPane(pane)) domains.add(domain);
  }
  const existing = await chrome.declarativeNetRequest.getSessionRules();
  const removeRuleIds = existing.map(r => r.id);
  const addRules = [...domains].slice(0,100).map((domain,index) => ({
    id:SESSION_RULE_BASE + index,
    priority:10,
    action:{type:"modifyHeaders", responseHeaders:[
      {header:"x-frame-options",operation:"remove"},
      {header:"content-security-policy",operation:"remove"},
      {header:"content-security-policy-report-only",operation:"remove"}
    ]},
    condition:{
      initiatorDomains:[chrome.runtime.id],
      urlFilter:`||${domain}^`,
      resourceTypes:["sub_frame"]
    }
  }));
  await chrome.declarativeNetRequest.updateSessionRules({removeRuleIds,addRules});
  return {domains:[...domains], ruleIds:addRules.map(r=>r.id)};
}

function paneNeedsCompatibility(pane) {
  const mode = normalizeMode(pane?.mode);
  if (mode === "compat") return true;
  if (mode !== "auto") return false;
  // Auto is a real persisted mode in v0.3.8:
  // - known official media embeds need no header stripping;
  // - ordinary HTTP(S) pages get scoped Compatibility for their pane host.
  // Users can still select Secure explicitly when they do not want header changes.
  if (youtubeVideoId(pane?.url) || yandexMusicEmbedUrl(pane?.url)) return false;
  try {
    const u = new URL(pane?.url || "");
    return u.protocol === "http:" || u.protocol === "https:";
  } catch { return false; }
}
function youtubeVideoId(value) {
  try {
    const url = new URL(value); const host = url.hostname.replace(/^www\./,"").toLowerCase(); let id = null;
    if (host === "youtu.be") id = url.pathname.split("/").filter(Boolean)[0] || null;
    if (host === "youtube.com" || host.endsWith(".youtube.com")) {
      if (url.pathname === "/watch") id = url.searchParams.get("v");
      else { const match = url.pathname.match(/^\/(?:shorts|embed|live)\/([A-Za-z0-9_-]{6,})/); if (match) id = match[1]; }
    }
    return id && /^[A-Za-z0-9_-]{6,}$/.test(id) ? id : null;
  } catch { return null; }
}
function yandexMusicEmbedUrl(value) {
  try {
    const url = new URL(value);
    const host = url.hostname.replace(/^www\./,"").toLowerCase();
    if (host !== "music.yandex.ru") return null;

    if (url.pathname.startsWith("/iframe/")) return url.href;

    let match = url.pathname.match(/^\/album\/(\d+)\/track\/(\d+)(?:\/|$)/);
    if (match) {
      const [, albumId, trackId] = match;
      return `https://music.yandex.ru/iframe/#track/${trackId}/${albumId}`;
    }

    match = url.pathname.match(/^\/album\/(\d+)(?:\/|$)/);
    if (match) {
      return `https://music.yandex.ru/iframe/#album/${match[1]}`;
    }

    match = url.pathname.match(/^\/users\/([^/]+)\/playlists\/(\d+)(?:\/|$)/i);
    if (match) {
      const [, owner, playlistId] = match;
      return `https://music.yandex.ru/iframe/#playlist/${encodeURIComponent(owner)}/${playlistId}`;
    }

    return null;
  } catch {
    return null;
  }
}

function compatibilityDomainsForPane(pane) {
  const domains = normalizeCompatDomains(pane.compatDomains || []);
  try { const host = new URL(pane.url).hostname.toLowerCase(); if (host) domains.push(host); } catch {}
  return [...new Set(domains)];
}
function inferDefaultsForUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (host === "translate.yandex.ru" || host.endsWith(".translate.yandex.ru")) {
      return {mode:"auto",compatDomains:["yandex.ru","ya.ru"]};
    }
    if (host === "youtube.com" || host === "www.youtube.com" || host === "youtu.be" || host.endsWith(".youtube.com")) {
      return {mode:"auto",compatDomains:YOUTUBE_COMPAT_DOMAINS};
    }
    if (host === "music.yandex.ru" || host.endsWith(".music.yandex.ru")) {
      return {mode:"auto",compatDomains:[]};
    }
  } catch {}
  return {mode:"auto",compatDomains:[]};
}
function normalizeCompatDomains(values) {
  const result=[];
  for (const raw of values || []) {
    const text=String(raw||"").trim().toLowerCase(); if(!text) continue;
    try { const url=new URL(text.includes("://")?text:`https://${text.replace(/^\.+/,"")}`); const host=url.hostname.toLowerCase(); if(host && !result.includes(host)) result.push(host); } catch {}
    if(result.length>=20) break;
  }
  return result;
}
function resolveAutoMode(url, mode) {
  // Auto stays Auto in persisted/UI state. Renderer/header decisions happen at
  // runtime; they are no longer encoded by silently rewriting A into C.
  return normalizeMode(mode);
}
function normalizeMode(mode) { return RENDER_MODES.has(mode) ? mode : "auto"; }
function normalizeUrl(value) {
  let input=String(value||"").trim(); if(!input) return null;
  if(!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(input)) input="https://"+input;
  try { const u=new URL(input); return ["http:","https:"].includes(u.protocol) ? u.href : null; } catch { return null; }
}

function findPaneForUrl(panes, url) {
  for (const name of ["top","bottom"]) {
    const current = panes?.[name]?.url;
    if (!current) continue;
    if (current === url) return name;
    try { if (new URL(current).origin === new URL(url).origin) return name; } catch {}
  }
  return null;
}
function clamp(v,min,max){return Math.min(max,Math.max(min,v));}

# App Tower Next v0.3.2

Test build for Microsoft Edge and Google Chrome (Manifest V3).

## v0.2.9 changes

- Reworked collapsed App Tower page reservation using the same proven strategy as the audited Classic Sidebar:
  root right padding + scrollbar relocation + fixed-right element adjustment.
- This is intended to stop the 46 px rail from covering page content on browser start and after collapse.
- Internal panel controls moved to match the requested layout:
  - split (1/2 panes) stays in the content header;
  - collapse moved to the top of the right App Tower rail;
  - only one `+` remains, directly after the site shortcuts;
  - site shortcuts grow downward as sites are added;
  - Settings stays at the bottom.
- External collapsed rail follows the same shortcuts → `+` → Settings arrangement.
- Fluent/MDL2 system glyphs remain preferred for Add, Settings, and Collapse.

## Native Side Panel width limitation

The public Chromium `chrome.sidePanel` API still does not expose a width setter/resetter.
Edge 151 can therefore reset an extension Side Panel width when it is closed and reopened,
and the extension cannot reliably force the previous width back.

If exact automatic width restoration becomes a hard requirement, the expanded renderer has
to move away from native `chrome.sidePanel` to a controllable sidecar browser window/native
helper. That trade-off is intentionally not made in this build.

## Install

Use a new empty folder for this build, then load it from `edge://extensions` /
`chrome://extensions` with Developer mode enabled. Keep only one App Tower Next installed.
Refresh already-open web tabs once so their content script is updated.

## Security

Compatibility mode removes frame-blocking CSP/X-Frame-Options only for the pane's configured
domains. Secure mode leaves them unchanged. Real Page uses a top-level browser page.

No telemetry, analytics, remote JavaScript, sync backend, or cloud service is included.


## v0.3.2 changes

- Collapsed App Tower now keeps a permanent Expand control at the very top. It reopens the native Side Panel without changing saved pane URLs, split ratio, active pane, or one/two-pane state.
- The open-panel Collapse control and the 1/2-layout control share the same 44 px row and are visually aligned.
- The page rail starts at `document_start` and reserves its 46 px immediately on normal HTTP/HTTPS pages.
- Right-edge compensation also recognizes sticky elements.
- Native Edge/Chrome New Tab pages (`edge://newtab`, `chrome://newtab`) are browser-internal pages and cannot receive this content-script rail. Showing App Tower there requires replacing New Tab with an extension-owned page using `chrome_url_overrides`; v0.3.2 deliberately does not replace the user's native New Tab page.


## v0.3.2 fixes

- Collapse is guarded against a stale/reconnecting Side Panel runtime port.
  The page App Tower is reasserted after the native panel closes.
- The native-panel layout button and rail collapse/expand button now share one
  exact 44 px control row and one border line; the extra separator/margins were
  removed.
- A blocked iframe can still activate its pane: focus of the iframe element is
  used as a fallback when the embedded content script cannot run.
- The collapsed rail keeps its expand button in the same aligned top row.


## v0.3.2 fixes

- Removed the artificial `html -> body` scrollbar relocation. It was the source
  of the extra bottom horizontal scrollbar on the first restored tab.
- The page keeps its native scrollbar at the far right; the collapsed App Tower
  is positioned immediately to the left of that scrollbar.
- The root document only reserves the 46 px rail and clips accidental root
  horizontal overflow instead of creating a second scroll container.
- The collapsed rail now mirrors the expanded visual structure:
  native-like 56 px close row -> 44 px expand row -> shortcuts -> separator ->
  Add -> Settings.
- Added a Fluent close (`X`) control to the collapsed rail. It hides App Tower
  on the current document; explicitly opening the native Side Panel resets that
  local dismissal.
- Restored the short top and bottom rail separators. The top separator is drawn
  at `bottom: 0` inside the same 44 px row, so it no longer shifts the right
  control line relative to the main layout button.

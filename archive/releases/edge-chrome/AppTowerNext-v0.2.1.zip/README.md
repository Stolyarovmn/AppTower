# App Tower Next v0.2.1

Тестовая сборка для Microsoft Edge / Google Chrome (Manifest V3).

## Что нового в 0.2

- 4 renderer-режима на каждую область: **Auto / Secure / Compatibility / Real Page**.
- `Compatibility` использует `declarativeNetRequest` и снимает `X-Frame-Options`, `Content-Security-Policy` и `Content-Security-Policy-Report-Only` **только у sub-frame ответов выбранных доменов**.
- Для Яндекс Переводчика добавлен preset `yandex.ru, ya.ru`, потому что авторизация может уходить на `sso.ya.ru`.
- YouTube video URL (`watch`, `youtu.be`, `shorts`, `live`) в режиме `Auto` превращается в privacy-enhanced `youtube-nocookie.com/embed/...` mini-player.
- `Real Page` не использует iframe: показывает кнопку для открытия URL как настоящего popup browser window либо обычной вкладки.
- Режим можно переключать прямо в toolbar кнопкой `A/S/C/R`. Shift+click — назад.
- При добавлении сайта можно выбрать renderer по умолчанию и список Compatibility domains.

## Режимы

- **A / Auto** — специальные renderers. Сейчас: YouTube video → mini-player; остальные URL → Secure.
- **S / Secure** — обычный iframe, защитные заголовки сайта не меняются.
- **C / Compatibility** — iframe, но для заданных доменов снимаются frame-blocking response headers.
- **R / Real Page** — top-level browser page в отдельном окне/вкладке. CSP/X-Frame-Options не обходятся.

### Важное ограничение Compatibility

Chromium DNR умеет удалить response header целиком, но не вырезать только директиву `frame-ancestors` из существующего CSP. Поэтому Compatibility удаляет **весь CSP response header** у sub-frame документа для разрешённых доменов. Это существенно ослабляет защиту встроенной страницы. Не используйте Compatibility для password vault, банков, финансовых и других чувствительных страниц.

## Установка / обновление в Edge

1. Распакуйте ZIP в постоянную папку.
2. Откройте `edge://extensions`.
3. Включите **Режим разработчика**.
4. Для сохранения старых настроек лучше заменить содержимое прежней папки App Tower Next файлами этой версии и нажать **Обновить** на карточке расширения.
5. При новой папке используйте **Загрузить распакованное расширение** и выберите папку с `manifest.json`.
6. После обновления нажмите F5 в уже открытых сайтах, чтобы content script rail обновился.

Chrome: те же шаги через `chrome://extensions`.

## Как проверить

1. Верхний pane должен стартовать с Яндекс Переводчиком в режиме `C`.
2. Если он всё ещё не проходит SSO, это значит, что в redirect/login flow участвует ещё один домен — его можно будет добавить в Compatibility domains в следующем UI для редактирования закладки; пока переключите pane в `R`.
3. Вставьте в нижнюю область URL конкретного YouTube-ролика и оставьте режим `A`: должен открыться mini-player.
4. Нажмите `R` для сложного сайта → **Открыть боковым окном**: это уже top-level browser page, не iframe.

## Что осталось на следующие версии

- UI редактирования/удаления/drag&drop существующих закладок.
- Автоматическая диагностика iframe failure там, где это возможно.
- Workspaces и сохранённые split-комбинации.
- Translate selected text.
- Более аккуратный sidecar manager для Real Page (привязка к окну браузера, восстановление геометрии, multi-monitor).
- Firefox adapter без изменения core-модели.


## v0.2.1 fixes

- Removed duplicate extension title inside the native browser Side Panel header.
- New one/two-pane icon with visual state.
- Cancel in Add Site no longer triggers required-field validation.
- External 46 px page rail is actively hidden while the native Side Panel is open.
- Removed persistent renderer warning banners.
- Auto mode now attempts the full YouTube website using scoped Compatibility rules; specific video URLs still use the privacy-enhanced mini-player.
- Added microphone/camera permission delegation to embedded pages (the browser/site may still deny it).

Full YouTube in an iframe is best-effort: YouTube can still change login, third-party-cookie, or JavaScript behavior independently of X-Frame-Options/CSP.

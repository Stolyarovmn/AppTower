# App Tower Next v0.8.0

Experimental Manifest V3 extension targeting Microsoft Edge and Google Chrome,
with a sidecar fallback path for Chromium-family browsers where
`chrome.sidePanel` is unavailable.

## v0.8.0 — browser layer, Workspaces and control plane

### BrowserAdapter

Browser-specific container operations are isolated in
`shared/browser-adapter.js`.

- Edge / Chrome with `chrome.sidePanel`: native browser Side Panel.
- Browser without the API: managed top-level sidecar window.
- UI skin hint:
  - Edge -> Fluent-like
  - Chrome -> Chromium-like
  - Yandex Browser -> Yandex-like

The Core does not depend directly on a browser-specific sidebar implementation.

A public Extensions API that exposes the user's native Edge/Chrome/Yandex
browser Workspace identity is not used because App Tower cannot rely on such an
API. App Tower instead binds its own active Workspace to the current browser
window for the session.

### Native-style Options page

The gear opens the extension Options page instead of growing the Side Panel
settings dialog.

The page has a browser-settings-like left navigation:

- General
- Appearance
- Workspaces
- Shortcuts
- Recent
- Sites
- Notifications
- Performance
- Modules
- Web Apps
- Sidecars
- Media
- Permissions
- Sync and data

Contextual `Site settings...` opens/focuses the same Options page and routes it
to the matching site.

### Workspaces

Each App Tower Workspace owns:

- shortcut tree (sites, groups, two-pane templates)
- top/bottom pane URLs and modes
- split state and split ratio

The active Workspace is bound to a browser window for the current session.
Workspace names and shortcut trees can be synchronized through Browser Sync;
open pane state remains local.

### Search

A magnifier is at the bottom of the expanded rail and collapsed rail.

Default command:

`Ctrl+Shift+Space` (`Command+Shift+Space` on macOS)

Search covers:

- sites
- groups
- two-pane templates
- Workspaces
- Recent App Tower entries
- App Tower commands

### Recent

App Tower keeps a bounded Recent list per Workspace. It is separate from the
rail and can be searched or opened from Options -> Recent.

### Resource sleeping

Normal web/media pane surfaces register a live resource lease.

Policy:

- idle web pane: unload after 5 minutes
- global hard cap: 1..6 live pane resources, default 6
- hidden pane is unloaded immediately
- `Never sleep` protects a site from the 5-minute idle timer
- the global hard cap still wins, so App Tower never intentionally keeps more
  live pane resources than the configured maximum

Resource leases live in `chrome.storage.session`, so MV3 service-worker
suspension does not reset the idle timer.

Sleeping unloads the iframe and keeps the App Tower pane URL/state. The pane can
be woken explicitly.

### Per-site settings

Options -> Sites currently provides per-origin:

- Zoom: 60%..150%
- Sleep policy: 5 minutes / Never sleep

Shortcut context menus provide renderer mode:

- Auto
- Secure
- Compatibility
- Real Page

### Notifications

Options -> Notifications uses the browser's site notification content setting
when the optional `contentSettings` permission is granted:

- Default
- Allow
- Block

Rules are rebuilt as a set so returning one origin to `Default` does not remove
the other App Tower notification rules.

Declarative modules may also declare notification categories. App Tower stores
the selected categories per origin. A module still needs an actual documented
integration to produce or filter those category-specific notifications.

### Native browser context menu

The normal browser page/link context menu contains App Tower actions:

- Open App Tower
- Add current page
- Open link in bottom pane
- Settings

The custom menu inside the Side Panel is styled for the detected browser,
because browsers do not expose an API for placing native context-menu widgets
inside an arbitrary extension page.

Shortcut menu actions include:

- Open
- Open in bottom pane
- Open separately
- Add to group
- Create two-pane template
- Auto / Secure / Compatibility / Real Page
- Site settings
- Duplicate
- Remove

### Sidecar Manager

Top-level Real Page / PWA sidecar windows are tracked in session state.
Options -> Sidecars can focus or close tracked sidecars.

### Media contract

`shared/media-contract.js` defines a provider-neutral state contract for
module-backed media surfaces.

The Core can expose an attached media surface in the rail/Options. Transport
controls such as play/pause are deliberately not fabricated: they are only
enabled when a provider module has a verified control API.

### Module Permissions dashboard

Options -> Permissions shows the BrowserAdapter capabilities and installed
declarative modules, including their host scope.

Modules remain data-only: no downloaded JavaScript/WASM is executed by the
module registry.

A module manifest may declare notification categories as metadata.

## v0.7.x shortcut organization

The rail supports mouse wheel, touchpad, touch/pen panning, overflow arrows,
groups with 1-2 letter badges, pointer drag/reorder, drag-to-group, and
two-pane templates with adjustable 20-80% favicon overlap.

## v0.6.x foundations

- System / Light / Dark theme
- system or custom accent
- modular Auto renderer
- PWA-aware discovery and top-level sidecar launch
- split panes
- persistent collapsed rail
- App Tower New Tab

## Browser notes

### Edge / Chrome

The main build uses the native Side Panel API when available.

### Yandex Browser

The runtime contains a sidecar fallback, but Yandex Browser compatibility is
not claimed as identical to Edge/Chrome until the actual target Yandex version
is tested. A fallback package can omit the Side Panel manifest key/permission
so installation does not depend on Yandex supporting that Chrome API.

## Install / update unpacked build

1. Extract the ZIP into a stable folder.
2. Open `edge://extensions` or `chrome://extensions`.
3. Enable Developer mode if needed.
4. Load unpacked, or replace the files of the already-loaded unpacked build.
5. Press Reload on App Tower Next.
6. Reload already-open HTTP/HTTPS pages so the current collapsed rail/content
   scripts are injected.

Do not uninstall the unpacked extension merely to update it if you want to keep
its local storage.
